package com.lead.agent.interceptorimpl;

import java.math.BigDecimal;
import java.text.Format;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lead.agent.interceptor.CustomerDobDetail;
import com.lead.agent.service.SmokerService;

/**
 * @author ad01084
 *
 */
@Service
public class CustomerDobDetailImpl implements CustomerDobDetail 
{
	private static Logger logger = LogManager.getLogger(CustomerDobDetailImpl.class);
	
	@Autowired
	private SmokerService smokerService;
	ResourceBundle resb = ResourceBundle.getBundle("application");
	String speech="";
	/** 
	 * @Param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String getDobDetail(Map<String, Map<String, String>> map, String sessionId) {
		
		try {
		if (map.containsKey(sessionId)) {

			logger.info("Smoker API call start");
			String response = smokerService.callSmokerAPI(map, sessionId);
			if("Age is less than 18 years.".equalsIgnoreCase(response))
			{
				speech=map.get(sessionId+"Msg").get("dobError");
			}
			else{
			logger.info("Smoker API call end");
			JSONObject object = new JSONObject(response);
			
			JSONObject res = (JSONObject) object.getJSONObject("response").getJSONObject("payload")
					.getJSONArray("resPlan").get(0);
			String totalPremiumWOGST = res.get("totalPremiumWOGST") + "";

			String policyTerm = res.getString("policyTerm");
			String totalPremium = res.getString("totalPremiumWGST");
			double doubletotalPremiumWGST = Double.parseDouble(totalPremium);
			
			

			String convertedtotalPremiumWGST = String.valueOf(doubletotalPremiumWGST);
			String[] arr = convertedtotalPremiumWGST.split("\\.");
			String totalPremiumWGST = arr[0];
			
			Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
			
			String totalPremiumWGSTFormat=format.format(new BigDecimal(totalPremiumWGST));

			map.get(sessionId).put("TotalPremiumWOGST", totalPremiumWOGST);
			map.get(sessionId).put("totalPremiumWGST", totalPremium);

			String message1 = map.get(sessionId+"Msg").get("smoker1"); 
			String message2 = map.get(sessionId+"Msg").get("smoker2");  
			String formattedMessage2 = MessageFormat.format(message2, policyTerm, totalPremiumWGSTFormat);

			speech=message1+formattedMessage2+map.get(sessionId+"Msg").get("smoker3"); 
			}
		} else {
			speech = "Internal Glitch Please try after some time :-smoker";
		}
		}
		catch(Exception ex) {
		 logger.error("Exception in getDOBdetails Method :: sessionId :: "+sessionId + " :: "+ex);	
		}
		
		
		logger.info("Speech :: "+speech);
		return speech;
	}
}
