package com.lead.agent.service;

import java.util.Map;

/**
 * @author ad01084
 *
 */
@FunctionalInterface
public interface SmokerService 
{
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String callSmokerAPI(Map<String, Map<String, String>> map, String sessionId);

}
