package com.lead.agent.interceptor;

import java.util.Map;

/**
 * @author ad01084
 *
 */
@FunctionalInterface
public interface CustomerWelcomeDetail 
{
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String welcomeCall(Map<String,Map<String,String>> map, String sessionId);

}
