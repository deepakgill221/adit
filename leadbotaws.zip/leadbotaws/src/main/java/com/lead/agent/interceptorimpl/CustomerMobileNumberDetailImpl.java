package com.lead.agent.interceptorimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.lead.agent.interceptor.CustomerMobileNumberDetail;
/**
 * @author ad01084
 *
 */
@Service
public class CustomerMobileNumberDetailImpl implements CustomerMobileNumberDetail 
{
	private static Logger logger = LogManager.getLogger(CustomerMobileNumberDetailImpl.class);
	
	ResourceBundle res = ResourceBundle.getBundle("application");
	String speech="";
	/** (non-Javadoc)
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String getCustMobileNum(Map<String, Map<String, String>> map, String sessionId) {
		if(map.containsKey(sessionId))
		{
			speech=map.get(sessionId+"Msg").get("mobileNumber2"); 
			speech=speech.replace("<Insert_checkbox>", "<input type=\"checkbox\"  checked=\"checked\" disabled>");
		}
		else{
			speech="Internal Glitch Please try after some time :- mobile";
		}
		logger.info("Speech :: "+speech);
		return speech;
	}
}