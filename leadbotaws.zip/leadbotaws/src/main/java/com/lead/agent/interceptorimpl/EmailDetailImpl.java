package com.lead.agent.interceptorimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.lead.agent.interceptor.EmailDetail;

/**
 * @author ad01084
 *
 */
@Service
public class EmailDetailImpl implements EmailDetail 
{
	private static Logger logger = LogManager.getLogger(EmailDetailImpl.class);
	String speech="";
	ResourceBundle res = ResourceBundle.getBundle("application");
	/** (non-Javadoc)
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String getEmailDetail(Map<String, Map<String, String>> map, String sessionId) {
		speech=map.get(sessionId+"Msg").get("mobileNumber"); 
		logger.info("Speech :: "+speech);
		return speech;
	}

}
