package com.lead.agent.interceptor;

import java.util.Map;

/**
 * @author ad01084
 *
 */
@FunctionalInterface
public interface CustomerEmailDetail {
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String getEmail(Map<String,Map<String,String>> map, String sessionId);
}
