package com.mli.bot.lead.response;

import java.io.Serializable;

public interface GenericResponse  extends Serializable{

	
}
