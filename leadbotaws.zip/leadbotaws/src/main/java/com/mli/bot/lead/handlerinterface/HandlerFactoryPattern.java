package com.mli.bot.lead.handlerinterface;

import com.mli.bot.lead.handlerinterface.RequestResponseHandler;
import com.mli.bot.lead.request.WebhookRequest;


public interface HandlerFactoryPattern {

	public RequestResponseHandler  getHandlerObject(WebhookRequest request);
	
}
