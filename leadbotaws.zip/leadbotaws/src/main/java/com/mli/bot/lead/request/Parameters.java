package com.mli.bot.lead.request;

import java.io.Serializable;

public class Parameters implements Serializable{
	
	  private String gender;
	  private String smoke;
	  private String date;
	  private String customername;
	  private String email;
	  private String mobilenum;
	  
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getSmoke() {
			return smoke;
		}
		public void setSmoke(String smoke) {
			this.smoke = smoke;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public String getCustomername() {
			return customername;
		}
		public void setCustomername(String customername) {
			this.customername = customername;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getMobilenum() {
			return mobilenum;
		}
		public void setMobilenum(String mobilenum) {
			this.mobilenum = mobilenum;
		}
	
}
