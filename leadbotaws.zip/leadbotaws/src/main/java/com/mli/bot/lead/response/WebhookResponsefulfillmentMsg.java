package com.mli.bot.lead.response;

import java.io.Serializable;

public class WebhookResponsefulfillmentMsg implements Serializable{

	WebhookResponseText text;
 
	public WebhookResponsefulfillmentMsg()
	{
		text=new WebhookResponseText();
	}
	
	
	public WebhookResponseText getText() {
		return text;
	}

	public void setText(WebhookResponseText text) {
		this.text = text;
	}

	
}
