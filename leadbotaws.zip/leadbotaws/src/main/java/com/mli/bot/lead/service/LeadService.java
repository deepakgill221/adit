package com.mli.bot.lead.service;

import com.mli.bot.lead.exceptions.GenericCustomException;
import com.mli.bot.lead.request.InternalBasicRequest;
import com.mli.bot.lead.response.GenericResponseDTO;

/**
 * @author ad01084
 *
 */
public interface LeadService 
{
	/**
	 * @param jsonStr : Request data in JSON Format
	 * @return
	 */
	public GenericResponseDTO leadBotProcess(InternalBasicRequest basicRequest) throws GenericCustomException ;
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	public void removeUnUsedSessionFromCache();
}
