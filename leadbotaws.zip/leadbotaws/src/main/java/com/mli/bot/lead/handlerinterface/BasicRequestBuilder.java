package com.mli.bot.lead.handlerinterface;

import com.mli.bot.lead.exceptions.GenericCustomException;
import com.mli.bot.lead.request.InternalBasicRequest;
import com.mli.bot.lead.request.WebhookRequest;

public interface BasicRequestBuilder {

	public InternalBasicRequest getBasicRequest(WebhookRequest  webhookRequest) throws GenericCustomException;
	
}
