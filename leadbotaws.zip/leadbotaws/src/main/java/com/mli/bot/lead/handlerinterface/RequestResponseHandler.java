package com.mli.bot.lead.handlerinterface;

import com.mli.bot.lead.exceptions.GenericCustomException;
import com.mli.bot.lead.response.GenericResponse;

public interface RequestResponseHandler{
	
	
	public void requestHandler() throws GenericCustomException;
	
	public void responseHandler() throws GenericCustomException;
	
	public GenericResponse getResponse() ;
	
	public void processRequest() throws GenericCustomException;
	

}
