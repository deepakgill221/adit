package com.mli.bot.lead.serviceimpl;

import java.util.Map;
import java.util.UUID;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.bot.lead.service.GetLeadService;
import com.mli.bot.lead.utils.BeanProperty;
import com.mli.bot.lead.utils.HttpCaller;

/**
 * @author ad01084
 *
 */
@Service
public class GetLeadServiceImpl implements GetLeadService {
	@Autowired
	private BeanProperty bean;
	@Autowired
	HttpCaller httpCaller;
	private static Logger logger = LogManager.getLogger(GetLeadServiceImpl.class);

	/**
	 * (non-Javadoc)
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String getLeadAPI(Map<String, Map<String, String>> map, String sessionId) {

		StringBuilder result = new StringBuilder();
		try {
			String leadIdStr = map.get(sessionId).get("leadId");
			logger.info("Get Lead API Lead Id- " + leadIdStr);
			int leadId = getLeadInInt(leadIdStr);
			String extURL = bean.getGetLead();
			String soaUserId = bean.getSoaUserId();
			String soaPassword = bean.getSoaPassword();
			StringBuilder requestdata = new StringBuilder();
			requestdata.append("{ ");
			requestdata.append("  \"request\": {	");
			requestdata.append("    \"header\": {	");
			requestdata.append("      \"soaUserId\": \"" + soaUserId + "\",	");
			requestdata.append("      \"soaCorrelationId\": \"").append(UUID.randomUUID()).append("\",	");
			requestdata.append("      \"soaPassword\": \"" + soaPassword + "\",	");
			requestdata.append("      \"soaMsgVersion\": \"1.0\",	");
			requestdata.append("      \"soaAppId\": \"NEO\"	");
			requestdata.append("    },	");
			requestdata.append("    \"requestData\": {	");
			requestdata.append("      \"getLead\": {	");
			requestdata.append("        \"leadId\": " + leadId + "	");
			requestdata.append("      }	");
			requestdata.append("    }	");
			requestdata.append("  }	");
			requestdata.append("} ");
			httpCaller.callHttp(extURL, requestdata, result);
		} catch (Exception e) {
			logger.info("Exception Occoured While making request to call API : " + e);
		}
		return result.toString();
	}
	
	private int getLeadInInt(String leadIdStr)
	{
		int leadId = 0;
		try {
			leadId = Integer.parseInt(leadIdStr);
		} catch (Exception ex) {
			logger.info("Exception while parsing leadId" + ex);
		}
		return leadId;
	}
}
