package com.mli.bot.lead.handlerInterfaceImpl;

import org.springframework.stereotype.Component;

import com.mli.bot.lead.exceptions.GenericCustomException;
import com.mli.bot.lead.handlerinterface.BasicRequestBuilder;
import com.mli.bot.lead.request.InternalBasicRequest;
import com.mli.bot.lead.request.WebhookRequest;

@Component
public class BasicRequestBuilderImpl implements BasicRequestBuilder
{
	public InternalBasicRequest getBasicRequest(WebhookRequest  webhookRequest) throws GenericCustomException {
		
		InternalBasicRequest internalBasicRequest=new InternalBasicRequest();
		try
		{
		internalBasicRequest.setAction(webhookRequest.getQueryResult().getAction());
		internalBasicRequest.setQuery(webhookRequest.getQueryResult().getQueryText());
		internalBasicRequest.setSession(webhookRequest.getSession());
		internalBasicRequest.getParameters().setCustomername(webhookRequest.getQueryResult().getParameters().getCustomername());
		internalBasicRequest.getParameters().setDate(webhookRequest.getQueryResult().getParameters().getDate());
		internalBasicRequest.getParameters().setEmail(webhookRequest.getQueryResult().getParameters().getEmail());
		internalBasicRequest.getParameters().setGender(webhookRequest.getQueryResult().getParameters().getGender());
		internalBasicRequest.getParameters().setMobilenum(webhookRequest.getQueryResult().getParameters().getMobilenum());
		internalBasicRequest.getParameters().setSmoke(webhookRequest.getQueryResult().getParameters().getSmoke());
		}
		catch(Exception ec)
		{
			throw new GenericCustomException(ec.getMessage(), ec.getLocalizedMessage(), null);
		}
		return internalBasicRequest;
	}
}
