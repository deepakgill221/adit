package com.mli.bot.lead.service;

import java.util.Map;

import com.mli.bot.lead.response.InnerData;


/**
 * @author ad01084
 *
 */
public interface Button 
{
	/**
	 * @return
	 */
	public InnerData getButtonsYesNo();
	/**
	 * @return
	 */
	public InnerData getButtonsGender();
	/**
	 * @return
	 */
	public InnerData letsProceed();
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public InnerData proceed(Map<String,Map<String,String>> map, String sessionId);
}
