package com.mli.bot.lead.handlerInterfaceImpl;


import com.mli.bot.lead.handlerinterface.RequestResponseHandler;
import com.mli.bot.lead.response.GenericResponse;

public class TwitterHandler  implements RequestResponseHandler {

	

	@Override
	public void requestHandler() {
	}

	@Override
	public void responseHandler() {
		
	}

	@Override
	public GenericResponse getResponse() {
		return null;
	}

	@Override
	public void processRequest() {
		
	}

	
		

}
