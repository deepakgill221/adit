package com.mli.bot.lead.handlerInterfaceImpl;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.mli.bot.lead.controller.LeadController;
import com.mli.bot.lead.exceptions.GenericCustomException;
import com.mli.bot.lead.exceptions.WebCustomExceptionHandler;
import com.mli.bot.lead.handlerinterface.BasicRequestBuilder;
import com.mli.bot.lead.handlerinterface.RequestResponseHandler;
import com.mli.bot.lead.request.InternalBasicRequest;
import com.mli.bot.lead.request.WebhookRequest;
import com.mli.bot.lead.response.GenericResponse;
import com.mli.bot.lead.response.GenericResponseDTO;
import com.mli.bot.lead.response.WebhookResponse;
import com.mli.bot.lead.service.LeadService;

public class WebHandler implements RequestResponseHandler {

	private static Logger logger = LogManager.getLogger(LeadController.class);
	private WebhookRequest webReq;
	private GenericResponse webRes;
	private LeadService leadBotService;
	GenericResponseDTO genericResponseDto;
	private InternalBasicRequest basicReq;
	private BasicRequestBuilder basicRequestBuilder;

	public WebHandler(WebhookRequest webReq, LeadService leadBotService, BasicRequestBuilder basicRequestBuilder) {
		this.webReq = webReq;
		this.leadBotService = leadBotService;
		this.basicRequestBuilder = basicRequestBuilder;

		try 
		{
			logger.info("call request handler method start");
			requestHandler();
			logger.info("call request handler method ends");

			logger.info("call processRequest  method starts");
			processRequest();
			logger.info("call processRequest  method ends");

			logger.info("call responseHandler  method starts");
			responseHandler();
			logger.info("call responseHandler  method ends");

		} catch (GenericCustomException ex) {
		    this.webRes = new WebCustomExceptionHandler(ex).getFormattedExceptionResponse();
		}

	}

	
	@Override
	public void requestHandler() throws GenericCustomException {
		basicReq = basicRequestBuilder.getBasicRequest(webReq);
	}

	@Override
	public void responseHandler() throws GenericCustomException {
		this.webRes = new WebhookResponse(genericResponseDto.getSpeech(), genericResponseDto.getDisplayText(),
				genericResponseDto.getData());
	}

	@Override
	public GenericResponse getResponse() {

		return this.webRes;
	}

	@Override
	public void processRequest() throws GenericCustomException {
		genericResponseDto = leadBotService.leadBotProcess(basicReq);
	}

}
