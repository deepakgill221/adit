package com.mli.bot.lead.controller;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mli.bot.lead.handlerinterface.HandlerFactoryPattern;
import com.mli.bot.lead.handlerinterface.RequestResponseHandler;
import com.mli.bot.lead.request.WebhookRequest;
import com.mli.bot.lead.response.GenericResponse;
import com.mli.bot.lead.service.LeadService;

/**
 * @author ad01084
 *
 */
@RestController

public class LeadController {
	private static Logger logger = LogManager.getLogger(LeadController.class);
	@Autowired
	private LeadService leadBotService;
	
	@Autowired
	private HandlerFactoryPattern factoryPattern;
	
	
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	@Scheduled(cron = "0 0/10 * * * ?")
	public void removeCashethirtyminute() 
	{
		logger.info("Cron job to remove un-used session from cache : Start");
		leadBotService.removeUnUsedSessionFromCache();
	}

	
	@PostMapping("/leadAgent")
	public GenericResponse webhook(@RequestBody WebhookRequest webReq) 
	{
		
		logger.info("lead boat process starts");
		RequestResponseHandler   reqRpnsHandler = factoryPattern.getHandlerObject(webReq);
		logger.info("lead boat process Ends");
		return  reqRpnsHandler.getResponse();
		
	}
	
	

}
