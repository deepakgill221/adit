package com.mli.bot.lead.request;

public class InternalBasicRequest {

	private String session;
	private String query;
	private String action;
	private Parameters parameters;

	public InternalBasicRequest() {
		parameters=new Parameters();
	}

	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Parameters getParameters() {
		return parameters;
	}

	public void setParameters(Parameters parameters) {
		this.parameters = parameters;
	}

}
