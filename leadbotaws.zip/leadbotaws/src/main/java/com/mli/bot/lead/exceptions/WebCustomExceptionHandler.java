package com.mli.bot.lead.exceptions;

import com.mli.bot.lead.response.GenericResponse;
import com.mli.bot.lead.response.WebhookResponse;

public class WebCustomExceptionHandler extends GenericCustomException 
{  
	   
	   private static final long serialVersionUID = 7397479533721583476L;
	   
	   public WebCustomExceptionHandler(GenericCustomException genericException)
	   {
		    super(genericException.getSpeech(),genericException.getDisplayText(),genericException.getData());
	   }
	   
	   public GenericResponse getFormattedExceptionResponse() 
	   {
		    return new WebhookResponse(speech, displayText, data);
	   }
	
}
