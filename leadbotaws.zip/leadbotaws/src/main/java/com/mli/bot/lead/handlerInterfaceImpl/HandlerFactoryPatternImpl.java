package com.mli.bot.lead.handlerInterfaceImpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mli.bot.lead.handlerinterface.BasicRequestBuilder;
import com.mli.bot.lead.handlerinterface.HandlerFactoryPattern;
import com.mli.bot.lead.handlerinterface.RequestResponseHandler;
import com.mli.bot.lead.request.WebhookRequest;
import com.mli.bot.lead.service.LeadService;


@Component
public class HandlerFactoryPatternImpl implements HandlerFactoryPattern{

	@Autowired
	private LeadService leadBotService;
	
	@Autowired 
	BasicRequestBuilder basicRequestBuilder;  
	
	@Override
	public RequestResponseHandler getHandlerObject(WebhookRequest request) {
		
			return new WebHandler(request,leadBotService,basicRequestBuilder);
			
			
	}

	
}
