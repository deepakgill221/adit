package com.mli.bot.lead.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.mli.bot.lead.request.InternalBasicRequest;


/**
 * @author ad01084
 *
 */
@Service
public class DataFromJson 
{
	private static Logger logger = LogManager.getLogger(DataFromJson.class);

	/**
	 * @param object 
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	
	
	private static final String NAME = "name";
	private static final String GENDER = "gender";
	private static final String MOBILENUM ="mobilenum";
	private static final String DATE ="date";
	private static final String SMOKE ="smoke";
	
	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String customerNameVariable(InternalBasicRequest basicRequest, String sessionId,
			Map<String, Map<String, String>> externalMap) {
		String name;
		try {
			name = basicRequest.getParameters().getCustomername();
			String[] str = name.split(" ");
			name = str[0];
			name = name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
			externalMap.get(sessionId).put(NAME, name);
		} catch (Exception e) {
			if (externalMap.containsKey(sessionId)) {
				logger.error("We face Exception while getting customer name from json when session id exist : "
						+ sessionId + " : " + e);
			} else {
				logger.error("We face Exception while getting customer name from json : " + e);
			}
			name = "";
		}
		return name;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String genderVariable(InternalBasicRequest  basicRequest, String sessionId, Map<String, Map<String, String>> externalMap) {
		final String male="M";
		final String female="F";
		String genderStr;
		try {
			genderStr = basicRequest.getParameters().getGender();
			if ("male".equalsIgnoreCase(genderStr)) {
				genderStr = male;
				externalMap.get(sessionId).put(GENDER, genderStr);
			} else {
				genderStr = female;
				externalMap.get(sessionId).put(GENDER, genderStr);
			}
		} catch (Exception e) {
			if (externalMap.containsKey(sessionId)) {
			logger.error("We face Exception while getting gender from json when session id exist : "+sessionId+" : " + e);
			}
			else
			{
			logger.error("We face Exception while getting gender from json" + e);	
			}
				
			genderStr = "";
		}
			return genderStr;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String emailVariable(InternalBasicRequest basicRequest, String sessionId, Map<String, Map<String, String>> externalMap) {
		String custEmail;
		
			try {
				custEmail = basicRequest.getParameters().getEmail();
				custEmail = custEmail.replaceAll("\\s", "");
				externalMap.get(sessionId).put("custEmail", custEmail);
			} catch (Exception e) {
				
				if (externalMap.containsKey(sessionId)) {
				    logger.error("We face Exception while getting customer email from json when session id exist : "+sessionId+" : " + e);
				}
				else
				{
					logger.error("We face Exception while getting customer email from json" + e);	
				}
				custEmail = "";
			}
		
		return custEmail;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String mobileVariable(InternalBasicRequest  basicRequest, String sessionId, Map<String, Map<String, String>> externalMap) {
		String mobileNum;
		try {
			mobileNum = basicRequest.getParameters().getMobilenum();
			externalMap.get(sessionId).put(MOBILENUM, mobileNum);
		} catch (Exception e) {
			if (externalMap.containsKey(sessionId)) {
				logger.error("We face Exception while getting customer mobileNum from json when session id exist : "
						+ sessionId + " : ", e);
			} else {
				logger.error("We face Exception while getting customer mobileNum from json", e);
			}
			mobileNum = "";
		}

		return mobileNum;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String dateVariable(InternalBasicRequest  basicRequest, String sessionId, Map<String, Map<String, String>> externalMap) {
		String date;
		try {
			date = basicRequest.getParameters().getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat sdfFormat = new SimpleDateFormat("dd-MM-yyyy");
			Date date1 = sdf.parse(date);
			String strDate1 = sdfFormat.format(date1);
			date = strDate1;
			externalMap.get(sessionId).put(DATE, date);
		} catch (Exception e) {
			if (externalMap.containsKey(sessionId)) {
				logger.error("We face Exception while getting customer date from json when session id exist : "
						+ sessionId + " : ", e);
			} else {
				logger.error("We face Exception while getting date from json", e);
			}
			date = "";
		}
		
		return date;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String smokeVariable(InternalBasicRequest basicRequest, String sessionId, Map<String, Map<String, String>> externalMap) {
		String smoke;
		try {
			smoke = basicRequest.getParameters().getSmoke();
			if ("smoker".equalsIgnoreCase(smoke) || "Yes".equalsIgnoreCase(smoke) || SMOKE.equalsIgnoreCase(smoke)) {
				smoke = "Y";
				externalMap.get(sessionId).put(SMOKE, smoke);
			} else {
				smoke = "N";
				externalMap.get(sessionId).put(SMOKE, smoke);
			}
		} catch (Exception e) {
			if (externalMap.containsKey(sessionId)) {
				logger.error("We face Exception while getting customer smoke from json when session id exist : "
						+ sessionId + " : ", e);
			} else {
				logger.error("We face Exception while getting smoke from json", e);
			}
			smoke = "";
		}
		return smoke;
	}
}
