package com.qc.common;

import java.text.DecimalFormat;

import org.springframework.stereotype.Service;

@Service
public class ValueInLacs {


	public String getValueInLacs(String valueInString) {

        
		float i = Float.parseFloat(valueInString)/100000;
		DecimalFormat decimalFormat = new DecimalFormat(".00");
        String numberAsString = decimalFormat.format(i);
		
               return numberAsString;
	}

}
