package com.qc.utils;

import org.springframework.stereotype.Service;

@Service
public class HierarchyManage {
	
	public String getHierarchyData(String channel, String subChannel, String superZone, String zone, String keyMarket, 
			String region, String cluster, String circle, String go)
	{
		String userLevel = "";
		
		if(go != null && !(go.isEmpty()))
		{
			userLevel = go;
		}
		else if(circle != null && !(circle.isEmpty()))
		{
			userLevel = circle;
		}
		else if(cluster!=null && !(cluster.isEmpty()))
		{
			userLevel = cluster;
		}
		else if(region!=null && !(region.isEmpty()))
		{
			userLevel = region;
		}
		else if(keyMarket!=null && !(keyMarket.isEmpty()))
		{
			userLevel = keyMarket;
		}
		else if(zone!=null && !(zone.isEmpty()))
		{
			userLevel = zone;
		}
		else if(superZone!=null && !(superZone.isEmpty()))
		{
			userLevel = superZone;
		}
		else if(subChannel!=null && !(subChannel.isEmpty()))
		{
			userLevel = subChannel;
		}
		else
		{
			userLevel = channel;
		}
		return userLevel;
		
	}

}
