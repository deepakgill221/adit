package com.qc.utils;

import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class Commons 
{
	private static final Logger logger = LogManager.getLogger(Commons.class);
	
	private Commons() {
	    throw new IllegalAccessError("Commons class");
	  }
	
	public static String getMethodName()
	{
		String methodName="";
		try
		{
			methodName=Thread.currentThread().getStackTrace()[2].getMethodName();
		}
		catch(Exception e)
		{
			logger.info(e);
			methodName="MethodNameNotFound";
		}
		return methodName;
	}

	@SuppressWarnings("unchecked")
	public static Map<String,Object> getGsonData(String jsonData)
	{
		JsonElement jsonElement=new JsonParser().parse(jsonData);
		Map<String,Object> data=new Gson().fromJson(jsonElement,Map.class);
		//System.out.println(data);			
		return data;
	}
	
	public static String tokenGenerator()
	{
		UUID uniqueKey = UUID.randomUUID();   
		  System.out.println (uniqueKey);  
		return uniqueKey.toString();
	}
}