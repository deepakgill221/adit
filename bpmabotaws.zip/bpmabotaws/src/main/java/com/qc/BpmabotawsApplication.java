package com.qc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BpmabotawsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BpmabotawsApplication.class, args);
	}

}
