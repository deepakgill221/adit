package com.qc.jsonImpl;

import org.json.JSONObject;

import com.qc.dataBean.NatHybModeMixBean;

public class NatHybModeMix 
{
	public static NatHybModeMixBean modeMixBean = new NatHybModeMixBean();
	public void natHybModeMix(JSONObject object)
	{
		try{
			modeMixBean.setNativ_annual_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_annual_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setNativ_semi_annual_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_semi_annual_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setNativ_quarterly_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_quarterly_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setNativ_monthly_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_monthly_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setNativ_single_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_single_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setNativ_annual_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_annual_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setNativ_semi_annual_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_semi_annual_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setNativ_quarterly_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_quarterly_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setNativ_monthly_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_monthly_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setNativ_single_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("nativ_single_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybride_annual_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybride_annual_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybre_semi_annual_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybre_semi_annual_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybre_quarterly_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybre_quarterly_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybre_monthly_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybre_monthly_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybre_single_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybre_single_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybre_annual_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybre_annual_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybre_semi_annual_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybre_semi_annual_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybre_quarterly_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybre_semi_annual_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybre_monthly_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybre_semi_annual_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setHybre_single_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("hybre_single_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		try{
			modeMixBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("natHybModeMix").get("real_tim_timstamp").toString());
		}catch(Exception e){}
	}
}