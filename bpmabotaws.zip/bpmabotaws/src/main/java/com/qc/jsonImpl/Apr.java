package com.qc.jsonImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.qc.dataBean.AprBean;

@Component
public class Apr {

	private static Logger logger = LogManager.getLogger(Apr.class);
	@Autowired
	AprBean aprBean;

	public AprBean getApr(JSONObject object) {
		JSONObject payLoad = null;
		try {
			if (object != null) {
				payLoad = object.getJSONObject("payload");

				JSONObject aprPayloadResponse = payLoad.getJSONObject("aprPayloadResponse");

				aprBean.setAgentId(validatePolicyData(aprPayloadResponse.get("agentId")));
				aprBean.setBotType(validatePolicyData(aprPayloadResponse.get("botType")));
				aprBean.setPaidCasesMtd(validatePolicyData(aprPayloadResponse.get("paidCasesMtd")));
				aprBean.setAdjMfypMtd(validatePolicyData(aprPayloadResponse.get("adjMfypMtd")));
				aprBean.setWeightMfypMtd(validatePolicyData(aprPayloadResponse.get("weightMfypMtd")));
				aprBean.setFycMtd(validatePolicyData(aprPayloadResponse.get("fycMtd")));
				aprBean.setMtdGrowthPer(validatePolicyData(aprPayloadResponse.get("mtdGrowthPer")));
				aprBean.setYtdPaidCases(validatePolicyData(aprPayloadResponse.get("ytdPaidCases")));
				aprBean.setAdjMfypYtd(validatePolicyData(aprPayloadResponse.get("adjMfypYtd")));
				aprBean.setWeightMfypYtd(validatePolicyData(aprPayloadResponse.get("weightMfypYtd")));
				aprBean.setYtdFycWithoutSgBonus(validatePolicyData(aprPayloadResponse.get("ytdFycWithoutSgBonus")));
				aprBean.setYtdGrowthPer(validatePolicyData(aprPayloadResponse.get("ytdGrowthPer")));
				aprBean.setMtdAppliedNops(validatePolicyData(aprPayloadResponse.get("mtdAppliedNops")));
				aprBean.setMtdAppliedWfyp(validatePolicyData(aprPayloadResponse.get("mtdAppliedWfyp")));
				aprBean.setAplAdjIfypMtd(validatePolicyData(aprPayloadResponse.get("aplAdjIfypMtd")));
				aprBean.setEarlySuccessCases(validatePolicyData(aprPayloadResponse.get("earlySuccessCases")));
				aprBean.setEarlySuccessFyc(validatePolicyData(aprPayloadResponse.get("earlySuccessFyc")));
				aprBean.setEarlySuccessCasesShortfall(
						validatePolicyData(aprPayloadResponse.get("earlySuccessCasesShortfall")));
				aprBean.setEarlySuccessFycShortfall(
						validatePolicyData(aprPayloadResponse.get("earlySuccessFycShortfall")));
				aprBean.setFinalEarlySuccess(validatePolicyData(aprPayloadResponse.get("finalEarlySuccess")));
				aprBean.setFycActualMtd(validatePolicyData(aprPayloadResponse.get("fycActualMtd")));
				aprBean.setFycTargetMtd(validatePolicyData(aprPayloadResponse.get("fycTargetMtd")));
				aprBean.setShortInFycMtd(validatePolicyData(aprPayloadResponse.get("shortInFycMtd")));
				aprBean.setProactiveManMonthsMtd(validatePolicyData(aprPayloadResponse.get("proactiveManMonthsMtd")));
				aprBean.setProStatusmtd(validatePolicyData(aprPayloadResponse.get("proStatusmtd")));
				aprBean.setFycActualYtd(validatePolicyData(aprPayloadResponse.get("fycActualYtd")));
				aprBean.setFycYtdTarget(validatePolicyData(aprPayloadResponse.get("fycYtdTarget")));
				aprBean.setShortInFycYtd(validatePolicyData(aprPayloadResponse.get("shortInFycYtd")));
				aprBean.setProStatusYtd(validatePolicyData(aprPayloadResponse.get("proStatusYtd")));
				aprBean.setPaidCsYtd(validatePolicyData(aprPayloadResponse.get("paidCsYtd")));
				aprBean.setShortInPaidCase(validatePolicyData(aprPayloadResponse.get("shortInPaidCase")));
				aprBean.setManMonthytd(validatePolicyData(aprPayloadResponse.get("manMonthytd")));
				aprBean.setActivityYtdVintage(validatePolicyData(aprPayloadResponse.get("activityYtdVintage")));
				aprBean.setActivityYtdStLevel(validatePolicyData(aprPayloadResponse.get("activityYtdStLevel")));
				aprBean.setActivityYtdLastActiveDate(
						validatePolicyData(aprPayloadResponse.get("activityYtdLastActiveDate")));
				aprBean.setActivityYtdYtdActiveStatus(
						validatePolicyData(aprPayloadResponse.get("activityYtdYtdActiveStatus")));
				aprBean.setActivityYtdMtdActiveStatus(
						validatePolicyData(aprPayloadResponse.get("activityYtdMtdActiveStatus")));
				aprBean.setQrFyc(validatePolicyData(aprPayloadResponse.get("qrFyc")));
				aprBean.setShortfallQrFyc(validatePolicyData(aprPayloadResponse.get("shortfallQrFyc")));
				aprBean.setQrQualifyingMonth(validatePolicyData(aprPayloadResponse.get("qrQualifyingMonth")));
				aprBean.setPaidCase9In90(validatePolicyData(aprPayloadResponse.get("paidCase9In90")));
				aprBean.setFyc9In90(validatePolicyData(aprPayloadResponse.get("fyc9In90")));
				aprBean.setShortInPaidCase9In90(validatePolicyData(aprPayloadResponse.get("shortInPaidCase9In90")));
				aprBean.setShortInFyc9In90(validatePolicyData(aprPayloadResponse.get("shortInFyc9In90")));
				aprBean.setNineIn90Month(validatePolicyData(aprPayloadResponse.get("nineIn90Month")));
				aprBean.setComisionDtlCarerAgtSchmSt(
						validatePolicyData(aprPayloadResponse.get("comisionDtlCarerAgtSchmSt")));
				aprBean.setFycqtr1(validatePolicyData(aprPayloadResponse.get("fycqtr1")));
				aprBean.setFycqtr2(validatePolicyData(aprPayloadResponse.get("fycqtr2")));
				aprBean.setFycqtr3(validatePolicyData(aprPayloadResponse.get("fycqtr3")));
				aprBean.setFycqtr4(validatePolicyData(aprPayloadResponse.get("fycqtr4")));
				aprBean.setMtdProtectionUpdateNop(validatePolicyData(aprPayloadResponse.get("mtdProtectionUpdateNop")));
				aprBean.setMtdProtectionUpdateWfyp(
						validatePolicyData(aprPayloadResponse.get("mtdProtectionUpdateWfyp")));
				aprBean.setMtdProtectionUpdateAdjMfyp(
						validatePolicyData(aprPayloadResponse.get("mtdProtectionUpdateAdjMfyp")));
				aprBean.setYtdProtectionUpdateNop(validatePolicyData(aprPayloadResponse.get("ytdProtectionUpdateNop")));
				aprBean.setYtdProtectionUpdateWfyp(
						validatePolicyData(aprPayloadResponse.get("ytdProtectionUpdateWfyp")));
				aprBean.setYtdProtectionUpdateAdjMfyp(
						validatePolicyData(aprPayloadResponse.get("ytdProtectionUpdateAdjMfyp")));
				aprBean.setRenewalBusiUpdtCollectible(
						validatePolicyData(aprPayloadResponse.get("renewalBusiUpdtCollectible")));
				aprBean.setRenewalBusiUpdtCollected(
						validatePolicyData(aprPayloadResponse.get("renewalBusiUpdtCollected")));
				aprBean.setRenewalBusiUpdt13mPersis(
						validatePolicyData(aprPayloadResponse.get("renewalBusiUpdt13mPersis")));
				aprBean.setEarlySuccessTotalAgents(
						validatePolicyData(aprPayloadResponse.get("earlySuccessTotalAgents")));
				aprBean.setEarlySuccessSinceInception(
						validatePolicyData(aprPayloadResponse.get("earlySuccessSinceInception")));
				aprBean.setEarlySuccessCurrentFy(validatePolicyData(aprPayloadResponse.get("earlySuccessCurrentFy")));
				aprBean.setEarlySuccessCurrentMonth(
						validatePolicyData(aprPayloadResponse.get("earlySuccessCurrentMonth")));
				aprBean.setMtdProactiveAgents(validatePolicyData(aprPayloadResponse.get("mtdProactiveAgents")));
				aprBean.setYtdProactiveAgents(validatePolicyData(aprPayloadResponse.get("ytdProactiveAgents")));
				aprBean.setFycShortfall(validatePolicyData(aprPayloadResponse.get("fycShortfall")));
				aprBean.setActivityTotalMM(validatePolicyData(aprPayloadResponse.get("activityTotalMM")));
				aprBean.setActivityMtdActive(validatePolicyData(aprPayloadResponse.get("activityMtdActive")));
				aprBean.setActivityYtdActive(validatePolicyData(aprPayloadResponse.get("activityYtdActive")));
				aprBean.setQrTargetMtd(validatePolicyData(aprPayloadResponse.get("qrTargetMtd")));
				aprBean.setAgentsQualifiedNineIn90(
						validatePolicyData(aprPayloadResponse.get("agentsQualifiedNineIn90")));
				aprBean.setProbableAgents(validatePolicyData(aprPayloadResponse.get("probableAgents")));
				aprBean.setGetGoingAgents(validatePolicyData(aprPayloadResponse.get("getGoingAgents")));
				aprBean.setYtdFyc(validatePolicyData(aprPayloadResponse.get("ytdFyc")));
				aprBean.setActualQr(validatePolicyData(aprPayloadResponse.get("actualQr")));
			}
		} catch (Exception ex) {
			logger.error(ex);
		}
		return aprBean;
	}

	private String validatePolicyData(Object object) {
		String policyStatus = "";
		try {
			if (object != null && !(object.toString().isEmpty())) {
				policyStatus = object.toString();
			}

		} catch (Exception ex) {
			logger.error(ex);
		}
		return policyStatus;
	}

	public String toBePopulateAgentList(String object) {
		StringBuilder agentList =new StringBuilder();
		JSONObject jSONObject = null;
		try {
			if (object != null) {
				jSONObject = new JSONObject(object);
				JSONObject payLoad = jSONObject.getJSONObject("payload");
				JSONArray array = (JSONArray)payLoad.get("agentDetails");
				for(int i=0;i<array.length();i++)
				{
					JSONObject jsonobj = (JSONObject)array.get(i);
					String agentid = jsonobj.get("agentId").toString();
					String agentName = jsonobj.get("agentName").toString();
					String agentDesignation = jsonobj.get("agentDesignationCode").toString();
					agentList.append(agentName+"-"+agentid+"-"+agentDesignation);
					if(i<array.length()-1)
					{
						agentList.append("|");
					}
					
				}
			}
		} catch (Exception ex) {
			logger.error(ex);
		}
		return agentList.toString();
	}

}
