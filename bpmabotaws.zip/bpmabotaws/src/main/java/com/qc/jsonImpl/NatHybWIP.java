package com.qc.jsonImpl;

import org.json.JSONObject;

import com.qc.dataBean.NatHybWipBean;

public class NatHybWIP 
{
	public static NatHybWipBean wipBean = new NatHybWipBean();
	public void natHybWip(JSONObject object)
	{
		try{
			wipBean.setNativ_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_ho_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_ho_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_go_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_go_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_it_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_it_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_fin_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_fin_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_misc_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_misc_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_welcome_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_welcome_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_ho_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_ho_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_go_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_go_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_it_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_it_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_fin_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_fin_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_misc_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_misc_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_welcome_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_welcome_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_ho_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_ho_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_go_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_go_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_it_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_it_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_fin_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_fin_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_misc_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_misc_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_welcome_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_welcome_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setNativ_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("nativ_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_ho_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_ho_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_go_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_go_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_it_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_it_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_fin_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_fin_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_misc_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_misc_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_welcome_wip_afyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_welcome_wip_afyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_ho_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_ho_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_go_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_go_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_it_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_it_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_fin_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_fin_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_misc_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_misc_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_welcome_wip_count(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_welcome_wip_count").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_ho_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_ho_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_go_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_go_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_it_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_it_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_fin_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_fin_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_misc_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_misc_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_welcome_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_welcome_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setHybrd_wip_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybWip").get("hybrd_wip_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			wipBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("natHybWip").get("real_tim_timstamp").toString());
		}catch(Exception e){}
	}
}
