package com.qc.jsonImpl;

import org.json.JSONObject;

import com.qc.dataBean.NatHybGrowthBean;

public class NatHybGrowth 
{
	public static NatHybGrowthBean growthBean = new NatHybGrowthBean();
	public void natHybGrowth(JSONObject object)
	{
		try{
			growthBean.setN_grh_lst_yr_inforced_cnt_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grh_lst_yr_inforced_cnt_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_ytd_inforced_cnt(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_ytd_inforced_cnt").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_year_inforced_cnt_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_year_inforced_cnt_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lst_yr_inforced_cnt_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lst_yr_inforced_cnt_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_mtd_inforced_cnt(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_mtd_inforced_cnt").toString());
		}catch(Exception e){}
	
		try{
			growthBean.setN_prev_year_inforced_cnt_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_year_inforced_cnt_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lst_yr_sm_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lst_yr_sm_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_ytd_inforced_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_ytd_inforced_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_year_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_year_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lst_yr_sm_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lst_yr_sm_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_mtd_inforced_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_mtd_inforced_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_year_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_year_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lst_yr_sm_adj_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lst_yr_sm_adj_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_ytd_inforced_adj_afyp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_ytd_inforced_adj_afyp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_year_adj_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_year_adj_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lst_yr_sm_adj_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lst_yr_sm_adj_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_mtd_inforced_adj_afyp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_mtd_inforced_adj_afyp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_year_adj_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_year_adj_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_btch_timstamp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_btch_timstamp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_real_tim_timstamp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_real_tim_timstamp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_rpev_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_rpev_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lpc_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lpc_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_lpc_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_lpc_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_lpc_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_lpc_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grh_lpc_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grh_lpc_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_lpc_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_lpc_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prv_lpc_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prv_lpc_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lpc_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lpc_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_curr_lpc_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_curr_lpc_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_lpc_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_lpc_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lpc_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lpc_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_lpc_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_lpc_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_lpc_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_lpc_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lpc_paid_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lpc_paid_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_lpc_paid_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_lpc_paid_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_lpc_paid_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_lpc_paid_adj_mfyp_mtd").toString());
		}catch(Exception e){}

		try{
			growthBean.setN_grth_recruitment_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_recruitment_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_recruitment_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_recruitment_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_recruitment_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_recruitment_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_case_size_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_case_size_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_case_size_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_case_size_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_case_size_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_case_size_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_prod_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_prod_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prod_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prod_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_prod_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_prod_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_prod_mix_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_prod_mix_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prod_mix_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prod_mix_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_prod_mix_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_prod_mix_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_mode_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_mode_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_mode_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_mode_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_mode_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_mode_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_rpev_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_rpev_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lpc_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lpc_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_lpc_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_lpc_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_lpc_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_lpc_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grh_lpc_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grh_lpc_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_lpc_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_lpc_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prv_lpc_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prv_lpc_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lpc_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lpc_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_curr_lpc_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_curr_lpc_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_lpc_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_lpc_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lpc_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lpc_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_lpc_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_lpc_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_lpc_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_lpc_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_lpc_paid_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_lpc_paid_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_lpc_paid_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_lpc_paid_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_lpc_paid_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_lpc_paid_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_recruitment_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_recruitment_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_recruitment_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_recruitment_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_recruitment_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_recruitment_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_case_size_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_case_size_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_case_size_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_case_size_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_case_size_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_case_size_afyp_ytd").toString());
		}catch(Exception e){}

		try{
			growthBean.setN_grth_prod_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_prod_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prod_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prod_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_prod_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_prod_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_prod_mix_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_prod_mix_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prod_mix_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prod_mix_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_prod_mix_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_prod_mix_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_mode_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_mode_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_mode_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_mode_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_mode_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_mode_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_mode_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_mode_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_mtd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_mtd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_mtd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_mtd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_mtd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_mtd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_ytd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_ytd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_ytd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_ytd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_ytd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_ytd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_proactive_agents_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_proactive_agents_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_proactive_agents_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_proactive_agents_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_proactive_agents_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_proactive_agents_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_grth_proactive_agents_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_grth_proactive_agents_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_proactive_agents_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_proactive_agents_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setN_prev_proactive_agents_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("n_prev_proactive_agents_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lst_yr_inforced_cnt_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lst_yr_inforced_cnt_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_ytd_inforced_cnt(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_ytd_inforced_cnt").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_year_inforced_cnt_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_year_inforced_cnt_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lst_yr_inforced_cnt_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lst_yr_inforced_cnt_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_mtd_inforced_cnt(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_mtd_inforced_cnt").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_year_inforced_cnt_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_year_inforced_cnt_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lst_yr_sm_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lst_yr_sm_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_ytd_inforced_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_ytd_inforced_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_year_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_year_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lst_yr_sm_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lst_yr_sm_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_mtd_inforced_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_mtd_inforced_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_year_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_year_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lst_yr_sm_adj_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lst_yr_sm_adj_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_ytd_inforced_adj_afyp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_ytd_inforced_adj_afyp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_year_adj_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_year_adj_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lst_yr_sm_adj_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lst_yr_sm_adj_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_mtd_inforced_adj_afyp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_mtd_inforced_adj_afyp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_year_adj_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_year_adj_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_btch_timstamp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_btch_timstamp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_real_tim_timstamp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_real_tim_timstamp").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_rpev_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_rpev_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lpc_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lpc_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_lpc_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_lpc_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_lpc_applied_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_lpc_applied_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grh_lpc_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grh_lpc_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_lpc_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_lpc_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prv_lpc_applied_adj_ifyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prv_lpc_applied_adj_ifyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lpc_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lpc_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_curr_lpc_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_curr_lpc_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_lpc_applied_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_lpc_applied_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lpc_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lpc_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_lpc_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_lpc_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_lpc_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_lpc_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lpc_paid_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lpc_paid_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_lpc_paid_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_lpc_paid_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_lpc_paid_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_lpc_paid_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_recruitment_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_recruitment_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_recruitment_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_recruitment_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_recruitment_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_recruitment_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_case_size_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_case_size_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_case_size_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_case_size_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_case_size_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_case_size_afyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_prod_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_prod_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prod_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prod_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_prod_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_prod_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_prod_mix_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_prod_mix_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prod_mix_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prod_mix_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_prod_mix_paid_cases_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_prod_mix_paid_cases_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_mode_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_mode_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_mode_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_mode_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_mode_mix_adj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_mode_mix_adj_mfyp_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_rpev_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_rpev_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lpc_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lpc_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_lpc_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_lpc_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_lpc_applied_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_lpc_applied_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grh_lpc_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grh_lpc_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_lpc_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_lpc_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prv_lpc_applied_adj_ifyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prv_lpc_applied_adj_ifyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lpc_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lpc_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_curr_lpc_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_curr_lpc_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_lpc_applied_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_lpc_applied_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lpc_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lpc_paid_cases_ytd").toString());
		}catch(Exception e){}
		

		try{
			growthBean.setH_lpc_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_lpc_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_lpc_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_lpc_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_lpc_paid_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_lpc_paid_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_lpc_paid_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_lpc_paid_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_lpc_paid_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_lpc_paid_adj_mfyp_ytd").toString());
		}catch(Exception e){}

		try{
			growthBean.setH_grth_recruitment_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_recruitment_ytd").toString());
		}catch(Exception e){}
		
		
		try{
			growthBean.setH_recruitment_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_recruitment_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_recruitment_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_recruitment_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_case_size_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_case_size_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_case_size_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_case_size_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_case_size_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_case_size_afyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_prod_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_prod_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prod_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prod_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_prod_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_prod_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_prod_mix_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_prod_mix_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prod_mix_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prod_mix_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_prod_mix_paid_cases_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_prod_mix_paid_cases_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_mode_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_mode_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}

		try{
			growthBean.setH_mode_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_mode_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_mode_mix_adj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_mode_mix_adj_mfyp_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_mtd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_mtd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_mtd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_mtd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_mtd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_mtd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_ytd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_ytd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_ytd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_ytd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_ytd_case_active(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_ytd_case_active").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_proactive_agents_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_proactive_agents_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_proactive_agents_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_proactive_agents_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_proactive_agents_mtd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_proactive_agents_mtd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_grth_proactive_agents_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_grth_proactive_agents_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_proactive_agents_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_proactive_agents_ytd").toString());
		}catch(Exception e){}
		
		try{
			growthBean.setH_prev_proactive_agents_ytd(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("h_prev_proactive_agents_ytd").toString());
		}catch(Exception e){}
		try{
			growthBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("natHybGrowth").get("real_tim_timstamp").toString());
		}catch(Exception e){}
	}
}
