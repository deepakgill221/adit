package com.qc.jsonImpl;

import org.json.JSONObject;

import com.qc.dataBean.NatHybPenetrationBean;

public class NatHybPenetration 
{
	public static NatHybPenetrationBean penetrationBean = new NatHybPenetrationBean();
	public void natHybPenetration(JSONObject object)
	{
		try{
			penetrationBean.setNt_mtd_inforced_count(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_mtd_inforced_count").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_mtd_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_mtd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ytd_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ytd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ytd_inforced_count(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ytd_inforced_count").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_trad_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_trad_penet_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_trad_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_trad_penet_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_trad_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_trad_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_trad_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_trad_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_trad_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_trad_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_trad_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_trad_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_trad_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_trad_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_trad_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_trad_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_penet_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_penet_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_penet_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_penet_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_penet_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_penet_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setNt_nonpar_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_penet_mtd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setNt_protec_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_penet_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_mtd_inforced_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_mtd_inforced_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ytd_inforced_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ytd_inforced_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setNt_ul_penet_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_penet_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_penet_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_penet_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_ul_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_ul_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setNt_par_penet_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_penet_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_penet_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_penet_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_par_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_par_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_penet_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_penet_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_penet_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_penet_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_nonpar_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_nonpar_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_penet_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_penet_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_penet_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_penet_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setNt_protec_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("nt_protec_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_mtd_inforced_count(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_mtd_inforced_count").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_mtd_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_mtd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_ytd_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ytd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_ytd_inforced_count(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ytd_inforced_count").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_trad_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_trad_penet_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_trad_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_trad_penet_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_trad_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_trad_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_trad_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_trad_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_trad_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_trad_mtd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_trad_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_trad_ytd_afyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_trad_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_trad_mtd_pol_cnt").toString());
		}catch(Exception e){}

		try{
			penetrationBean.setHy_trad_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_trad_ytd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_penet_mtd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_penet_ytd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_mtd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_ytd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_mtd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_ytd_pol_cnt").toString());
		}catch(Exception e){}

		try{
			penetrationBean.setHy_par_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_penet_mtd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_par_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_penet_ytd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_par_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_par_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_par_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_mtd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_par_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_ytd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_par_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_mtd_pol_cnt").toString());
		}catch(Exception e){}

		try{
			penetrationBean.setHy_par_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_ytd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_penet_mtd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_penet_ytd_afyp").toString());
		}catch(Exception e){}

		try{
			penetrationBean.setHy_nonpar_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_mtd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_ytd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_mtd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_ytd_pol_cnt").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_protec_penet_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_penet_mtd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_protec_penet_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_penet_ytd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_protec_penet_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_penet_mtd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_protec_penet_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_penet_ytd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_protec_mtd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_mtd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_protec_ytd_afyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_ytd_afyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_protec_mtd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_mtd_pol_cnt").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_protec_ytd_pol_cnt(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_ytd_pol_cnt").toString());
		}catch(Exception e){}

		try{
			penetrationBean.setHy_mtd_inforced_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_mtd_inforced_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ytd_inforced_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ytd_inforced_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_penet_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_penet_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_penet_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_penet_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_ul_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_ul_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setHy_par_penet_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_penet_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_par_penet_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_penet_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_par_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_par_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_par_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_penet_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_penet_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_penet_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_penet_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_nonpar_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_nonpar_ytd_adj_mfyp").toString());
		}catch(Exception e){}

		try{
			penetrationBean.setHy_protec_penet_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_penet_mtd_adj_mfyp").toString());
		}catch(Exception e){}


		try{
			penetrationBean.setHy_protec_penet_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_penet_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_protec_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		
		try{
			penetrationBean.setHy_protec_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("hy_protec_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			penetrationBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("natHybPenetration").get("real_tim_timstamp").toString());
		}catch(Exception e){}
	}
}
