package com.qc.api.service;

public interface SendMailService {

	public byte[] convertPdfToByteArray(String source); 
	public boolean sendMail(String byteArray,String mailTo,String username);
	public  String camelCase(String inputString);
	
}
