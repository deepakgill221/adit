package com.qc.api.service;


import com.qc.api.response.WebhookResponse;

public interface APIConsumerService {
	
	public WebhookResponse getWipDataAll(String action, String channel, String period, String productType, String planType,
			String userSsoid, String userSubChannel, String userDesignationDesc, 
			String userGetZone, String userRegion, String userCircle, String userClusters, String userGo, String userCmo, 
			String userAmo, String kpiAsked, String sessionId, String source, String employeeIdentification, String policyNumber, 
			String agentId, String emailId, String user_superzone, String user_keyMarket);
	
}



