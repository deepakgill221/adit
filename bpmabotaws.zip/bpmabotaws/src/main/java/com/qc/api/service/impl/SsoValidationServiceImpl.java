package com.qc.api.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.OtpVarificationService;
import com.qc.api.service.SsoValidationService;
import com.qc.controller.MliBotController;
import com.qc.utils.XTrustProvider;

@Service
public class SsoValidationServiceImpl implements SsoValidationService
{
	private static Logger logger = LogManager.getLogger(SsoValidationServiceImpl.class);
	ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");
	HttpURLConnection conn = null;
	
	@Autowired private OtpVarificationService otpVarificationService;
	public Map<String, Map<String, String>> APICallSSOValidation(String ssoId, String sessionId,String actionperformed, Map<String, Map<String, String>> sessionMapcontainssoinfo)
	{
		logger.info("START :- Inside : - APICallSSOValidation :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
		String phoneNo = "", agentName = "", DevMode = "N", mnylstatus = "";
        String agentId="";String emailId ="",agentCode="";
		String output = new String();
		StringBuilder result = new StringBuilder();
		Map<String, Map<String, String>> cashData = null;
		int apiResponseCode3=0;
		MliBotController mliBotController = new MliBotController();
		Map<String, String> blankmessage = new HashMap<String, String>();
		
		try 
		{
			if(!"nb.integrate".equalsIgnoreCase(actionperformed))
			{

				XTrustProvider trustProvider = new XTrustProvider();
				trustProvider.install();
				StringBuilder requestdata = new StringBuilder();
				String serviceurl3 = res.getString("serviceproduction");
				URL url3 = new URL(serviceurl3);
				UUID uniqueId = UUID.randomUUID();
				if (DevMode != null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode)) {
					Proxy proxy = new Proxy(Proxy.Type.HTTP,
							new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
					conn = (HttpURLConnection) url3.openConnection(proxy);
				} else {
					conn = (HttpURLConnection) url3.openConnection();
				}
				//UUID uniqueId = UUID.randomUUID();
				HttpsURLConnection.setFollowRedirects(true);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");
				requestdata.append("	{	");
				requestdata.append("	    \"request\": {	");
				requestdata.append("	        \"header\": {	");
				requestdata.append("	            \"soaCorrelationId\": \""+uniqueId+"\",	");
				requestdata.append("	            \"soaMsgVersion\": \"1.0\",	");
				requestdata.append("	            \"soaAppId\": \"MISBOT\",	");
				requestdata.append("	            \"soaUserId\": \"MISBOTPROD123\",	");
				requestdata.append("	            \"soaPassword\": \"cGFzd29yZDU=\"	");
				requestdata.append("	        },	");
				requestdata.append("	        \"requestData\": {	");
				requestdata.append("	            \"requestPayload\": {	");
				requestdata.append("	                \"transactions\": [	");
				requestdata.append("	                    {	");
				requestdata.append("	                        \"ssoId\": \"" + ssoId + "\"");
				requestdata.append("	                    }	");
				requestdata.append("	                ]	");
				requestdata.append("	            }	");
				requestdata.append("	        }	");
				requestdata.append("	    }	");
				requestdata.append("	}	");
				logger.info("OutputStream call : START ::: APICallSSOValidation :- SSOID:- "+ssoId);
				OutputStreamWriter writer3 = new OutputStreamWriter(conn.getOutputStream());
				writer3.write(requestdata.toString());
				writer3.flush();
				try {
					writer3.close();
				} catch (Exception e1) {
				}
				logger.info("OutputStream call : END ::: APICallSSOValidation :- SSOID:- "+ssoId);
				apiResponseCode3 = conn.getResponseCode();
				logger.info("Response Code :- "+ apiResponseCode3+ " SSOID:- "+ssoId);
			}
			else
			{
				
				apiResponseCode3 = nbIntegrationValidation( DevMode,  ssoId, apiResponseCode3);
				String channel = null;
				if (apiResponseCode3 == 200) 
				{
					
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					while ((output = br.readLine()) != null) {
						result.append(output);
					}
					conn.disconnect();
					br.close();
					JSONObject object = new JSONObject(result.toString());
					try {
						channel = object.getJSONObject("response").getJSONObject("responseData")
								.getJSONArray("Transactions").getJSONObject(0).get("mnyldepartmentgpname") + "";
						agentId = object.getJSONObject("response").getJSONObject("responseData")
								.getJSONArray("Transactions").getJSONObject(0).get("mnylagentcode") + "";
						emailId = object.getJSONObject("response").getJSONObject("responseData")
								.getJSONArray("Transactions").getJSONObject(0).get("mnylofficialemail") + "";
						agentCode = object.getJSONObject("response").getJSONObject("responseData")
								.getJSONArray("Transactions").getJSONObject(0).get("mnylmyagentrolecode") + "";
						agentName = object.getJSONObject("response").getJSONObject("responseData")
								.getJSONArray("Transactions").getJSONObject(0).get("mnyldisplayname") + "";
						logger.info(" SSOID:- "+ssoId + " mnylstatus : - "+mnylstatus + " SessionId :-"+sessionId);
					}catch(Exception ex) {
						}
					}
				blankmessage.put("agentCode", agentCode);
				blankmessage.put("channel", channel);
				blankmessage.put("agentId", agentId);
				blankmessage.put("emailId", emailId);
				blankmessage.put("agentName", agentName);
				blankmessage.put("Validation", "Success");
				blankmessage.put("validSSOID",  ssoId);
				sessionMapcontainssoinfo.put(sessionId, blankmessage);
				cashData = sessionMapcontainssoinfo;
				return cashData;
			}
			if (apiResponseCode3 == 200) 
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
				JSONObject object = new JSONObject(result.toString());
				try {
					phoneNo = object.getJSONObject("response").getJSONObject("responseData")
							.getJSONArray("Transactions").getJSONObject(0).get("mnylpreferredmobile") + "";
					mnylstatus = object.getJSONObject("response").getJSONObject("responseData")
							.getJSONArray("Transactions").getJSONObject(0).get("mnylstatus") + "";
					agentName = object.getJSONObject("response").getJSONObject("responseData")
							.getJSONArray("Transactions").getJSONObject(0).get("givenname") + "";
					agentId = object.getJSONObject("response").getJSONObject("responseData")
							.getJSONArray("Transactions").getJSONObject(0).get("mnylagentcode") + "";
					emailId = object.getJSONObject("response").getJSONObject("responseData")
							.getJSONArray("Transactions").getJSONObject(0).get("mail") + "";
					logger.info(" SSOID:- "+ssoId + " mnylstatus : - "+mnylstatus + " SessionId :-"+sessionId);

					if("nb.validate".equalsIgnoreCase(actionperformed))
					{
						logger.info("START Calling OTPVarification API SSOID :-"+ssoId);
						cashData = otpVarificationService.OTPVarification(sessionId, phoneNo, agentName, ssoId, actionperformed,sessionMapcontainssoinfo,agentId,emailId);
						logger.info("END Calling OTPVarification API SSOID :-"+ssoId);
					}
					else if (phoneNo != null && !"".equalsIgnoreCase(phoneNo) && mnylstatus != null
							&& !"".equalsIgnoreCase(mnylstatus) && ("ACTIVE".equalsIgnoreCase(mnylstatus)||"Y".equalsIgnoreCase(mnylstatus)))
					{
						logger.info("START Calling OTPVarification API SSOID :-"+ssoId);
						cashData = otpVarificationService.OTPVarification(sessionId, phoneNo, agentName, ssoId, actionperformed,sessionMapcontainssoinfo,agentId,emailId);
						logger.info("END Calling OTPVarification API SSOID :-"+ssoId);

					}
					else
					{
						blankmessage.put("PhoneStatus", phoneNo);
						blankmessage.put("mnylStatus",  mnylstatus);
						sessionMapcontainssoinfo.put(sessionId, blankmessage);
						cashData = sessionMapcontainssoinfo;
					}
				} catch (Exception e) {
					logger.info("Exception in calling OTP varification API :: "+ e);
				}
				logger.info("External API Call : END ::: APICallSSOValidation");

			} else {
				blankmessage.put("SoaStatus", "Failure_API_1");
				sessionMapcontainssoinfo.put(sessionId, blankmessage);
				cashData = sessionMapcontainssoinfo;
			}
		} catch (Exception ex)
		{
			logger.info("Error in method APICallSSOValidation :: "+ex);
			blankmessage.put("SoaStatus", "Failure_API_1");
			sessionMapcontainssoinfo.put(sessionId, blankmessage);
			cashData = sessionMapcontainssoinfo;
		}
		logger.info("END :- OutSide : - APICallSSOValidation :- SSOID:- "+ssoId+" SessionId :-"+sessionId);
		return cashData;
	}
	
	public int nbIntegrationValidation(String DevMode, String ssoId,int apiResponseCode3) {
		try {
		XTrustProvider trustProvider = new XTrustProvider();
		trustProvider.install();
		StringBuilder requestdata = new StringBuilder();
		String serviceurl3 = res.getString("serviceproduction");
		URL url3 = new URL(serviceurl3);
		UUID uniqueId = UUID.randomUUID();
		if (DevMode != null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode)) {
			Proxy proxy = new Proxy(Proxy.Type.HTTP,
					new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
			conn = (HttpURLConnection) url3.openConnection(proxy);
		} else {
			conn = (HttpURLConnection) url3.openConnection();
		}
		//UUID uniqueId = UUID.randomUUID();
		HttpsURLConnection.setFollowRedirects(true);
		conn.setDoInput(true);
		conn.setDoOutput(true);
		conn.setRequestMethod("POST");
		conn.setRequestProperty("Content-Type", "application/json");
		requestdata.append("	{	");
		requestdata.append("	    \"request\": {	");
		requestdata.append("	        \"header\": {	");
		requestdata.append("	            \"soaCorrelationId\": \""+uniqueId+"\",	");
		requestdata.append("	            \"soaMsgVersion\": \"1.0\",	");
		requestdata.append("	            \"soaAppId\": \"MISBOT\",	");
		requestdata.append("	            \"soaUserId\": \"MISBOTPROD123\",	");
		requestdata.append("	            \"soaPassword\": \"cGFzd29yZDU=\"	");
		requestdata.append("	        },	");
		requestdata.append("	        \"requestData\": {	");
		requestdata.append("	            \"requestPayload\": {	");
		requestdata.append("	                \"transactions\": [	");
		requestdata.append("	                    {	");
		requestdata.append("	                        \"ssoId\": \"" + ssoId + "\"");
		requestdata.append("	                    }	");
		requestdata.append("	                ]	");
		requestdata.append("	            }	");
		requestdata.append("	        }	");
		requestdata.append("	    }	");
		requestdata.append("	}	");
		logger.info("OutputStream call : START ::: nbIntegrationValidation :- SSOID:- "+ssoId);
		OutputStreamWriter writer3 = new OutputStreamWriter(conn.getOutputStream());
		writer3.write(requestdata.toString());
		writer3.flush();
		try {
			writer3.close();
		} catch (Exception e1) {
		}
		logger.info("OutputStream call : END ::: nbIntegrationValidation :- SSOID:- "+ssoId);
		apiResponseCode3 = conn.getResponseCode();
		logger.info("Response Code :- "+ apiResponseCode3+ " SSOID:- "+ssoId);
		}catch(Exception ex) {
			logger.info("Error in method nbIntegrationValidation :: "+ex);
		}
		return apiResponseCode3;
	}
	
}
