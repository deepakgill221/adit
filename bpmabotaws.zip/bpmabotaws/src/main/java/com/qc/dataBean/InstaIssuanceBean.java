package com.qc.dataBean;

public class InstaIssuanceBean {
	
	private String designationDesc;
	private String channel;
	private String subChannel;
	private String superZone;
	private String zone;
	private String region;
	private String keyMarket;
	private String circle;
	private String clusters;
	private String go;
	private String cmo;
	private String amo;
	private String iiNpNmNopAllMtd;
	private String iiNpNmAdjMfypAllMtd;
	private String iiNpNmNop6hMtd;
	private String iiNpNmAdjMfyp6hMtd;
	private String iiNpNmNop12hMtd;
	private String iiNpNmAdjMfyp12hMtd;
	private String iiNpNmNop24hMtd;
	private String iiNpNmAdjMfyp24hMtd;
	private String iiNpMnmNopAllMtd;
	private String iiNpMnmAdjMfypAllMtd;
	private String iiNpMnmNop6hMtd;
	private String iiNpMnmAdjMfyp6hMtd;
	private String iiNpMnmNop12hMtd;
	private String iiNpMnmAdjMfyp12hMtd;
	private String iiNpMnmNop24hMtd;
	private String iiNpMnmAdjMfyp24hMtd;
	private String iiNpNmNopAllFtd;
	private String iiNpNmAdjMfypAllFtd;
	private String iiNpNmNop6hFtd;
	private String iiNpNmAdjMfyp6hFtd;
	private String iiNpNmNop12hFtd;
	private String iiNpNmAdjMfyp12hFtd;
	private String iiNpNmNop24hFtd;
	private String iiNpNmAdjMfyp24hFtd;
	private String iiNpMnmNopAllFtd;
	private String iiNpMnmAdjMfypAllFtd;
	private String iiNpMnmNop6hFtd;
	private String iiNpMnmAdjMfyp6hFtd;
	private String iiNpMnmNop12hFtd;
	private String iiNpMnmAdjMfyp12hFtd;
	private String iiNpMnmNop24hFtd;
	private String iiNpMnmAdjMfyp24hFtd;
	private String iiNpNmNopAllYtd;
	private String iiNpNmAdjMfypAllYtd;
	private String iiNpNmNop6hYtd;
	private String iiNpNmAdjMfyp6hYtd;
	private String iiNpNmNop12hYtd;
	private String iiNpNmAdjMfyp12hYtd;
	private String iiNpNmNop24hYtd;
	private String iiNpNmAdjMfyp24hYtd;
	private String iiNpMnmNopAllYtd;
	private String iiNpMnmAdjMfypAllYtd;
	private String iiNpMnmNop6hYtd;
	private String iiNpMnmAdjMfyp6hYtd;
	private String iiNpMnmNop12hYtd;
	private String iiNpMnmAdjMfyp12hYtd;
	private String iiNpMnmNop24hYtd;
	private String iiNpMnmAdjMfyp24hYtd;
	private String iiTimeStamp;              
	private String column1;
	private String column2;
	private String column3;
	private String column4;
	private String column5;
	
	public String getDesignationDesc() {
		return designationDesc;
	}
	public void setDesignationDesc(String designationDesc) {
		this.designationDesc = designationDesc;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSubChannel() {
		return subChannel;
	}
	public void setSubChannel(String subChannel) {
		this.subChannel = subChannel;
	}
	public String getSuperZone() {
		return superZone;
	}
	public void setSuperZone(String superZone) {
		this.superZone = superZone;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getKeyMarket() {
		return keyMarket;
	}
	public void setKeyMarket(String keyMarket) {
		this.keyMarket = keyMarket;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getClusters() {
		return clusters;
	}
	public void setClusters(String clusters) {
		this.clusters = clusters;
	}
	public String getGo() {
		return go;
	}
	public void setGo(String go) {
		this.go = go;
	}
	public String getCmo() {
		return cmo;
	}
	public void setCmo(String cmo) {
		this.cmo = cmo;
	}
	public String getAmo() {
		return amo;
	}
	public void setAmo(String amo) {
		this.amo = amo;
	}
	public String getIiNpNmNopAllMtd() {
		return iiNpNmNopAllMtd;
	}
	public void setIiNpNmNopAllMtd(String iiNpNmNopAllMtd) {
		this.iiNpNmNopAllMtd = iiNpNmNopAllMtd;
	}
	public String getIiNpNmAdjMfypAllMtd() {
		return iiNpNmAdjMfypAllMtd;
	}
	public void setIiNpNmAdjMfypAllMtd(String iiNpNmAdjMfypAllMtd) {
		this.iiNpNmAdjMfypAllMtd = iiNpNmAdjMfypAllMtd;
	}
	public String getIiNpNmNop6hMtd() {
		return iiNpNmNop6hMtd;
	}
	public void setIiNpNmNop6hMtd(String iiNpNmNop6hMtd) {
		this.iiNpNmNop6hMtd = iiNpNmNop6hMtd;
	}
	public String getIiNpNmAdjMfyp6hMtd() {
		return iiNpNmAdjMfyp6hMtd;
	}
	public void setIiNpNmAdjMfyp6hMtd(String iiNpNmAdjMfyp6hMtd) {
		this.iiNpNmAdjMfyp6hMtd = iiNpNmAdjMfyp6hMtd;
	}
	public String getIiNpNmNop12hMtd() {
		return iiNpNmNop12hMtd;
	}
	public void setIiNpNmNop12hMtd(String iiNpNmNop12hMtd) {
		this.iiNpNmNop12hMtd = iiNpNmNop12hMtd;
	}
	public String getIiNpNmAdjMfyp12hMtd() {
		return iiNpNmAdjMfyp12hMtd;
	}
	public void setIiNpNmAdjMfyp12hMtd(String iiNpNmAdjMfyp12hMtd) {
		this.iiNpNmAdjMfyp12hMtd = iiNpNmAdjMfyp12hMtd;
	}
	public String getIiNpNmNop24hMtd() {
		return iiNpNmNop24hMtd;
	}
	public void setIiNpNmNop24hMtd(String iiNpNmNop24hMtd) {
		this.iiNpNmNop24hMtd = iiNpNmNop24hMtd;
	}
	public String getIiNpNmAdjMfyp24hMtd() {
		return iiNpNmAdjMfyp24hMtd;
	}
	public void setIiNpNmAdjMfyp24hMtd(String iiNpNmAdjMfyp24hMtd) {
		this.iiNpNmAdjMfyp24hMtd = iiNpNmAdjMfyp24hMtd;
	}
	public String getIiNpMnmNopAllMtd() {
		return iiNpMnmNopAllMtd;
	}
	public void setIiNpMnmNopAllMtd(String iiNpMnmNopAllMtd) {
		this.iiNpMnmNopAllMtd = iiNpMnmNopAllMtd;
	}
	public String getIiNpMnmAdjMfypAllMtd() {
		return iiNpMnmAdjMfypAllMtd;
	}
	public void setIiNpMnmAdjMfypAllMtd(String iiNpMnmAdjMfypAllMtd) {
		this.iiNpMnmAdjMfypAllMtd = iiNpMnmAdjMfypAllMtd;
	}
	public String getIiNpMnmNop6hMtd() {
		return iiNpMnmNop6hMtd;
	}
	public void setIiNpMnmNop6hMtd(String iiNpMnmNop6hMtd) {
		this.iiNpMnmNop6hMtd = iiNpMnmNop6hMtd;
	}
	public String getIiNpMnmAdjMfyp6hMtd() {
		return iiNpMnmAdjMfyp6hMtd;
	}
	public void setIiNpMnmAdjMfyp6hMtd(String iiNpMnmAdjMfyp6hMtd) {
		this.iiNpMnmAdjMfyp6hMtd = iiNpMnmAdjMfyp6hMtd;
	}
	public String getIiNpMnmNop12hMtd() {
		return iiNpMnmNop12hMtd;
	}
	public void setIiNpMnmNop12hMtd(String iiNpMnmNop12hMtd) {
		this.iiNpMnmNop12hMtd = iiNpMnmNop12hMtd;
	}
	public String getIiNpMnmAdjMfyp12hMtd() {
		return iiNpMnmAdjMfyp12hMtd;
	}
	public void setIiNpMnmAdjMfyp12hMtd(String iiNpMnmAdjMfyp12hMtd) {
		this.iiNpMnmAdjMfyp12hMtd = iiNpMnmAdjMfyp12hMtd;
	}
	public String getIiNpMnmNop24hMtd() {
		return iiNpMnmNop24hMtd;
	}
	public void setIiNpMnmNop24hMtd(String iiNpMnmNop24hMtd) {
		this.iiNpMnmNop24hMtd = iiNpMnmNop24hMtd;
	}
	public String getIiNpMnmAdjMfyp24hMtd() {
		return iiNpMnmAdjMfyp24hMtd;
	}
	public void setIiNpMnmAdjMfyp24hMtd(String iiNpMnmAdjMfyp24hMtd) {
		this.iiNpMnmAdjMfyp24hMtd = iiNpMnmAdjMfyp24hMtd;
	}
	public String getIiNpNmNopAllFtd() {
		return iiNpNmNopAllFtd;
	}
	public void setIiNpNmNopAllFtd(String iiNpNmNopAllFtd) {
		this.iiNpNmNopAllFtd = iiNpNmNopAllFtd;
	}
	public String getIiNpNmAdjMfypAllFtd() {
		return iiNpNmAdjMfypAllFtd;
	}
	public void setIiNpNmAdjMfypAllFtd(String iiNpNmAdjMfypAllFtd) {
		this.iiNpNmAdjMfypAllFtd = iiNpNmAdjMfypAllFtd;
	}
	public String getIiNpNmNop6hFtd() {
		return iiNpNmNop6hFtd;
	}
	public void setIiNpNmNop6hFtd(String iiNpNmNop6hFtd) {
		this.iiNpNmNop6hFtd = iiNpNmNop6hFtd;
	}
	public String getIiNpNmAdjMfyp6hFtd() {
		return iiNpNmAdjMfyp6hFtd;
	}
	public void setIiNpNmAdjMfyp6hFtd(String iiNpNmAdjMfyp6hFtd) {
		this.iiNpNmAdjMfyp6hFtd = iiNpNmAdjMfyp6hFtd;
	}
	public String getIiNpNmNop12hFtd() {
		return iiNpNmNop12hFtd;
	}
	public void setIiNpNmNop12hFtd(String iiNpNmNop12hFtd) {
		this.iiNpNmNop12hFtd = iiNpNmNop12hFtd;
	}
	public String getIiNpNmAdjMfyp12hFtd() {
		return iiNpNmAdjMfyp12hFtd;
	}
	public void setIiNpNmAdjMfyp12hFtd(String iiNpNmAdjMfyp12hFtd) {
		this.iiNpNmAdjMfyp12hFtd = iiNpNmAdjMfyp12hFtd;
	}
	public String getIiNpNmNop24hFtd() {
		return iiNpNmNop24hFtd;
	}
	public void setIiNpNmNop24hFtd(String iiNpNmNop24hFtd) {
		this.iiNpNmNop24hFtd = iiNpNmNop24hFtd;
	}
	public String getIiNpNmAdjMfyp24hFtd() {
		return iiNpNmAdjMfyp24hFtd;
	}
	public void setIiNpNmAdjMfyp24hFtd(String iiNpNmAdjMfyp24hFtd) {
		this.iiNpNmAdjMfyp24hFtd = iiNpNmAdjMfyp24hFtd;
	}
	public String getIiNpMnmNopAllFtd() {
		return iiNpMnmNopAllFtd;
	}
	public void setIiNpMnmNopAllFtd(String iiNpMnmNopAllFtd) {
		this.iiNpMnmNopAllFtd = iiNpMnmNopAllFtd;
	}
	public String getIiNpMnmAdjMfypAllFtd() {
		return iiNpMnmAdjMfypAllFtd;
	}
	public void setIiNpMnmAdjMfypAllFtd(String iiNpMnmAdjMfypAllFtd) {
		this.iiNpMnmAdjMfypAllFtd = iiNpMnmAdjMfypAllFtd;
	}
	public String getIiNpMnmNop6hFtd() {
		return iiNpMnmNop6hFtd;
	}
	public void setIiNpMnmNop6hFtd(String iiNpMnmNop6hFtd) {
		this.iiNpMnmNop6hFtd = iiNpMnmNop6hFtd;
	}
	public String getIiNpMnmAdjMfyp6hFtd() {
		return iiNpMnmAdjMfyp6hFtd;
	}
	public void setIiNpMnmAdjMfyp6hFtd(String iiNpMnmAdjMfyp6hFtd) {
		this.iiNpMnmAdjMfyp6hFtd = iiNpMnmAdjMfyp6hFtd;
	}
	public String getIiNpMnmNop12hFtd() {
		return iiNpMnmNop12hFtd;
	}
	public void setIiNpMnmNop12hFtd(String iiNpMnmNop12hFtd) {
		this.iiNpMnmNop12hFtd = iiNpMnmNop12hFtd;
	}
	public String getIiNpMnmAdjMfyp12hFtd() {
		return iiNpMnmAdjMfyp12hFtd;
	}
	public void setIiNpMnmAdjMfyp12hFtd(String iiNpMnmAdjMfyp12hFtd) {
		this.iiNpMnmAdjMfyp12hFtd = iiNpMnmAdjMfyp12hFtd;
	}
	public String getIiNpMnmNop24hFtd() {
		return iiNpMnmNop24hFtd;
	}
	public void setIiNpMnmNop24hFtd(String iiNpMnmNop24hFtd) {
		this.iiNpMnmNop24hFtd = iiNpMnmNop24hFtd;
	}
	public String getIiNpMnmAdjMfyp24hFtd() {
		return iiNpMnmAdjMfyp24hFtd;
	}
	public void setIiNpMnmAdjMfyp24hFtd(String iiNpMnmAdjMfyp24hFtd) {
		this.iiNpMnmAdjMfyp24hFtd = iiNpMnmAdjMfyp24hFtd;
	}
	public String getIiNpNmNopAllYtd() {
		return iiNpNmNopAllYtd;
	}
	public void setIiNpNmNopAllYtd(String iiNpNmNopAllYtd) {
		this.iiNpNmNopAllYtd = iiNpNmNopAllYtd;
	}
	public String getIiNpNmAdjMfypAllYtd() {
		return iiNpNmAdjMfypAllYtd;
	}
	public void setIiNpNmAdjMfypAllYtd(String iiNpNmAdjMfypAllYtd) {
		this.iiNpNmAdjMfypAllYtd = iiNpNmAdjMfypAllYtd;
	}
	public String getIiNpNmNop6hYtd() {
		return iiNpNmNop6hYtd;
	}
	public void setIiNpNmNop6hYtd(String iiNpNmNop6hYtd) {
		this.iiNpNmNop6hYtd = iiNpNmNop6hYtd;
	}
	public String getIiNpNmAdjMfyp6hYtd() {
		return iiNpNmAdjMfyp6hYtd;
	}
	public void setIiNpNmAdjMfyp6hYtd(String iiNpNmAdjMfyp6hYtd) {
		this.iiNpNmAdjMfyp6hYtd = iiNpNmAdjMfyp6hYtd;
	}
	public String getIiNpNmNop12hYtd() {
		return iiNpNmNop12hYtd;
	}
	public void setIiNpNmNop12hYtd(String iiNpNmNop12hYtd) {
		this.iiNpNmNop12hYtd = iiNpNmNop12hYtd;
	}
	public String getIiNpNmAdjMfyp12hYtd() {
		return iiNpNmAdjMfyp12hYtd;
	}
	public void setIiNpNmAdjMfyp12hYtd(String iiNpNmAdjMfyp12hYtd) {
		this.iiNpNmAdjMfyp12hYtd = iiNpNmAdjMfyp12hYtd;
	}
	public String getIiNpNmNop24hYtd() {
		return iiNpNmNop24hYtd;
	}
	public void setIiNpNmNop24hYtd(String iiNpNmNop24hYtd) {
		this.iiNpNmNop24hYtd = iiNpNmNop24hYtd;
	}
	public String getIiNpNmAdjMfyp24hYtd() {
		return iiNpNmAdjMfyp24hYtd;
	}
	public void setIiNpNmAdjMfyp24hYtd(String iiNpNmAdjMfyp24hYtd) {
		this.iiNpNmAdjMfyp24hYtd = iiNpNmAdjMfyp24hYtd;
	}
	public String getIiNpMnmNopAllYtd() {
		return iiNpMnmNopAllYtd;
	}
	public void setIiNpMnmNopAllYtd(String iiNpMnmNopAllYtd) {
		this.iiNpMnmNopAllYtd = iiNpMnmNopAllYtd;
	}
	public String getIiNpMnmAdjMfypAllYtd() {
		return iiNpMnmAdjMfypAllYtd;
	}
	public void setIiNpMnmAdjMfypAllYtd(String iiNpMnmAdjMfypAllYtd) {
		this.iiNpMnmAdjMfypAllYtd = iiNpMnmAdjMfypAllYtd;
	}
	public String getIiNpMnmNop6hYtd() {
		return iiNpMnmNop6hYtd;
	}
	public void setIiNpMnmNop6hYtd(String iiNpMnmNop6hYtd) {
		this.iiNpMnmNop6hYtd = iiNpMnmNop6hYtd;
	}
	public String getIiNpMnmAdjMfyp6hYtd() {
		return iiNpMnmAdjMfyp6hYtd;
	}
	public void setIiNpMnmAdjMfyp6hYtd(String iiNpMnmAdjMfyp6hYtd) {
		this.iiNpMnmAdjMfyp6hYtd = iiNpMnmAdjMfyp6hYtd;
	}
	public String getIiNpMnmNop12hYtd() {
		return iiNpMnmNop12hYtd;
	}
	public void setIiNpMnmNop12hYtd(String iiNpMnmNop12hYtd) {
		this.iiNpMnmNop12hYtd = iiNpMnmNop12hYtd;
	}
	public String getIiNpMnmAdjMfyp12hYtd() {
		return iiNpMnmAdjMfyp12hYtd;
	}
	public void setIiNpMnmAdjMfyp12hYtd(String iiNpMnmAdjMfyp12hYtd) {
		this.iiNpMnmAdjMfyp12hYtd = iiNpMnmAdjMfyp12hYtd;
	}
	public String getIiNpMnmNop24hYtd() {
		return iiNpMnmNop24hYtd;
	}
	public void setIiNpMnmNop24hYtd(String iiNpMnmNop24hYtd) {
		this.iiNpMnmNop24hYtd = iiNpMnmNop24hYtd;
	}
	public String getIiNpMnmAdjMfyp24hYtd() {
		return iiNpMnmAdjMfyp24hYtd;
	}
	public void setIiNpMnmAdjMfyp24hYtd(String iiNpMnmAdjMfyp24hYtd) {
		this.iiNpMnmAdjMfyp24hYtd = iiNpMnmAdjMfyp24hYtd;
	}
	public String getIiTimeStamp() {
		return iiTimeStamp;
	}
	public void setIiTimeStamp(String iiTimeStamp) {
		this.iiTimeStamp = iiTimeStamp;
	}
	public String getColumn1() {
		return column1;
	}
	public void setColumn1(String column1) {
		this.column1 = column1;
	}
	public String getColumn2() {
		return column2;
	}
	public void setColumn2(String column2) {
		this.column2 = column2;
	}
	public String getColumn3() {
		return column3;
	}
	public void setColumn3(String column3) {
		this.column3 = column3;
	}
	public String getColumn4() {
		return column4;
	}
	public void setColumn4(String column4) {
		this.column4 = column4;
	}
	public String getColumn5() {
		return column5;
	}
	public void setColumn5(String column5) {
		this.column5 = column5;
	}
	
	

}
