package com.qc.service.messageimpl;

import org.springframework.stereotype.Component;

import com.qc.dataBean.PolicyStatusBean;

//@Component
public class PolicyStatusMessage 
{
	String finalresponse="";
public String policyStatusIntent(PolicyStatusBean policyStatusBean)
{
	finalresponse= "The current status of Policy no. "+policyStatusBean.getPolicyNumber()+" is "+
                    "\n\nWorkitem: "+policyStatusBean.getWorkitemDescription()+""+
			        "\n\nCase Status: "+policyStatusBean.getPolicyStatusDesc()+""+
                    "\n\nPending Req.:"+policyStatusBean.getPendingRequirement()+""+
			        "\n\nTPP Comments: "+policyStatusBean.getTppComment();
	return finalresponse;
}
}
