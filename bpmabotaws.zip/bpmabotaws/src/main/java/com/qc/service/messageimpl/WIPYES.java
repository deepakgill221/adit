package com.qc.service.messageimpl;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.qc.jsonImpl.NatHybWIP;
public class WIPYES 
{
	public static String wipyesIntent(String channel, String msgChannel, String convertsum3, String convertsum4, double hoWIPAFYP,
			double ho_wip_count, double goWIPAFYP, double go_wip_count, double itWIPAFYP, double it_wip_count, double finWIPAFYP, 
			double fin_wip_count, double miscWIPAFYP, double misc_wip_count, double welcomeWIPAFYP, double welcome_wip_count,
			double ho_wip_adj_mfyp, double go_wip_adj_mfyp, double it_wip_adj_mfyp, double fin_wip_adj_mfyp, 
			double misc_wip_adj_mfyp, double welcome_wip_adj_mfyp, String LacsCr, 
			String userzone, String user_region, String user_circle, String user_clusters, String user_go)
	{

		Calendar cal = Calendar.getInstance(); // creates calendar
		cal.setTime(new Date()); // sets calendar time/date
		/*cal.add(Calendar.HOUR_OF_DAY, 5); // adds one hour
		cal.add(Calendar.MINUTE, 30);*/
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss aa");


		DecimalFormat df = new DecimalFormat("####");
		String finalresponse="";
		if(!"".equalsIgnoreCase(channel))
		{

			if("Agency".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
					&& "".equalsIgnoreCase(user_circle) && "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(user_go))
			{
				finalresponse="Current WIP as of "+dateFormat.format(cal.getTime())+
						" for "+msgChannel+" is "+convertsum4+" Policies with "+convertsum3+" "
						+  " " + LacsCr + ". Adj MFYP." // Do you wish to see the stage wise snapshot. "


						//+"WIP for "+msgChannel+" Adj MFYP :" +convertsum3+" " + LacsCr +". and Policies "+convertsum4+" "
						+"\n\n HO WIP Adj MFYP: "+ho_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(ho_wip_count)+" "
						+"\n\n GO WIP Adj MFYP: "+go_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(go_wip_count)+" "
						+"\n\n IT WIP Adj MFYP: "+it_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(it_wip_count)+" "
						+"\n\n FIN WIP Adj MFYP: "+fin_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(fin_wip_count)+" "
						+"\n\n MISC WIP Adj MFYP: "+misc_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(misc_wip_count)+" "
						+"\n\n WELCOME WIP Adj MFYP: "+welcome_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(welcome_wip_count)+""
						+ "If you want to see the data for sub-channels, "
						+ "please enter sub-channel name - Defence, Office within office, APC, Greenfield.";
			}

			else{
				if("Internet Sales".equalsIgnoreCase(msgChannel))
				{
					finalresponse=" Current WIP as of "+NatHybWIP.wipBean.getReal_tim_timstamp()+" for Native ecomm is "+NatHybWIP.wipBean.getNativ_wip_count()
					+" Policies with "+NatHybWIP.wipBean.getNativ_wip_adj_mfyp()+ " " + LacsCr + ". Adj MFYP.\n\n"
					+" Current WIP as of "+NatHybWIP.wipBean.getReal_tim_timstamp()+" for Hybrid ecomm is " +NatHybWIP.wipBean.getHybrd_wip_count()+" "
					+" Policies with "+NatHybWIP.wipBean.getHybrd_wip_adj_mfyp()+ " " + LacsCr + ". Adj MFYP."

							//+"WIP for "+msgChannel+" Adj MFYP :" +convertsum3+" " + LacsCr +". and Policies "+convertsum4+" "
							+"\n\n HO WIP Adj MFYP: "+ho_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(ho_wip_count)+" "
							+"\n\n GO WIP Adj MFYP: "+go_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(go_wip_count)+" "
							+"\n\n IT WIP Adj MFYP: "+it_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(it_wip_count)+" "
							+"\n\n FIN WIP Adj MFYP: "+fin_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(fin_wip_count)+" "
							+"\n\n MISC WIP Adj MFYP: "+misc_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(misc_wip_count)+" "
							+"\n\n WELCOME WIP Adj MFYP: "+welcome_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(welcome_wip_count)+"";

				}
				else
				{
					finalresponse="Current WIP as of "+dateFormat.format(cal.getTime())+
							" for "+msgChannel+" is "+convertsum4+" Policies with "+convertsum3+" "
							+  " " + LacsCr + ". Adj MFYP." //  Do you wish to see the stage wise snapshot."

							//+"WIP for "+msgChannel+" Adj MFYP :" +convertsum3+" " + LacsCr +". and Policies "+convertsum4+" "
							+"\n\n HO WIP Adj MFYP: "+ho_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(ho_wip_count)+" "
							+"\n\n GO WIP Adj MFYP: "+go_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(go_wip_count)+" "
							+"\n\n IT WIP Adj MFYP: "+it_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(it_wip_count)+" "
							+"\n\n FIN WIP Adj MFYP: "+fin_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(fin_wip_count)+" "
							+"\n\n MISC WIP Adj MFYP: "+misc_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(misc_wip_count)+" "
							+"\n\n WELCOME WIP Adj MFYP: "+welcome_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(welcome_wip_count)+"";

				}
			}

			/*finalresponse="WIP for "+msgChannel+" Adj MFYP :" +convertsum3+" " + LacsCr +". and Policies "+convertsum4+" "
					+"\n\n HO WIP Adj MFYP: "+ho_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(ho_wip_count)+" "
					+"\n\n GO WIP Adj MFYP: "+go_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(go_wip_count)+" "
					+"\n\n IT WIP Adj MFYP: "+it_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(it_wip_count)+" "
					+"\n\n FIN WIP Adj MFYP: "+fin_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(fin_wip_count)+" "
					+"\n\n MISC WIP Adj MFYP: "+misc_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(misc_wip_count)+" "
					+"\n\n WELCOME WIP Adj MFYP: "+welcome_wip_adj_mfyp+" " + LacsCr +". and Policies "+df.format(welcome_wip_count)+"";*/
		}
		else
		{

			finalresponse="Current WIP as of "+dateFormat.format(cal.getTime())+
					" for "+msgChannel+" is "+convertsum4+" Policies with "+convertsum3
					+ " " + LacsCr +". Adj MFYP." //Do you wish to see the stage wise snapshot."
					//+"WIP AdjMFYP: " +convertsum3+" " + LacsCr +"."
					+"\n\n HO WIP Adj MFYP: "+ho_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n GO WIP Adj MFYP: "+go_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n IT WIP Adj MFYP: "+it_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n FIN WIP Adj MFYP: "+fin_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n MISC WIP Adj MFYP: "+misc_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n WELCOME WIP Adj MFYP: "+welcome_wip_adj_mfyp+" " + LacsCr +".";

			/*finalresponse="WIP AdjMFYP: " +convertsum3+" " + LacsCr +"."
					+"\n\n HO WIP Adj MFYP: "+ho_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n GO WIP Adj MFYP: "+go_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n IT WIP Adj MFYP: "+it_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n FIN WIP Adj MFYP: "+fin_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n MISC WIP Adj MFYP: "+misc_wip_adj_mfyp+" " + LacsCr +"."
					+"\n\n WELCOME WIP Adj MFYP: "+welcome_wip_adj_mfyp+" " + LacsCr +".";*/
		}
		return finalresponse.toString();
	}

}
