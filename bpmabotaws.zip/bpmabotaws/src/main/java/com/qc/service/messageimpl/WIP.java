package com.qc.service.messageimpl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.qc.jsonImpl.NatHybWIP;

public class WIP 
{
	public static String wipIntent(String channel, String msgChannel, String convertsum4, String convertsum3, String LacsCr, 
			String userzone, String user_region, String user_circle, String user_clusters, String user_go)
	{

		Calendar cal = Calendar.getInstance(); // creates calendar
		cal.setTime(new Date()); // sets calendar time/date
		/*cal.add(Calendar.HOUR_OF_DAY, 5); // adds one hour
		cal.add(Calendar.MINUTE, 30);*/
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss aa");
		String finalresponse="";
		if(!"".equalsIgnoreCase(channel))
		{
			if("Agency".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
					&& "".equalsIgnoreCase(user_circle) && "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(user_go))
			{
				finalresponse="Current WIP as of "+dateFormat.format(cal.getTime())+
						" for "+msgChannel+" is "+convertsum4+" Policies with "+convertsum3+" "
						+  " " + LacsCr + ". Adj MFYP. Do you wish to see the stage wise snapshot. "
								+ "If you want to see the data for sub-channels, "
								+ "please enter sub-channel name - Defence, Office within office, APC, Greenfield.";
			}
			else{
				if("Internet Sales".equalsIgnoreCase(msgChannel))
				{
					finalresponse=" Current WIP as of "+NatHybWIP.wipBean.getReal_tim_timstamp()+" for Native ecomm is "+NatHybWIP.wipBean.getNativ_wip_count()
					+" Policies with "+NatHybWIP.wipBean.getNativ_wip_adj_mfyp()+ " " + LacsCr + ". Adj MFYP.\n\n"
					+" Current WIP as of "+NatHybWIP.wipBean.getReal_tim_timstamp()+" for Hybrid ecomm is " +NatHybWIP.wipBean.getHybrd_wip_count()+" "
					+" Policies with "+NatHybWIP.wipBean.getHybrd_wip_adj_mfyp()+ " " + LacsCr + ". Adj MFYP.";
				}
				else
				{
					finalresponse="Current WIP as of "+dateFormat.format(cal.getTime())+
							" for "+msgChannel+" is "+convertsum4+" Policies with "+convertsum3+" "
							+  " " + LacsCr + ". Adj MFYP. Do you wish to see the stage wise snapshot.";
				}
			}
		}
		else
		{
			finalresponse="Current WIP as of "+dateFormat.format(cal.getTime())+
					" for "+msgChannel+" is "+convertsum4+" Policies with "+convertsum3
					+ " " + LacsCr +". Adj MFYP. Do you wish to see the stage wise snapshot.";
		}
		return finalresponse.toString();
	}
}
