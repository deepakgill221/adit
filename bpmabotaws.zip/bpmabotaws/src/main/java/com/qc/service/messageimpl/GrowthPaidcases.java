package com.qc.service.messageimpl;

import com.qc.jsonImpl.NatHybGrowth;

public class GrowthPaidcases 
{
	public static String growthPaidcasesIntent(String channel,String period,String userzone,String user_region,
			String real_tim_timstamp,String grth_lst_yr_inforced_cnt_ytd, String prev_year_inforced_cnt_ytd,
			String ytd_inforced_cnt,String grth_lst_yr_inforced_cnt_mtd,String prev_year_inforced_cnt_mtd,
			String mtd_inforced_cnt, String user_circle, String subchannel, String user_clusters, String user_go, String superZone, String keyMarket)
	{
		String finalresponse="";

		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			if("FTD".equalsIgnoreCase(period))
			{
				period="YTD";
			}
			else
			{
				period=period.toUpperCase();
			}
		}
		if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}
		/*------------------------------------------------*/
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		/*------------------------------------------------*/
		if(!"".equalsIgnoreCase(subchannel))
		{
			channel = subchannel;
		}
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "MLI has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ "% on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today."
					+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse= channel+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
						grth_lst_yr_inforced_cnt_mtd+ "% on MTD basis, last year same month we have clocked "+
						prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today."
						+ " If you want to see the data for sub-channels, please enter sub-channel name - Defence, Office within office, APC, Greenfield.";
			}
			else
			{
				/*if("Internet Sales".equalsIgnoreCase(channel))
				{
					finalresponse=" Native ecomm has witnessed paid cases growth of "+NatHybGrowth.growthBean.getN_grh_lst_yr_inforced_cnt_ytd()+" % on YTD basis,"
							+" last year same time we had clocked "+NatHybGrowth.growthBean.getN_prev_year_inforced_cnt_ytd()
							+" of paid cases as compared to "+NatHybGrowth.growthBean.getN_ytd_inforced_cnt()
							+" today MTD business Growth of "+NatHybGrowth.growthBean.getN_grth_lst_yr_inforced_cnt_mtd()
							+" % on MTD basis, last year same month we have clocked "+NatHybGrowth.growthBean.getN_prev_year_inforced_cnt_mtd()
							+" of paid cases as compared to " +NatHybGrowth.growthBean.getN_mtd_inforced_cnt()
							+" today. \n\n"
							+" Hybrid ecomm has witnessed paid cases growth of "+NatHybGrowth.growthBean.getH_grth_lst_yr_inforced_cnt_ytd()
							+" % on YTD basis, last year same time we had clocked "+NatHybGrowth.growthBean.getH_prev_year_inforced_cnt_ytd()
							+" of paid cases as compared to "+NatHybGrowth.growthBean.getH_ytd_inforced_cnt()
							+" today MTD business Growth of "+NatHybGrowth.growthBean.getH_grth_lst_yr_inforced_cnt_mtd()
							+" % on MTD basis, last year same month we have clocked "+NatHybGrowth.growthBean.getH_prev_year_inforced_cnt_mtd()
							+" of paid cases as compared to "+NatHybGrowth.growthBean.getH_mtd_inforced_cnt()
							+" today.";
				}
				else
				{*/
				finalresponse= channel+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
						grth_lst_yr_inforced_cnt_mtd+ "% on MTD basis, last year same month we have clocked "+
						prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today."
						+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
				//}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)  
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= superZone+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ "% on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today."
					+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)  
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "Zone "+userzone+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ "% on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today."
					+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region)  
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "KM "+keyMarket+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ "% on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today."
					+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse=  ""+user_region+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today."
					+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse=  ""+user_clusters+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today.";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse=  ""+user_clusters+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today.";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse=  ""+user_clusters+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today.";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse=  ""+user_region+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today."
					+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
		}else if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(superZone))
		{	
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "MLI has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= "MLI has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(superZone))
		{	
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= channel+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= channel+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}

		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= superZone+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= superZone+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}

		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "KM "+keyMarket+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= "KM "+keyMarket+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}

		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "Zone "+userzone+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= "Zone "+userzone+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_region+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= ""+user_region+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}

		}
		/*----------------------------------------------------------------------------------------start*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_clusters+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today.";

			}
			else
			{
				finalresponse= ""+user_clusters+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today.";

			}
		}
		/*-------------------condition added by bhavneet-----------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_clusters+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today.";

			}
			else
			{
				finalresponse= ""+user_clusters+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today.";

			}
		}
		/*----------------------------------------------------------------------------------------start*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_region+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= ""+user_region+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}

		}
		/*---------------------------------------------------------------------start*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_clusters+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today.";

			}
			else
			{
				finalresponse= ""+user_clusters+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today.";

			}

		}else if(!"".equalsIgnoreCase(channel)&&!"".equalsIgnoreCase(user_clusters)&&"".equalsIgnoreCase(period)) {
			
			finalresponse=  ""+user_clusters+" has witnessed paid cases growth of "+grth_lst_yr_inforced_cnt_ytd+"% on YTD basis, last year same time we had clocked "+
					prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today MTD business Growth of "+ 
					grth_lst_yr_inforced_cnt_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_year_inforced_cnt_mtd+" of paid cases as compared to " +mtd_inforced_cnt+ " today.";
			
		}else if(!"".equalsIgnoreCase(channel)&&!"".equalsIgnoreCase(user_clusters)&&!"".equalsIgnoreCase(period)) {
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_clusters+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today.";

			}
			else
			{
				finalresponse= ""+user_clusters+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today.";

			}
		}
		/*---------------------------------------------------------------------End*/
		else
		{
			if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= channel+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_mtd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_mtd+ " of paid cases as compared to " +mtd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}else
			{
				finalresponse= channel+" has witnessed paid cases growth of " +grth_lst_yr_inforced_cnt_ytd+"% on "+period+" basis, last year same time we had clocked "+
						prev_year_inforced_cnt_ytd+ " of paid cases as compared to " +ytd_inforced_cnt+ " today "
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
		}
		return finalresponse.toString();
	}
}