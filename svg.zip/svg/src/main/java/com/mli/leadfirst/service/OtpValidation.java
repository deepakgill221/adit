package com.mli.leadfirst.service;

import java.util.Map;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface OtpValidation {
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String validateOtp(Map<String,Map<String, String>> map , String sessionId);

}
