package com.mli.leadfirst.response;

import org.springframework.stereotype.Service;

import com.mli.leadfirst.button.InnerData;
/**
 * @author sc05216
 *
 */
@Service
public class WebhookResponse {
	private static final long serialVersionUID = 1L;
	private String speech;
    private String displayText;
    private InnerData data;
    private String source = "java-webhook";

    /**
     * Default constructor
     */
    public WebhookResponse() {
		super();
	}

    /**
	 * @param speech
	 * @param displayText
	 * @param data
	 */
	public WebhookResponse(String speech, String displayText,InnerData data) {
		super();
		this.speech = speech;
		this.displayText = displayText;
		this.data=data;
	}		

	public String getSpeech() {
        return speech;
    }

    public String getDisplayText() {
        return displayText;
    }

    public String getSource() {
        return source;
    }

	public InnerData getData() {
		return data;
	}

	public void setData(InnerData data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "WebhookResponse [speech=" + speech + ", displayText=" + displayText + ", data=" + data + ", source="
				+ source + "]";
	}
	
}
