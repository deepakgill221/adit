package com.csg.model;

public interface CSGWebServiceCall 
{
	public String csgWebServiceCall();

}
