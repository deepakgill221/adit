package com.csg.controller;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.csg.service.NeedAnalysisService;
import com.csg.service.PDFCreationService;

@RestController
public class CSGController {

	private static Logger logger = LogManager.getLogger(CSGController.class);

	@Autowired
	private NeedAnalysisService needAnalysisService;
	
	@Autowired
	private PDFCreationService pdfCreationService;
	
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	
	@Scheduled(cron = "0 0/10 * * * ?")
	public void removeCashethirtyminute()
	{
		logger.info("Cron job to remove un-used session from cache : Start");
		needAnalysisService.removeUnUsedSessionFromCache();
	}
	
	/**
	 * @param request : Request data in JSON Format
	 * @return
	 */
	@RequestMapping(path ="/csg")
	public String webhook(@RequestBody String request) 
	{
		logger.info("Need Analysis Process Request start:: ");
		return needAnalysisService.doProcessRequest(request);
	}
}
