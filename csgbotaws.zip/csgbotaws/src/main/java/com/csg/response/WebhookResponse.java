package com.csg.response;

import com.csg.button.InnerData;

public class WebhookResponse
{
    private String speech;
    private String displayText;
    private InnerData data;
    private  static final String SOURCE = "java-webhook";

    public WebhookResponse() {
		super();
	}
	public WebhookResponse(String speech, String displayText,InnerData data) {
		super();
		this.speech = speech;
		this.displayText = displayText;
	
		this.data=data;
	}		
	public String getSpeech() {
        return speech;
    }
    public String getDisplayText() {
        return displayText;
    }
    public String getSource() {
        return SOURCE;
    }
	public InnerData getData() {
		return data;
	}
	public void setData(InnerData data) {
		this.data = data;
	}
}
