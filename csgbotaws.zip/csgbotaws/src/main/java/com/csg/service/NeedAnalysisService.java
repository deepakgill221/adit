package com.csg.service;
 public interface NeedAnalysisService
{
	 public void removeUnUsedSessionFromCache();
	 public String doProcessRequest(String requestObject);
	 public String getArciseToken();
	 public String callArciseServices(String sessionId,String sourceName);
	 
}
