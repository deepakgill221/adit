package com.csg.service;

import java.io.ByteArrayOutputStream;
import java.util.Map;

import com.csg.bean.FinalPlanDetailBean;

public interface PDFCreationService {
	
	public  void createPdf(String username,String pathwithName,Map externalMap,String sessionId,String planName);
	public ByteArrayOutputStream textPdfCreator(String username, Map externalMap,String sessionId,String planNameForImage);
	
	public FinalPlanDetailBean finalPlanDetail(Map<String, String> plan);
}
