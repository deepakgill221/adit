package com.csg.modelimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.csg.model.CSGWebServiceCall;
import com.csg.service.CSGQuestionsCall;

@Service
public class CSGWebServiceCallImpl implements CSGWebServiceCall 
{
	@Autowired
	private CSGQuestionsCall csgQuestionsCall;
	
	@Override
	public String csgWebServiceCall() {
		return null;
	}

}
