package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class RollingCollection 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(RollingCollection.class);
	public String rollingCollectionIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="Not Applicable";
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+" Your total 12 month rolling collected amount is "
					+bean.getRolling_mfyp_12mth()+" Total 12 month rolling collectable amount is "
					+bean.getRolling_collection_12mth();
		}
		else
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+" Your total 12 month rolling collected amount is "
					+bean.getRolling_mfyp_12mth()+" Total 12 month rolling collectable amount is "
					+bean.getRolling_collection_12mth();
		}
		System.out.println("RollingCollection--"+ finalresponse);
		logger.info("RollingCollection--"+ finalresponse);
		return finalresponse;
	}
}
