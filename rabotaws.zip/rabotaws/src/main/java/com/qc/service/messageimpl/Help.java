package com.qc.service.messageimpl;

import org.springframework.stereotype.Service;

@Service
public class Help {

	public String helpIntent()
	{
		String finalresponse= "You can use following keywords to get real time information about your relevant KPIs:"+"\n"+
                              "Policy Details � Policy no. Policy Status, Welcome calling status, Renewal Premium, Fund Value, Medical Category, ECS date, Policy pack delivery status"+"\n"+
                              "Adj. MFYP \n"
                              +"Paid Business \n"
                              +"Applied Cases \n"
                              +"Paid Cases \n"
                              +"Weighted MFYP (For CAT channel only*)\n"
                              +"Applied FYP \n"
                              +"WIP cases (Stage wise) \n"
                              +"Premium Due for the month \n"
                              +"13M Persistency \n" 
                              +"Collection, 12 month Rolling Collection (For Agency & CAT channel only*) \n"
                              +"Total NTU policies for the month \n"
                              +"Happy Chatting!";
							return finalresponse;

	}
}
