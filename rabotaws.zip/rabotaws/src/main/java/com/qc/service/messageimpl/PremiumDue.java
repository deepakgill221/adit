package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class PremiumDue 
{
	@Autowired
	private Bean bean;

	private static Logger logger = LogManager.getLogger(PremiumDue.class);
	public String premiumDueIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your total Premium due in this month is Rs."
					+bean.getDue_policy_mfyp();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your total Premium due in this month is Rs."
					+bean.getDue_policy_mfyp();
		}
		else
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your total Premium due in this month is Rs."
					+bean.getDue_policy_mfyp();
		}
		logger.info("PremiumDue--"+ finalresponse);
		return finalresponse;
	}
}
