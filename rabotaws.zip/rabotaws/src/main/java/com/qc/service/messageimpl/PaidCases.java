package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.qc.api.entity.Bean;

@Service
public class PaidCases 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(PaidCases.class);
	public String paidCasesIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel()) || "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your total count of Paid Cases is FTD :"+bean.getInforced_ftd()+
				", MTD : "+bean.getInforced_mtd()+", QTD :"+bean.getInforced_qtd()+", YTD : "+bean.getInforced_ytd();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your total count of Paid Cases is FTD :"+bean.getInforced_ftd()+
				",  MTD : "+bean.getInforced_mtd()+", QTD :"+bean.getInforced_qtd()+", YTD : "+bean.getInforced_ytd();
		}
		else
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your total count of Paid Cases is FTD :"+bean.getInforced_ftd()+
				",  MTD : "+bean.getInforced_mtd()+", QTD :"+bean.getInforced_qtd()+", YTD : "+bean.getInforced_ytd();
		}
		logger.info("PaidCases--"+finalresponse);
		return finalresponse;
	}
}
