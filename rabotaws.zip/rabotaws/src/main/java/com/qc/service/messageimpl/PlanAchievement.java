package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class PlanAchievement 
{
	@Autowired
	private Bean bean;
	
	String finalresponse="";
	public String planAchievementIntent(String channel)
	{
		if("Axis Bank".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+" Your Plan Achievement MTD is :"+bean.getMtd_adj_mfyp_ach_prcntg()+"%, "
					+ "QTD is :"+bean.getQtd_adj_mfyp_ach_prcntg()+"%, YTD is "+bean.getYtd_adj_mfyp_ach_prcntg()+"%.";
		}
		else if("Agency".equalsIgnoreCase(channel))
		{
			finalresponse=" As of "+bean.getREAL_TIM_TIMSTAMP()+" Your Plan Achievement YTD is : "+bean.getYtd_wtg_fyp_ach_prcntg()+"%"; 
		}
		else if("CAT".equalsIgnoreCase(channel))
		{
			finalresponse=" As of "+bean.getREAL_TIM_TIMSTAMP()+" Your Plan Achievement MTD is :"+bean.getMtd_g3_wtg_fyp_ach_prcntg()+"%, "
					+ "QTD is : "+bean.getQtd_g3_wtg_fyp_ach_prcntg()+"%, YTD is : "+bean.getYtd_g3_wtg_fyp_ach_prcntg()+"% ";
		}
		else
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+" Your Plan Achievement MTD is : "+bean.getMtd_adj_mfyp_in_lac_ach_prcntg()+"%, "
					+ "QTD is : "+bean.getQtd_adj_mfyp_in_lac_ach_prcntg()+"%, YTD is : "+bean.getYtd_adj_mfyp_in_lac_ach_prcntg()+"%";
		}
		return finalresponse;
	}
}
