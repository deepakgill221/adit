package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class NAT 
{
	@Autowired
	private Bean bean;
	String finalresponse="";
	public String natIntent(String channel)
	{
		if("Agency".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your NAT count FTD is :"+bean.getNat_count_ftd()+", MTD is :"+bean.getNat_count_mtd();
		}
		else if("BancAssurance".equalsIgnoreCase(channel))
		{
			finalresponse="NOT APPLICABLE";
		}else if("Axis Bank".equalsIgnoreCase(channel))
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}else
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}
		return finalresponse;
	}
}
