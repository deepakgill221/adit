package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class ECSDatePolicy 
{
	@Autowired
	private Bean bean;

	private static Logger logger = LogManager.getLogger(ECSDatePolicy.class);
	public String eCSDatePolicyIntent(String policyNumber)
	{
		String finalresponse="";
		if("0".equalsIgnoreCase(bean.getPolicy_ecs_dt()))
		{
			finalresponse="This is not an ECS Policy";
		}
		else if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="The ECS date for "+policyNumber+" is "+bean.getPolicy_ecs_dt();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="The ECS date for "+policyNumber+" is "+bean.getPolicy_ecs_dt();
		}
		else
		{
			finalresponse="The ECS date for "+policyNumber+" is "+bean.getPolicy_ecs_dt();
		}
		
		logger.info("ECSDatePolicy--"+ finalresponse);
		return finalresponse;
	}
}
