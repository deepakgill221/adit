package com.qc.service.messageimpl;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;
@Service
public class NomineeDetails 
{
	@Autowired
	private Bean bean;
	public String nomineeDetailsIntent(String policyNumber, JSONObject object)
	{
		StringBuffer finalresponse = new StringBuffer();
		StringBuffer bufferappend = new StringBuffer();
		JSONArray array=null;
		String nominee_NAME="", nominee_DOB="", nominee_RELATIONSHIP="", nominee_SHARE="";
		try{
			array=object.getJSONObject("payload").getJSONArray("nomineeDetail");
			for(int i=0; i<array.length();i++)
			{
				try{
					nominee_NAME=(array.getJSONObject(i).get("nominee_NAME")+"");
				}catch(Exception ex)
				{
					nominee_NAME="Mr. A";
				}
				try{
					nominee_DOB=(array.getJSONObject(i).get("nominee_DOB")+"");
				}
				catch(Exception ex)
				{
					nominee_DOB="23-July-1987";
				}
				try{
					nominee_RELATIONSHIP=(array.getJSONObject(i).get("nominee_RELATIONSHIP")+"");
				}catch(Exception ex)
				{
					nominee_RELATIONSHIP="SON";
				}
				try{
					nominee_SHARE=(array.getJSONObject(i).get("nominee_SHARE")+"");
				}catch(Exception ex)
				{
					nominee_SHARE="72";
				}
				bufferappend.append("Nominee Name :"+nominee_NAME+", DOB: "+nominee_DOB+", RelationShip :"+nominee_RELATIONSHIP+ 
						", Share :"+nominee_SHARE+"% \n\n");
			}
		}catch(Exception ex)
		{
			finalresponse.append("Something went wrong in nomineeDetail");
		}
		{
			int i=2;
			if(i>array.length())
			{
				if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
				{
					finalresponse.append("Nominee against Policy "+policyNumber+", Name: " +nominee_NAME
					+", DOB: "+nominee_DOB+", Relation: "+nominee_RELATIONSHIP+", Share: "+nominee_SHARE+"%");
				}
				else if("Agency".equalsIgnoreCase(bean.getChannel()))
				{
					finalresponse.append("Nominee against Policy "+policyNumber+", Name: " +nominee_NAME
							+", DOB: "+nominee_DOB+", Relation: "+nominee_RELATIONSHIP+", Share: "+nominee_SHARE+"%");
				}
				else
				{
					finalresponse.append("Nominee against Policy "+policyNumber+", Name: " +nominee_NAME
							+", DOB: "+nominee_DOB+", Relation: "+nominee_RELATIONSHIP+", Share: "+nominee_SHARE+"%");
				}
				return finalresponse.toString();
			}
			else
			{
				return finalresponse.append(bufferappend).toString();
			}
		}
	}
}
