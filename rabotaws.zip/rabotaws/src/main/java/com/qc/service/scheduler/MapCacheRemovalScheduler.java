/*package com.qc.service.scheduler;

import java.text.SimpleDateFormat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.qc.controller.MliBotController;

public class MapCacheRemovalScheduler implements Runnable {

	private static Logger logger = LogManager.getLogger(MapCacheRemovalScheduler.class);
	
	static SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy");

	public void run() {
		logger.info("MapCacheRemovalScheduler Run Method Started.");
		
		try {
			MliBotController mbc = new MliBotController();
			mbc.calculateTimeToDeleteMap();
			logger.info("Scheduler Status inserted for ExceptionNotificationScheduler.");
		} catch (Exception e) {
			logger.error("Error in inserting "
					+ "ExceptionNotificationScheduler  Status :-" + e);
		}
		logger.info("ExceptionNotificationScheduler Run Method End.");
	}
}
*/