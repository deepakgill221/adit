package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qc.api.entity.Bean;
@Service
public class AppliedFYP 
{
	@Autowired
	private Bean bean;
	
	public String appliedFYPIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" Your total Applied FYP is FTD : Rs."+bean.getApplied_total_afyp_ftd()+" Lacs, MTD : Rs."+bean.getApplied_total_afyp_mtd()
					+ " Lacs, QTD : Rs."+bean.getApplied_total_afyp_qtd()+" Lacs, YTD : Rs."+bean.getApplied_total_afyp_ytd()
				        +" Lacs.";
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" Your total Applied FYP is FTD : Rs."+bean.getApplied_total_afyp_ftd()+" Lacs, MTD : Rs."+bean.getApplied_total_afyp_mtd()
					+ " Lacs, QTD : Rs."+bean.getApplied_total_afyp_qtd()+" Lacs, YTD : Rs."+bean.getApplied_total_afyp_ytd()
			                +" Lacs.";
		}
		else
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" Your total Applied FYP is FTD : Rs."+bean.getApplied_total_afyp_ftd()+" Lacs, MTD : Rs."+bean.getApplied_total_afyp_mtd()
					+ " Lacs, QTD : Rs."+bean.getApplied_total_afyp_qtd()+" Lacs, YTD : Rs."+bean.getApplied_total_afyp_ytd()
				        +" Lacs.";
		}
		return finalresponse;
	}

}
