package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class PolicyStatus 
{
	String finalresponse="";
	private static Logger logger = LogManager.getLogger(PolicyStatus.class);
	public String policyStatusIntent(String policyNumber, Bean bean)
	{
		finalresponse= "The current status of Policy no. "+policyNumber+" is "+
                "\n\nWorkitem: "+bean.getWorkitemDescription()+""+
		        "\n\nCase Status: "+bean.getPolicy_status_desc()+""+
                "\n\nPending Req.:"+bean.getPendingRequirement()+""+
		        "\n\nTPP Comments: "+bean.getTppComment();
		return finalresponse;
	}
}
