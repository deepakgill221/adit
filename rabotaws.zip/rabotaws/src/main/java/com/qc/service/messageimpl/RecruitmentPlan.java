package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class RecruitmentPlan 
{
	@Autowired private Bean bean;
	String finalresponse="";
	public String recruitmentPlanIntent(String channel)
	{
		if("Agency".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Quality Recruitment achievement YTD is :"+bean.getQua_recruit_ach_p()+"%";
		}else if("BancAssurance".equalsIgnoreCase(channel))
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}else if("Axis Bank".equalsIgnoreCase(channel))
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}else
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}
		return finalresponse;
	}
}
