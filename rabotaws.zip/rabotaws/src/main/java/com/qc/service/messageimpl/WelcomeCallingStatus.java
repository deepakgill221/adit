package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class WelcomeCallingStatus 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(WelcomeCallingStatus.class);
	public String welcomeCallingStatusIntent(String policyNumber)
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="The Welcome Calling status for Policy "+policyNumber+ " is "+bean.getPol_welcom_call_status();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="The Welcome Calling status for Policy "+policyNumber+ " is "+bean.getPol_welcom_call_status();
		}
		else
		{
			finalresponse="The Welcome Calling status for Policy "+policyNumber+ " is "+bean.getPol_welcom_call_status();
		}
		logger.info("WelcomeCallingStatus--"+ finalresponse);
		return finalresponse;
	}
}
