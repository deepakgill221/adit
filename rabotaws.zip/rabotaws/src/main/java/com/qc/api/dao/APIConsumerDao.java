/*package com.qc.api.dao;


import com.qc.api.entity.WipEntity;

public interface APIConsumerDao {
	public String insertWipEntity(WipEntity entity);
	
}
*/