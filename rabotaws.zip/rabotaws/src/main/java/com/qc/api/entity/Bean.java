package com.qc.api.entity;

import org.springframework.stereotype.Service;

@Service
public class Bean 
{
	private	String	channel;
	private	String	sub_channel;
	private	String	ra_adm_agt_id;
	private	String	adj_mfyp_ftd;
	private	String	adj_mfyp_mtd;
	private	String	adj_mfyp_qtd;
	private	String	adj_mfyp_ytd;
	private	String	inforced_ftd;
	private	String	inforced_mtd;
	private	String	inforced_qtd;
	private	String	inforced_ytd;
	private	String	wtg_mfyp_mtd;
	private	String	wtg_mfyp_qtd;
	private	String	wtg_mfyp_ytd;
	private	String	policy_number;
	private	String	pol_due_date;
	private	String	pol_owner_dob;
	private	String	pol_owner_pan;
	private	String	policy_status_desc;
	private	String	pol_renewal_prm;
	private	String	due_policy_count;
	private	String	due_policy_mfyp;
	private	String	total_collection_amt;
	private	String	total_collection_mfyp;
	private	String	rolling_collection_12mth;
	private	String	rolling_mfyp_12mth;
	private	String	ntu_policy_count;
	private	String	ntu_policy_afyp;
	private	String	nominee_name;
	private	String	nominee_dob;
	private	String	nominee_relationship;
	private	String	nominee_share;
	private	String	pol_pack_delvry_dt;
	private	String	pol_med_category;
	private	String	pol_fund_value;
	private	String	total_base_13m_pers;
	private	String	unpaid_base_13m_pers;
	private	String	achievement_13m_pers;
	private	String	wip_count;
	private	String	wip_mfyp;
	private	String	wip_afyp;
	private	String	wip_adj_mfyp;
	private	String	wip_stage;
	private	String	pol_welcom_call_status;
	private	String	pol_welcom_call_region;
	private	String	policy_ecs_dt;
	private String  applied_total_afyp_ftd;
	private String  applied_total_afyp_mtd;
	private String  applied_total_afyp_qtd;
	private String  applied_total_afyp_ytd;
	private String  applied_count_ftd;
	private String  applied_count_mtd;
	private String  applied_count_qtd;
	private String  applied_count_ytd;
	/*-------------Sprint 3.2----------AxisBank--------------------------*/
	private String activisa_mtd_prcntg;
	private String activisa_mtd_manmonth;
	private String activisa_mtd_active;
	private String mtd_activa_act_ach_prcntg;
	private String mtd_activa_plan_ach_prcntg;
	private String mtd_activa_plan_manmonth;
	private String mtd_activa_plan_active;
	private String gpa_score;
	private String perform_activation_ach_p;
	private String perform_adj_mfyp_plan_ach_p;
	private String perform_15th_month_pers_qtd_p;
	private String mtd_adj_mfyp_ach_prcntg;
	private String mtd_adj_mfyp_plan;
	private String mtd_adj_mfyp_actual;
	private String qtd_adj_mfyp_ach_prcntg;
	private String qtd_adj_mfyp_plan;
	private String qtd_adj_mfyp_actual;
	private String ytd_adj_mfyp_ach_prcntg;
	private String ytd_adj_mfyp_plan;
	private String ytd_adj_mfyp_actual;
	private String prmtn_shrtfl_adj_mfyp_pln_ach;
	private String prmtn_shrtfl_actvn_ach;
	private String prmtn_shrtfl_15m_pers_qtd_ach;

	/*-------------Sprint 3.2----------YBL--------------------------*/
	/*private String activisa_mtd_prcntg;
	private String activisa_mtd_manmonth;// Threse three fields Already present in AxisBank 
	private String activisa_mtd_active;*/
	private String activisa_mtd_plan_prcntg;
	private String promo_adj_p_mfyp_in_lacs_act;
	private String promo_adj_p_mfyp_in_lacs_p;
	private String promo_paid_cases_act;
	private String promo_paid_cases_p;
	private String promo_15m_pers_in_lacs_p;
	private String mtd_adj_mfyp_in_lac_ach_prcntg;
	private String mtd_adj_mfyp_in_lac_plan;
	private String mtd_adj_mfyp_in_lac_actual;
	private String qtd_adj_mfyp_in_lac_ach_prcntg;
	private String qtd_adj_mfyp_in_lac_plan;
	private String qtd_adj_mfyp_in_lac_actual;
	private String ytd_adj_mfyp_in_lac_ach_prcntg;
	private String ytd_adj_mfyp_in_lac_plan;
	private String ytd_adj_mfyp_in_lac_actual;
	private String promo_adj_p_mfyp_in_lacs_srtfl;
	private String promo_paid_cases_shortfall;
	private String promo_15m_pers_shortfall;      

	/*-------------Sprint 3.2----------CAT--------------------------*/
	private String promo_wtg_fyp_act_6m;
	private String promo_wtg_fyp_ach_p_6m;
	private String promo_nop_act_6m;
	private String promo_nop_ach_p_6m;
	private String promo_collection_ach_p;
	private String promo_wtg_fyp_act_9m;
	private String promo_wtg_fyp_ach_p_9m;
	private String promo_nop_act_9m;
	private String promo_nop_ach_p_9m;
	private String promo_wtg_fyp_act12m;
	private String promo_wtg_fyp_ach_p_12m;
	private String promo_nop_act12m;
	private String promo_nop_ach_p_12m;
	private String ytd_wtg_fyp_plan;
	private String ytd_wtg_fyp_actual;
	private String mtd_g3_wtg_fyp_ach_prcntg;
	private String mtd_g3_wtg_fyp_plan;
	private String mtd_g3_wtg_fyp_actual;
	private String qtd_g3_wtg_fyp_ach_prcntg;
	private String qtd_g3_wtg_fyp_plan;
	private String qtd_g3_wtg_fyp_actual;
	private String ytd_g3_wtg_fyp_ach_prcntg;
	private String ytd_g3_wtg_fyp_plan;
	private String ytd_g3_wtg_fyp_actual;
	/*-------------Sprint 3.2----------AGENCY--------------------------*/
	private String adm_tot_gpa_scor_extra_credit;
	private String recruitment_mtd;
	private String recruitment_ytd;
	private String qua_recruit_extra_cr_actual;
	private String qua_recruit_ach_percntg;
	private String nat_count_ftd;
	private String nat_count_mtd;
	/*private String promo_wtg_fyp_act_6m;*///COLUMN PRESENT IN CAT
	private String ytd_wtg_fyp_in_lac_act;
	private String ytd_wtg_fyp_in_lac_ach_p;
	private String qua_recruit_with_extra_cre_act;
	private String qua_recruit_ach_p;
	private String tot_proac_agt_mm_wit_extr_cred;
	private String tot_proac_agt_mm_ach_p;
	/*private String ytd_adj_mfyp_plan;
	private String ytd_adj_mfyp_actual;*///COLUMN PRESENT IN AXISBANK
	private String ytd_wtg_fyp_ach_prcntg;
    /*COMMON FOR ALL*/
	private String  BTCH_TIMSTAMP;
	private String  REAL_TIM_TIMSTAMP;
	
	// new policy status fields
	
	private String workitemDescription;
	private String pendingRequirement;
	private String tppComment;
	
	public Bean() {
		super();
		
	}
	
	public String getWorkitemDescription() {
		return workitemDescription;
	}

	public void setWorkitemDescription(String workitemDescription) {
		this.workitemDescription = workitemDescription;
	}

	public String getPendingRequirement() {
		return pendingRequirement;
	}

	public void setPendingRequirement(String pendingRequirement) {
		this.pendingRequirement = pendingRequirement;
	}

	public String getTppComment() {
		return tppComment;
	}

	public void setTppComment(String tppComment) {
		this.tppComment = tppComment;
	}

	

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSub_channel() {
		return sub_channel;
	}

	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}

	public String getRa_adm_agt_id() {
		return ra_adm_agt_id;
	}

	public void setRa_adm_agt_id(String ra_adm_agt_id) {
		this.ra_adm_agt_id = ra_adm_agt_id;
	}

	public String getAdj_mfyp_ftd() {
		return adj_mfyp_ftd;
	}

	public void setAdj_mfyp_ftd(String adj_mfyp_ftd) {
		this.adj_mfyp_ftd = adj_mfyp_ftd;
	}

	public String getAdj_mfyp_mtd() {
		return adj_mfyp_mtd;
	}

	public void setAdj_mfyp_mtd(String adj_mfyp_mtd) {
		this.adj_mfyp_mtd = adj_mfyp_mtd;
	}

	public String getAdj_mfyp_qtd() {
		return adj_mfyp_qtd;
	}

	public void setAdj_mfyp_qtd(String adj_mfyp_qtd) {
		this.adj_mfyp_qtd = adj_mfyp_qtd;
	}

	public String getAdj_mfyp_ytd() {
		return adj_mfyp_ytd;
	}

	public void setAdj_mfyp_ytd(String adj_mfyp_ytd) {
		this.adj_mfyp_ytd = adj_mfyp_ytd;
	}

	public String getInforced_ftd() {
		return inforced_ftd;
	}

	public void setInforced_ftd(String inforced_ftd) {
		this.inforced_ftd = inforced_ftd;
	}

	public String getInforced_mtd() {
		return inforced_mtd;
	}

	public void setInforced_mtd(String inforced_mtd) {
		this.inforced_mtd = inforced_mtd;
	}

	public String getInforced_qtd() {
		return inforced_qtd;
	}

	public void setInforced_qtd(String inforced_qtd) {
		this.inforced_qtd = inforced_qtd;
	}

	public String getInforced_ytd() {
		return inforced_ytd;
	}

	public void setInforced_ytd(String inforced_ytd) {
		this.inforced_ytd = inforced_ytd;
	}

	public String getWtg_mfyp_mtd() {
		return wtg_mfyp_mtd;
	}

	public void setWtg_mfyp_mtd(String wtg_mfyp_mtd) {
		this.wtg_mfyp_mtd = wtg_mfyp_mtd;
	}

	public String getWtg_mfyp_qtd() {
		return wtg_mfyp_qtd;
	}

	public void setWtg_mfyp_qtd(String wtg_mfyp_qtd) {
		this.wtg_mfyp_qtd = wtg_mfyp_qtd;
	}

	public String getWtg_mfyp_ytd() {
		return wtg_mfyp_ytd;
	}

	public void setWtg_mfyp_ytd(String wtg_mfyp_ytd) {
		this.wtg_mfyp_ytd = wtg_mfyp_ytd;
	}

	public String getPolicy_number() {
		return policy_number;
	}

	public void setPolicy_number(String policy_number) {
		this.policy_number = policy_number;
	}

	public String getPol_due_date() {
		return pol_due_date;
	}

	public void setPol_due_date(String pol_due_date) {
		this.pol_due_date = pol_due_date;
	}

	public String getPol_owner_dob() {
		return pol_owner_dob;
	}

	public void setPol_owner_dob(String pol_owner_dob) {
		this.pol_owner_dob = pol_owner_dob;
	}

	public String getPol_owner_pan() {
		return pol_owner_pan;
	}

	public void setPol_owner_pan(String pol_owner_pan) {
		this.pol_owner_pan = pol_owner_pan;
	}

	public String getPolicy_status_desc() {
		return policy_status_desc;
	}

	public void setPolicy_status_desc(String policy_status_desc) {
		this.policy_status_desc = policy_status_desc;
	}

	public String getPol_renewal_prm() {
		return pol_renewal_prm;
	}

	public void setPol_renewal_prm(String pol_renewal_prm) {
		this.pol_renewal_prm = pol_renewal_prm;
	}

	public String getDue_policy_count() {
		return due_policy_count;
	}

	public void setDue_policy_count(String due_policy_count) {
		this.due_policy_count = due_policy_count;
	}

	public String getDue_policy_mfyp() {
		return due_policy_mfyp;
	}

	public void setDue_policy_mfyp(String due_policy_mfyp) {
		this.due_policy_mfyp = due_policy_mfyp;
	}

	public String getTotal_collection_amt() {
		return total_collection_amt;
	}

	public void setTotal_collection_amt(String total_collection_amt) {
		this.total_collection_amt = total_collection_amt;
	}

	public String getTotal_collection_mfyp() {
		return total_collection_mfyp;
	}

	public void setTotal_collection_mfyp(String total_collection_mfyp) {
		this.total_collection_mfyp = total_collection_mfyp;
	}

	public String getRolling_collection_12mth() {
		return rolling_collection_12mth;
	}

	public void setRolling_collection_12mth(String rolling_collection_12mth) {
		this.rolling_collection_12mth = rolling_collection_12mth;
	}

	public String getRolling_mfyp_12mth() {
		return rolling_mfyp_12mth;
	}

	public void setRolling_mfyp_12mth(String rolling_mfyp_12mth) {
		this.rolling_mfyp_12mth = rolling_mfyp_12mth;
	}

	public String getNtu_policy_count() {
		return ntu_policy_count;
	}

	public void setNtu_policy_count(String ntu_policy_count) {
		this.ntu_policy_count = ntu_policy_count;
	}

	public String getNtu_policy_afyp() {
		return ntu_policy_afyp;
	}

	public void setNtu_policy_afyp(String ntu_policy_afyp) {
		this.ntu_policy_afyp = ntu_policy_afyp;
	}

	public String getNominee_name() {
		return nominee_name;
	}

	public void setNominee_name(String nominee_name) {
		this.nominee_name = nominee_name;
	}

	public String getNominee_dob() {
		return nominee_dob;
	}

	public void setNominee_dob(String nominee_dob) {
		this.nominee_dob = nominee_dob;
	}

	public String getNominee_relationship() {
		return nominee_relationship;
	}

	public void setNominee_relationship(String nominee_relationship) {
		this.nominee_relationship = nominee_relationship;
	}

	public String getNominee_share() {
		return nominee_share;
	}

	public void setNominee_share(String nominee_share) {
		this.nominee_share = nominee_share;
	}

	public String getPol_pack_delvry_dt() {
		return pol_pack_delvry_dt;
	}

	public void setPol_pack_delvry_dt(String pol_pack_delvry_dt) {
		this.pol_pack_delvry_dt = pol_pack_delvry_dt;
	}

	public String getPol_med_category() {
		return pol_med_category;
	}

	public void setPol_med_category(String pol_med_category) {
		this.pol_med_category = pol_med_category;
	}

	public String getPol_fund_value() {
		return pol_fund_value;
	}

	public void setPol_fund_value(String pol_fund_value) {
		this.pol_fund_value = pol_fund_value;
	}

	public String getTotal_base_13m_pers() {
		return total_base_13m_pers;
	}

	public void setTotal_base_13m_pers(String total_base_13m_pers) {
		this.total_base_13m_pers = total_base_13m_pers;
	}

	public String getUnpaid_base_13m_pers() {
		return unpaid_base_13m_pers;
	}

	public void setUnpaid_base_13m_pers(String unpaid_base_13m_pers) {
		this.unpaid_base_13m_pers = unpaid_base_13m_pers;
	}

	public String getAchievement_13m_pers() {
		return achievement_13m_pers;
	}

	public void setAchievement_13m_pers(String achievement_13m_pers) {
		this.achievement_13m_pers = achievement_13m_pers;
	}

	public String getWip_count() {
		return wip_count;
	}

	public void setWip_count(String wip_count) {
		this.wip_count = wip_count;
	}

	public String getWip_mfyp() {
		return wip_mfyp;
	}

	public void setWip_mfyp(String wip_mfyp) {
		this.wip_mfyp = wip_mfyp;
	}

	public String getWip_afyp() {
		return wip_afyp;
	}

	public void setWip_afyp(String wip_afyp) {
		this.wip_afyp = wip_afyp;
	}

	public String getWip_adj_mfyp() {
		return wip_adj_mfyp;
	}

	public void setWip_adj_mfyp(String wip_adj_mfyp) {
		this.wip_adj_mfyp = wip_adj_mfyp;
	}

	public String getWip_stage() {
		return wip_stage;
	}

	public void setWip_stage(String wip_stage) {
		this.wip_stage = wip_stage;
	}

	public String getPol_welcom_call_status() {
		return pol_welcom_call_status;
	}

	public void setPol_welcom_call_status(String pol_welcom_call_status) {
		this.pol_welcom_call_status = pol_welcom_call_status;
	}

	public String getPol_welcom_call_region() {
		return pol_welcom_call_region;
	}

	public void setPol_welcom_call_region(String pol_welcom_call_region) {
		this.pol_welcom_call_region = pol_welcom_call_region;
	}

	public String getPolicy_ecs_dt() {
		return policy_ecs_dt;
	}

	public void setPolicy_ecs_dt(String policy_ecs_dt) {
		this.policy_ecs_dt = policy_ecs_dt;
	}

	public String getApplied_total_afyp_ftd() {
		return applied_total_afyp_ftd;
	}

	public void setApplied_total_afyp_ftd(String applied_total_afyp_ftd) {
		this.applied_total_afyp_ftd = applied_total_afyp_ftd;
	}

	public String getApplied_total_afyp_mtd() {
		return applied_total_afyp_mtd;
	}

	public void setApplied_total_afyp_mtd(String applied_total_afyp_mtd) {
		this.applied_total_afyp_mtd = applied_total_afyp_mtd;
	}

	public String getApplied_total_afyp_qtd() {
		return applied_total_afyp_qtd;
	}

	public void setApplied_total_afyp_qtd(String applied_total_afyp_qtd) {
		this.applied_total_afyp_qtd = applied_total_afyp_qtd;
	}

	public String getApplied_total_afyp_ytd() {
		return applied_total_afyp_ytd;
	}

	public void setApplied_total_afyp_ytd(String applied_total_afyp_ytd) {
		this.applied_total_afyp_ytd = applied_total_afyp_ytd;
	}

	public String getApplied_count_ftd() {
		return applied_count_ftd;
	}

	public void setApplied_count_ftd(String applied_count_ftd) {
		this.applied_count_ftd = applied_count_ftd;
	}

	public String getApplied_count_mtd() {
		return applied_count_mtd;
	}

	public void setApplied_count_mtd(String applied_count_mtd) {
		this.applied_count_mtd = applied_count_mtd;
	}

	public String getApplied_count_qtd() {
		return applied_count_qtd;
	}

	public void setApplied_count_qtd(String applied_count_qtd) {
		this.applied_count_qtd = applied_count_qtd;
	}

	public String getApplied_count_ytd() {
		return applied_count_ytd;
	}

	public void setApplied_count_ytd(String applied_count_ytd) {
		this.applied_count_ytd = applied_count_ytd;
	}

	public String getBTCH_TIMSTAMP() {
		return BTCH_TIMSTAMP;
	}

	public void setBTCH_TIMSTAMP(String bTCH_TIMSTAMP) {
		BTCH_TIMSTAMP = bTCH_TIMSTAMP;
	}

	public String getREAL_TIM_TIMSTAMP() {
		return REAL_TIM_TIMSTAMP;
	}

	public void setREAL_TIM_TIMSTAMP(String rEAL_TIM_TIMSTAMP) {
		REAL_TIM_TIMSTAMP = rEAL_TIM_TIMSTAMP;
	}

	public String getActivisa_mtd_prcntg() {
		return activisa_mtd_prcntg;
	}

	public void setActivisa_mtd_prcntg(String activisa_mtd_prcntg) {
		this.activisa_mtd_prcntg = activisa_mtd_prcntg;
	}

	public String getActivisa_mtd_manmonth() {
		return activisa_mtd_manmonth;
	}

	public void setActivisa_mtd_manmonth(String activisa_mtd_manmonth) {
		this.activisa_mtd_manmonth = activisa_mtd_manmonth;
	}

	public String getActivisa_mtd_active() {
		return activisa_mtd_active;
	}

	public void setActivisa_mtd_active(String activisa_mtd_active) {
		this.activisa_mtd_active = activisa_mtd_active;
	}

	public String getMtd_activa_act_ach_prcntg() {
		return mtd_activa_act_ach_prcntg;
	}

	public void setMtd_activa_act_ach_prcntg(String mtd_activa_act_ach_prcntg) {
		this.mtd_activa_act_ach_prcntg = mtd_activa_act_ach_prcntg;
	}

	public String getMtd_activa_plan_ach_prcntg() {
		return mtd_activa_plan_ach_prcntg;
	}

	public void setMtd_activa_plan_ach_prcntg(String mtd_activa_plan_ach_prcntg) {
		this.mtd_activa_plan_ach_prcntg = mtd_activa_plan_ach_prcntg;
	}

	public String getMtd_activa_plan_manmonth() {
		return mtd_activa_plan_manmonth;
	}

	public void setMtd_activa_plan_manmonth(String mtd_activa_plan_manmonth) {
		this.mtd_activa_plan_manmonth = mtd_activa_plan_manmonth;
	}

	public String getMtd_activa_plan_active() {
		return mtd_activa_plan_active;
	}

	public void setMtd_activa_plan_active(String mtd_activa_plan_active) {
		this.mtd_activa_plan_active = mtd_activa_plan_active;
	}

	public String getGpa_score() {
		return gpa_score;
	}

	public void setGpa_score(String gpa_score) {
		this.gpa_score = gpa_score;
	}

	public String getPerform_activation_ach_p() {
		return perform_activation_ach_p;
	}

	public void setPerform_activation_ach_p(String perform_activation_ach_p) {
		this.perform_activation_ach_p = perform_activation_ach_p;
	}

	public String getPerform_adj_mfyp_plan_ach_p() {
		return perform_adj_mfyp_plan_ach_p;
	}

	public void setPerform_adj_mfyp_plan_ach_p(String perform_adj_mfyp_plan_ach_p) {
		this.perform_adj_mfyp_plan_ach_p = perform_adj_mfyp_plan_ach_p;
	}

	public String getPerform_15th_month_pers_qtd_p() {
		return perform_15th_month_pers_qtd_p;
	}

	public void setPerform_15th_month_pers_qtd_p(String perform_15th_month_pers_qtd_p) {
		this.perform_15th_month_pers_qtd_p = perform_15th_month_pers_qtd_p;
	}

	public String getMtd_adj_mfyp_ach_prcntg() {
		return mtd_adj_mfyp_ach_prcntg;
	}

	public void setMtd_adj_mfyp_ach_prcntg(String mtd_adj_mfyp_ach_prcntg) {
		this.mtd_adj_mfyp_ach_prcntg = mtd_adj_mfyp_ach_prcntg;
	}

	public String getMtd_adj_mfyp_plan() {
		return mtd_adj_mfyp_plan;
	}

	public void setMtd_adj_mfyp_plan(String mtd_adj_mfyp_plan) {
		this.mtd_adj_mfyp_plan = mtd_adj_mfyp_plan;
	}

	public String getMtd_adj_mfyp_actual() {
		return mtd_adj_mfyp_actual;
	}

	public void setMtd_adj_mfyp_actual(String mtd_adj_mfyp_actual) {
		this.mtd_adj_mfyp_actual = mtd_adj_mfyp_actual;
	}

	public String getQtd_adj_mfyp_ach_prcntg() {
		return qtd_adj_mfyp_ach_prcntg;
	}

	public void setQtd_adj_mfyp_ach_prcntg(String qtd_adj_mfyp_ach_prcntg) {
		this.qtd_adj_mfyp_ach_prcntg = qtd_adj_mfyp_ach_prcntg;
	}

	public String getQtd_adj_mfyp_plan() {
		return qtd_adj_mfyp_plan;
	}

	public void setQtd_adj_mfyp_plan(String qtd_adj_mfyp_plan) {
		this.qtd_adj_mfyp_plan = qtd_adj_mfyp_plan;
	}

	public String getQtd_adj_mfyp_actual() {
		return qtd_adj_mfyp_actual;
	}

	public void setQtd_adj_mfyp_actual(String qtd_adj_mfyp_actual) {
		this.qtd_adj_mfyp_actual = qtd_adj_mfyp_actual;
	}

	public String getYtd_adj_mfyp_ach_prcntg() {
		return ytd_adj_mfyp_ach_prcntg;
	}

	public void setYtd_adj_mfyp_ach_prcntg(String ytd_adj_mfyp_ach_prcntg) {
		this.ytd_adj_mfyp_ach_prcntg = ytd_adj_mfyp_ach_prcntg;
	}

	public String getYtd_adj_mfyp_plan() {
		return ytd_adj_mfyp_plan;
	}

	public void setYtd_adj_mfyp_plan(String ytd_adj_mfyp_plan) {
		this.ytd_adj_mfyp_plan = ytd_adj_mfyp_plan;
	}

	public String getYtd_adj_mfyp_actual() {
		return ytd_adj_mfyp_actual;
	}

	public void setYtd_adj_mfyp_actual(String ytd_adj_mfyp_actual) {
		this.ytd_adj_mfyp_actual = ytd_adj_mfyp_actual;
	}

	public String getActivisa_mtd_plan_prcntg() {
		return activisa_mtd_plan_prcntg;
	}

	public void setActivisa_mtd_plan_prcntg(String activisa_mtd_plan_prcntg) {
		this.activisa_mtd_plan_prcntg = activisa_mtd_plan_prcntg;
	}

	public String getPromo_adj_p_mfyp_in_lacs_act() {
		return promo_adj_p_mfyp_in_lacs_act;
	}

	public void setPromo_adj_p_mfyp_in_lacs_act(String promo_adj_p_mfyp_in_lacs_act) {
		this.promo_adj_p_mfyp_in_lacs_act = promo_adj_p_mfyp_in_lacs_act;
	}

	public String getPromo_adj_p_mfyp_in_lacs_p() {
		return promo_adj_p_mfyp_in_lacs_p;
	}

	public void setPromo_adj_p_mfyp_in_lacs_p(String promo_adj_p_mfyp_in_lacs_p) {
		this.promo_adj_p_mfyp_in_lacs_p = promo_adj_p_mfyp_in_lacs_p;
	}

	public String getPromo_paid_cases_act() {
		return promo_paid_cases_act;
	}

	public void setPromo_paid_cases_act(String promo_paid_cases_act) {
		this.promo_paid_cases_act = promo_paid_cases_act;
	}

	public String getPromo_paid_cases_p() {
		return promo_paid_cases_p;
	}

	public void setPromo_paid_cases_p(String promo_paid_cases_p) {
		this.promo_paid_cases_p = promo_paid_cases_p;
	}

	public String getPromo_15m_pers_in_lacs_p() {
		return promo_15m_pers_in_lacs_p;
	}

	public void setPromo_15m_pers_in_lacs_p(String promo_15m_pers_in_lacs_p) {
		this.promo_15m_pers_in_lacs_p = promo_15m_pers_in_lacs_p;
	}

	public String getMtd_adj_mfyp_in_lac_ach_prcntg() {
		return mtd_adj_mfyp_in_lac_ach_prcntg;
	}

	public void setMtd_adj_mfyp_in_lac_ach_prcntg(String mtd_adj_mfyp_in_lac_ach_prcntg) {
		this.mtd_adj_mfyp_in_lac_ach_prcntg = mtd_adj_mfyp_in_lac_ach_prcntg;
	}

	public String getMtd_adj_mfyp_in_lac_plan() {
		return mtd_adj_mfyp_in_lac_plan;
	}

	public void setMtd_adj_mfyp_in_lac_plan(String mtd_adj_mfyp_in_lac_plan) {
		this.mtd_adj_mfyp_in_lac_plan = mtd_adj_mfyp_in_lac_plan;
	}

	public String getMtd_adj_mfyp_in_lac_actual() {
		return mtd_adj_mfyp_in_lac_actual;
	}

	public void setMtd_adj_mfyp_in_lac_actual(String mtd_adj_mfyp_in_lac_actual) {
		this.mtd_adj_mfyp_in_lac_actual = mtd_adj_mfyp_in_lac_actual;
	}

	public String getQtd_adj_mfyp_in_lac_ach_prcntg() {
		return qtd_adj_mfyp_in_lac_ach_prcntg;
	}

	public void setQtd_adj_mfyp_in_lac_ach_prcntg(String qtd_adj_mfyp_in_lac_ach_prcntg) {
		this.qtd_adj_mfyp_in_lac_ach_prcntg = qtd_adj_mfyp_in_lac_ach_prcntg;
	}

	public String getQtd_adj_mfyp_in_lac_plan() {
		return qtd_adj_mfyp_in_lac_plan;
	}

	public void setQtd_adj_mfyp_in_lac_plan(String qtd_adj_mfyp_in_lac_plan) {
		this.qtd_adj_mfyp_in_lac_plan = qtd_adj_mfyp_in_lac_plan;
	}

	public String getQtd_adj_mfyp_in_lac_actual() {
		return qtd_adj_mfyp_in_lac_actual;
	}

	public void setQtd_adj_mfyp_in_lac_actual(String qtd_adj_mfyp_in_lac_actual) {
		this.qtd_adj_mfyp_in_lac_actual = qtd_adj_mfyp_in_lac_actual;
	}

	public String getYtd_adj_mfyp_in_lac_ach_prcntg() {
		return ytd_adj_mfyp_in_lac_ach_prcntg;
	}

	public void setYtd_adj_mfyp_in_lac_ach_prcntg(String ytd_adj_mfyp_in_lac_ach_prcntg) {
		this.ytd_adj_mfyp_in_lac_ach_prcntg = ytd_adj_mfyp_in_lac_ach_prcntg;
	}

	public String getYtd_adj_mfyp_in_lac_plan() {
		return ytd_adj_mfyp_in_lac_plan;
	}

	public void setYtd_adj_mfyp_in_lac_plan(String ytd_adj_mfyp_in_lac_plan) {
		this.ytd_adj_mfyp_in_lac_plan = ytd_adj_mfyp_in_lac_plan;
	}

	public String getYtd_adj_mfyp_in_lac_actual() {
		return ytd_adj_mfyp_in_lac_actual;
	}

	public void setYtd_adj_mfyp_in_lac_actual(String ytd_adj_mfyp_in_lac_actual) {
		this.ytd_adj_mfyp_in_lac_actual = ytd_adj_mfyp_in_lac_actual;
	}

	public String getPromo_wtg_fyp_act_6m() {
		return promo_wtg_fyp_act_6m;
	}

	public void setPromo_wtg_fyp_act_6m(String promo_wtg_fyp_act_6m) {
		this.promo_wtg_fyp_act_6m = promo_wtg_fyp_act_6m;
	}

	public String getPromo_wtg_fyp_ach_p_6m() {
		return promo_wtg_fyp_ach_p_6m;
	}

	public void setPromo_wtg_fyp_ach_p_6m(String promo_wtg_fyp_ach_p_6m) {
		this.promo_wtg_fyp_ach_p_6m = promo_wtg_fyp_ach_p_6m;
	}

	public String getPromo_nop_act_6m() {
		return promo_nop_act_6m;
	}

	public void setPromo_nop_act_6m(String promo_nop_act_6m) {
		this.promo_nop_act_6m = promo_nop_act_6m;
	}

	public String getPromo_nop_ach_p_6m() {
		return promo_nop_ach_p_6m;
	}

	public void setPromo_nop_ach_p_6m(String promo_nop_ach_p_6m) {
		this.promo_nop_ach_p_6m = promo_nop_ach_p_6m;
	}

	public String getPromo_collection_ach_p() {
		return promo_collection_ach_p;
	}

	public void setPromo_collection_ach_p(String promo_collection_ach_p) {
		this.promo_collection_ach_p = promo_collection_ach_p;
	}

	public String getPromo_wtg_fyp_act_9m() {
		return promo_wtg_fyp_act_9m;
	}

	public void setPromo_wtg_fyp_act_9m(String promo_wtg_fyp_act_9m) {
		this.promo_wtg_fyp_act_9m = promo_wtg_fyp_act_9m;
	}

	public String getPromo_wtg_fyp_ach_p_9m() {
		return promo_wtg_fyp_ach_p_9m;
	}

	public void setPromo_wtg_fyp_ach_p_9m(String promo_wtg_fyp_ach_p_9m) {
		this.promo_wtg_fyp_ach_p_9m = promo_wtg_fyp_ach_p_9m;
	}

	public String getPromo_nop_act_9m() {
		return promo_nop_act_9m;
	}

	public void setPromo_nop_act_9m(String promo_nop_act_9m) {
		this.promo_nop_act_9m = promo_nop_act_9m;
	}

	public String getPromo_nop_ach_p_9m() {
		return promo_nop_ach_p_9m;
	}

	public void setPromo_nop_ach_p_9m(String promo_nop_ach_p_9m) {
		this.promo_nop_ach_p_9m = promo_nop_ach_p_9m;
	}

	public String getPromo_wtg_fyp_act12m() {
		return promo_wtg_fyp_act12m;
	}

	public void setPromo_wtg_fyp_act12m(String promo_wtg_fyp_act12m) {
		this.promo_wtg_fyp_act12m = promo_wtg_fyp_act12m;
	}

	public String getPromo_wtg_fyp_ach_p_12m() {
		return promo_wtg_fyp_ach_p_12m;
	}

	public void setPromo_wtg_fyp_ach_p_12m(String promo_wtg_fyp_ach_p_12m) {
		this.promo_wtg_fyp_ach_p_12m = promo_wtg_fyp_ach_p_12m;
	}

	public String getPromo_nop_act12m() {
		return promo_nop_act12m;
	}

	public void setPromo_nop_act12m(String promo_nop_act12m) {
		this.promo_nop_act12m = promo_nop_act12m;
	}

	public String getPromo_nop_ach_p_12m() {
		return promo_nop_ach_p_12m;
	}

	public void setPromo_nop_ach_p_12m(String promo_nop_ach_p_12m) {
		this.promo_nop_ach_p_12m = promo_nop_ach_p_12m;
	}

	public String getYtd_wtg_fyp_plan() {
		return ytd_wtg_fyp_plan;
	}

	public void setYtd_wtg_fyp_plan(String ytd_wtg_fyp_plan) {
		this.ytd_wtg_fyp_plan = ytd_wtg_fyp_plan;
	}

	public String getYtd_wtg_fyp_actual() {
		return ytd_wtg_fyp_actual;
	}

	public void setYtd_wtg_fyp_actual(String ytd_wtg_fyp_actual) {
		this.ytd_wtg_fyp_actual = ytd_wtg_fyp_actual;
	}

	public String getMtd_g3_wtg_fyp_ach_prcntg() {
		return mtd_g3_wtg_fyp_ach_prcntg;
	}

	public void setMtd_g3_wtg_fyp_ach_prcntg(String mtd_g3_wtg_fyp_ach_prcntg) {
		this.mtd_g3_wtg_fyp_ach_prcntg = mtd_g3_wtg_fyp_ach_prcntg;
	}

	public String getMtd_g3_wtg_fyp_plan() {
		return mtd_g3_wtg_fyp_plan;
	}

	public void setMtd_g3_wtg_fyp_plan(String mtd_g3_wtg_fyp_plan) {
		this.mtd_g3_wtg_fyp_plan = mtd_g3_wtg_fyp_plan;
	}

	public String getMtd_g3_wtg_fyp_actual() {
		return mtd_g3_wtg_fyp_actual;
	}

	public void setMtd_g3_wtg_fyp_actual(String mtd_g3_wtg_fyp_actual) {
		this.mtd_g3_wtg_fyp_actual = mtd_g3_wtg_fyp_actual;
	}

	public String getQtd_g3_wtg_fyp_ach_prcntg() {
		return qtd_g3_wtg_fyp_ach_prcntg;
	}

	public void setQtd_g3_wtg_fyp_ach_prcntg(String qtd_g3_wtg_fyp_ach_prcntg) {
		this.qtd_g3_wtg_fyp_ach_prcntg = qtd_g3_wtg_fyp_ach_prcntg;
	}

	public String getQtd_g3_wtg_fyp_plan() {
		return qtd_g3_wtg_fyp_plan;
	}

	public void setQtd_g3_wtg_fyp_plan(String qtd_g3_wtg_fyp_plan) {
		this.qtd_g3_wtg_fyp_plan = qtd_g3_wtg_fyp_plan;
	}

	public String getQtd_g3_wtg_fyp_actual() {
		return qtd_g3_wtg_fyp_actual;
	}

	public void setQtd_g3_wtg_fyp_actual(String qtd_g3_wtg_fyp_actual) {
		this.qtd_g3_wtg_fyp_actual = qtd_g3_wtg_fyp_actual;
	}

	public String getYtd_g3_wtg_fyp_ach_prcntg() {
		return ytd_g3_wtg_fyp_ach_prcntg;
	}

	public void setYtd_g3_wtg_fyp_ach_prcntg(String ytd_g3_wtg_fyp_ach_prcntg) {
		this.ytd_g3_wtg_fyp_ach_prcntg = ytd_g3_wtg_fyp_ach_prcntg;
	}

	public String getYtd_g3_wtg_fyp_plan() {
		return ytd_g3_wtg_fyp_plan;
	}

	public void setYtd_g3_wtg_fyp_plan(String ytd_g3_wtg_fyp_plan) {
		this.ytd_g3_wtg_fyp_plan = ytd_g3_wtg_fyp_plan;
	}

	public String getYtd_g3_wtg_fyp_actual() {
		return ytd_g3_wtg_fyp_actual;
	}

	public void setYtd_g3_wtg_fyp_actual(String ytd_g3_wtg_fyp_actual) {
		this.ytd_g3_wtg_fyp_actual = ytd_g3_wtg_fyp_actual;
	}

	public String getAdm_tot_gpa_scor_extra_credit() {
		return adm_tot_gpa_scor_extra_credit;
	}

	public void setAdm_tot_gpa_scor_extra_credit(String adm_tot_gpa_scor_extra_credit) {
		this.adm_tot_gpa_scor_extra_credit = adm_tot_gpa_scor_extra_credit;
	}

	public String getRecruitment_mtd() {
		return recruitment_mtd;
	}

	public void setRecruitment_mtd(String recruitment_mtd) {
		this.recruitment_mtd = recruitment_mtd;
	}

	public String getRecruitment_ytd() {
		return recruitment_ytd;
	}

	public void setRecruitment_ytd(String recruitment_ytd) {
		this.recruitment_ytd = recruitment_ytd;
	}

	public String getQua_recruit_extra_cr_actual() {
		return qua_recruit_extra_cr_actual;
	}

	public void setQua_recruit_extra_cr_actual(String qua_recruit_extra_cr_actual) {
		this.qua_recruit_extra_cr_actual = qua_recruit_extra_cr_actual;
	}

	public String getQua_recruit_ach_percntg() {
		return qua_recruit_ach_percntg;
	}

	public void setQua_recruit_ach_percntg(String qua_recruit_ach_percntg) {
		this.qua_recruit_ach_percntg = qua_recruit_ach_percntg;
	}

	public String getNat_count_ftd() {
		return nat_count_ftd;
	}

	public void setNat_count_ftd(String nat_count_ftd) {
		this.nat_count_ftd = nat_count_ftd;
	}

	public String getNat_count_mtd() {
		return nat_count_mtd;
	}

	public void setNat_count_mtd(String nat_count_mtd) {
		this.nat_count_mtd = nat_count_mtd;
	}

	public String getYtd_wtg_fyp_in_lac_act() {
		return ytd_wtg_fyp_in_lac_act;
	}

	public void setYtd_wtg_fyp_in_lac_act(String ytd_wtg_fyp_in_lac_act) {
		this.ytd_wtg_fyp_in_lac_act = ytd_wtg_fyp_in_lac_act;
	}

	public String getYtd_wtg_fyp_in_lac_ach_p() {
		return ytd_wtg_fyp_in_lac_ach_p;
	}

	public void setYtd_wtg_fyp_in_lac_ach_p(String ytd_wtg_fyp_in_lac_ach_p) {
		this.ytd_wtg_fyp_in_lac_ach_p = ytd_wtg_fyp_in_lac_ach_p;
	}

	public String getQua_recruit_with_extra_cre_act() {
		return qua_recruit_with_extra_cre_act;
	}

	public void setQua_recruit_with_extra_cre_act(String qua_recruit_with_extra_cre_act) {
		this.qua_recruit_with_extra_cre_act = qua_recruit_with_extra_cre_act;
	}

	public String getQua_recruit_ach_p() {
		return qua_recruit_ach_p;
	}

	public void setQua_recruit_ach_p(String qua_recruit_ach_p) {
		this.qua_recruit_ach_p = qua_recruit_ach_p;
	}

	public String getTot_proac_agt_mm_wit_extr_cred() {
		return tot_proac_agt_mm_wit_extr_cred;
	}

	public void setTot_proac_agt_mm_wit_extr_cred(String tot_proac_agt_mm_wit_extr_cred) {
		this.tot_proac_agt_mm_wit_extr_cred = tot_proac_agt_mm_wit_extr_cred;
	}

	public String getTot_proac_agt_mm_ach_p() {
		return tot_proac_agt_mm_ach_p;
	}

	public void setTot_proac_agt_mm_ach_p(String tot_proac_agt_mm_ach_p) {
		this.tot_proac_agt_mm_ach_p = tot_proac_agt_mm_ach_p;
	}

	public String getYtd_wtg_fyp_ach_prcntg() {
		return ytd_wtg_fyp_ach_prcntg;
	}

	public void setYtd_wtg_fyp_ach_prcntg(String ytd_wtg_fyp_ach_prcntg) {
		this.ytd_wtg_fyp_ach_prcntg = ytd_wtg_fyp_ach_prcntg;
	}
	public String getPrmtn_shrtfl_adj_mfyp_pln_ach() {
		return prmtn_shrtfl_adj_mfyp_pln_ach;
	}

	public void setPrmtn_shrtfl_adj_mfyp_pln_ach(String prmtn_shrtfl_adj_mfyp_pln_ach) {
		this.prmtn_shrtfl_adj_mfyp_pln_ach = prmtn_shrtfl_adj_mfyp_pln_ach;
	}

	public String getPrmtn_shrtfl_actvn_ach() {
		return prmtn_shrtfl_actvn_ach;
	}

	public void setPrmtn_shrtfl_actvn_ach(String prmtn_shrtfl_actvn_ach) {
		this.prmtn_shrtfl_actvn_ach = prmtn_shrtfl_actvn_ach;
	}

	public String getPrmtn_shrtfl_15m_pers_qtd_ach() {
		return prmtn_shrtfl_15m_pers_qtd_ach;
	}

	public void setPrmtn_shrtfl_15m_pers_qtd_ach(String prmtn_shrtfl_15m_pers_qtd_ach) {
		this.prmtn_shrtfl_15m_pers_qtd_ach = prmtn_shrtfl_15m_pers_qtd_ach;
	}

	public String getPromo_adj_p_mfyp_in_lacs_srtfl() {
		return promo_adj_p_mfyp_in_lacs_srtfl;
	}

	public void setPromo_adj_p_mfyp_in_lacs_srtfl(String promo_adj_p_mfyp_in_lacs_srtfl) {
		this.promo_adj_p_mfyp_in_lacs_srtfl = promo_adj_p_mfyp_in_lacs_srtfl;
	}

	public String getPromo_paid_cases_shortfall() {
		return promo_paid_cases_shortfall;
	}

	public void setPromo_paid_cases_shortfall(String promo_paid_cases_shortfall) {
		this.promo_paid_cases_shortfall = promo_paid_cases_shortfall;
	}

	public String getPromo_15m_pers_shortfall() {
		return promo_15m_pers_shortfall;
	}

	public void setPromo_15m_pers_shortfall(String promo_15m_pers_shortfall) {
		this.promo_15m_pers_shortfall = promo_15m_pers_shortfall;
	}

	@Override
	public String toString() {
		return "Bean [channel=" + channel + ", sub_channel=" + sub_channel + ", ra_adm_agt_id=" + ra_adm_agt_id
				+ ", adj_mfyp_ftd=" + adj_mfyp_ftd + ", adj_mfyp_mtd=" + adj_mfyp_mtd + ", adj_mfyp_qtd=" + adj_mfyp_qtd
				+ ", adj_mfyp_ytd=" + adj_mfyp_ytd + ", inforced_ftd=" + inforced_ftd + ", inforced_mtd=" + inforced_mtd
				+ ", inforced_qtd=" + inforced_qtd + ", inforced_ytd=" + inforced_ytd + ", wtg_mfyp_mtd=" + wtg_mfyp_mtd
				+ ", wtg_mfyp_qtd=" + wtg_mfyp_qtd + ", wtg_mfyp_ytd=" + wtg_mfyp_ytd + ", policy_number="
				+ policy_number + ", pol_due_date=" + pol_due_date + ", pol_owner_dob=" + pol_owner_dob
				+ ", pol_owner_pan=" + pol_owner_pan + ", policy_status_desc=" + policy_status_desc
				+ ", pol_renewal_prm=" + pol_renewal_prm + ", due_policy_count=" + due_policy_count
				+ ", due_policy_mfyp=" + due_policy_mfyp + ", total_collection_amt=" + total_collection_amt
				+ ", total_collection_mfyp=" + total_collection_mfyp + ", rolling_collection_12mth="
				+ rolling_collection_12mth + ", rolling_mfyp_12mth=" + rolling_mfyp_12mth + ", ntu_policy_count="
				+ ntu_policy_count + ", ntu_policy_afyp=" + ntu_policy_afyp + ", nominee_name=" + nominee_name
				+ ", nominee_dob=" + nominee_dob + ", nominee_relationship=" + nominee_relationship + ", nominee_share="
				+ nominee_share + ", pol_pack_delvry_dt=" + pol_pack_delvry_dt + ", pol_med_category="
				+ pol_med_category + ", pol_fund_value=" + pol_fund_value + ", total_base_13m_pers="
				+ total_base_13m_pers + ", unpaid_base_13m_pers=" + unpaid_base_13m_pers + ", achievement_13m_pers="
				+ achievement_13m_pers + ", wip_count=" + wip_count + ", wip_mfyp=" + wip_mfyp + ", wip_afyp="
				+ wip_afyp + ", wip_adj_mfyp=" + wip_adj_mfyp + ", wip_stage=" + wip_stage + ", pol_welcom_call_status="
				+ pol_welcom_call_status + ", pol_welcom_call_region=" + pol_welcom_call_region + ", policy_ecs_dt="
				+ policy_ecs_dt + ", applied_total_afyp_ftd=" + applied_total_afyp_ftd + ", applied_total_afyp_mtd="
				+ applied_total_afyp_mtd + ", applied_total_afyp_qtd=" + applied_total_afyp_qtd
				+ ", applied_total_afyp_ytd=" + applied_total_afyp_ytd + ", applied_count_ftd=" + applied_count_ftd
				+ ", applied_count_mtd=" + applied_count_mtd + ", applied_count_qtd=" + applied_count_qtd
				+ ", applied_count_ytd=" + applied_count_ytd + ", activisa_mtd_prcntg=" + activisa_mtd_prcntg
				+ ", activisa_mtd_manmonth=" + activisa_mtd_manmonth + ", activisa_mtd_active=" + activisa_mtd_active
				+ ", mtd_activa_act_ach_prcntg=" + mtd_activa_act_ach_prcntg + ", mtd_activa_plan_ach_prcntg="
				+ mtd_activa_plan_ach_prcntg + ", mtd_activa_plan_manmonth=" + mtd_activa_plan_manmonth
				+ ", mtd_activa_plan_active=" + mtd_activa_plan_active + ", gpa_score=" + gpa_score
				+ ", perform_activation_ach_p=" + perform_activation_ach_p + ", perform_adj_mfyp_plan_ach_p="
				+ perform_adj_mfyp_plan_ach_p + ", perform_15th_month_pers_qtd_p=" + perform_15th_month_pers_qtd_p
				+ ", mtd_adj_mfyp_ach_prcntg=" + mtd_adj_mfyp_ach_prcntg + ", mtd_adj_mfyp_plan=" + mtd_adj_mfyp_plan
				+ ", mtd_adj_mfyp_actual=" + mtd_adj_mfyp_actual + ", qtd_adj_mfyp_ach_prcntg="
				+ qtd_adj_mfyp_ach_prcntg + ", qtd_adj_mfyp_plan=" + qtd_adj_mfyp_plan + ", qtd_adj_mfyp_actual="
				+ qtd_adj_mfyp_actual + ", ytd_adj_mfyp_ach_prcntg=" + ytd_adj_mfyp_ach_prcntg + ", ytd_adj_mfyp_plan="
				+ ytd_adj_mfyp_plan + ", ytd_adj_mfyp_actual=" + ytd_adj_mfyp_actual
				+ ", prmtn_shrtfl_adj_mfyp_pln_ach=" + prmtn_shrtfl_adj_mfyp_pln_ach + ", prmtn_shrtfl_actvn_ach="
				+ prmtn_shrtfl_actvn_ach + ", prmtn_shrtfl_15m_pers_qtd_ach=" + prmtn_shrtfl_15m_pers_qtd_ach
				+ ", activisa_mtd_plan_prcntg=" + activisa_mtd_plan_prcntg + ", promo_adj_p_mfyp_in_lacs_act="
				+ promo_adj_p_mfyp_in_lacs_act + ", promo_adj_p_mfyp_in_lacs_p=" + promo_adj_p_mfyp_in_lacs_p
				+ ", promo_paid_cases_act=" + promo_paid_cases_act + ", promo_paid_cases_p=" + promo_paid_cases_p
				+ ", promo_15m_pers_in_lacs_p=" + promo_15m_pers_in_lacs_p + ", mtd_adj_mfyp_in_lac_ach_prcntg="
				+ mtd_adj_mfyp_in_lac_ach_prcntg + ", mtd_adj_mfyp_in_lac_plan=" + mtd_adj_mfyp_in_lac_plan
				+ ", mtd_adj_mfyp_in_lac_actual=" + mtd_adj_mfyp_in_lac_actual + ", qtd_adj_mfyp_in_lac_ach_prcntg="
				+ qtd_adj_mfyp_in_lac_ach_prcntg + ", qtd_adj_mfyp_in_lac_plan=" + qtd_adj_mfyp_in_lac_plan
				+ ", qtd_adj_mfyp_in_lac_actual=" + qtd_adj_mfyp_in_lac_actual + ", ytd_adj_mfyp_in_lac_ach_prcntg="
				+ ytd_adj_mfyp_in_lac_ach_prcntg + ", ytd_adj_mfyp_in_lac_plan=" + ytd_adj_mfyp_in_lac_plan
				+ ", ytd_adj_mfyp_in_lac_actual=" + ytd_adj_mfyp_in_lac_actual + ", promo_adj_p_mfyp_in_lacs_srtfl="
				+ promo_adj_p_mfyp_in_lacs_srtfl + ", promo_paid_cases_shortfall=" + promo_paid_cases_shortfall
				+ ", promo_15m_pers_shortfall=" + promo_15m_pers_shortfall + ", promo_wtg_fyp_act_6m="
				+ promo_wtg_fyp_act_6m + ", promo_wtg_fyp_ach_p_6m=" + promo_wtg_fyp_ach_p_6m + ", promo_nop_act_6m="
				+ promo_nop_act_6m + ", promo_nop_ach_p_6m=" + promo_nop_ach_p_6m + ", promo_collection_ach_p="
				+ promo_collection_ach_p + ", promo_wtg_fyp_act_9m=" + promo_wtg_fyp_act_9m
				+ ", promo_wtg_fyp_ach_p_9m=" + promo_wtg_fyp_ach_p_9m + ", promo_nop_act_9m=" + promo_nop_act_9m
				+ ", promo_nop_ach_p_9m=" + promo_nop_ach_p_9m + ", promo_wtg_fyp_act12m=" + promo_wtg_fyp_act12m
				+ ", promo_wtg_fyp_ach_p_12m=" + promo_wtg_fyp_ach_p_12m + ", promo_nop_act12m=" + promo_nop_act12m
				+ ", promo_nop_ach_p_12m=" + promo_nop_ach_p_12m + ", ytd_wtg_fyp_plan=" + ytd_wtg_fyp_plan
				+ ", ytd_wtg_fyp_actual=" + ytd_wtg_fyp_actual + ", mtd_g3_wtg_fyp_ach_prcntg="
				+ mtd_g3_wtg_fyp_ach_prcntg + ", mtd_g3_wtg_fyp_plan=" + mtd_g3_wtg_fyp_plan
				+ ", mtd_g3_wtg_fyp_actual=" + mtd_g3_wtg_fyp_actual + ", qtd_g3_wtg_fyp_ach_prcntg="
				+ qtd_g3_wtg_fyp_ach_prcntg + ", qtd_g3_wtg_fyp_plan=" + qtd_g3_wtg_fyp_plan
				+ ", qtd_g3_wtg_fyp_actual=" + qtd_g3_wtg_fyp_actual + ", ytd_g3_wtg_fyp_ach_prcntg="
				+ ytd_g3_wtg_fyp_ach_prcntg + ", ytd_g3_wtg_fyp_plan=" + ytd_g3_wtg_fyp_plan
				+ ", ytd_g3_wtg_fyp_actual=" + ytd_g3_wtg_fyp_actual + ", adm_tot_gpa_scor_extra_credit="
				+ adm_tot_gpa_scor_extra_credit + ", recruitment_mtd=" + recruitment_mtd + ", recruitment_ytd="
				+ recruitment_ytd + ", qua_recruit_extra_cr_actual=" + qua_recruit_extra_cr_actual
				+ ", qua_recruit_ach_percntg=" + qua_recruit_ach_percntg + ", nat_count_ftd=" + nat_count_ftd
				+ ", nat_count_mtd=" + nat_count_mtd + ", ytd_wtg_fyp_in_lac_act=" + ytd_wtg_fyp_in_lac_act
				+ ", ytd_wtg_fyp_in_lac_ach_p=" + ytd_wtg_fyp_in_lac_ach_p + ", qua_recruit_with_extra_cre_act="
				+ qua_recruit_with_extra_cre_act + ", qua_recruit_ach_p=" + qua_recruit_ach_p
				+ ", tot_proac_agt_mm_wit_extr_cred=" + tot_proac_agt_mm_wit_extr_cred + ", tot_proac_agt_mm_ach_p="
				+ tot_proac_agt_mm_ach_p + ", ytd_wtg_fyp_ach_prcntg=" + ytd_wtg_fyp_ach_prcntg + ", BTCH_TIMSTAMP="
				+ BTCH_TIMSTAMP + ", REAL_TIM_TIMSTAMP=" + REAL_TIM_TIMSTAMP + "]";
	}
}
