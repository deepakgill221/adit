package com.qc.api.service.impl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;
import com.qc.api.entity.DataBean;
import com.qc.api.response.WebhookResponse;
import com.qc.api.service.APIConsumerService;
import com.qc.common.CallingJavaService;
/*===================Sprint 3.2===========START====================*/
import com.qc.service.messageimpl.Activation;
import com.qc.service.messageimpl.ActivationPlan;
import com.qc.service.messageimpl.AdjMFYP;
import com.qc.service.messageimpl.AppliedCases;
import com.qc.service.messageimpl.AppliedFYP;
import com.qc.service.messageimpl.Collection;
import com.qc.service.messageimpl.ECSDatePolicy;
import com.qc.service.messageimpl.FundValue;
import com.qc.service.messageimpl.GPA;
import com.qc.service.messageimpl.Help;
import com.qc.service.messageimpl.MedicalCategory;
import com.qc.service.messageimpl.Mpersistency;
import com.qc.service.messageimpl.NAT;
import com.qc.service.messageimpl.NomineeDetails;
import com.qc.service.messageimpl.Ntued;
import com.qc.service.messageimpl.PaidCases;
import com.qc.service.messageimpl.Performance;
import com.qc.service.messageimpl.PerformanceShortFall;
import com.qc.service.messageimpl.PlanAchievement;
import com.qc.service.messageimpl.PolicyPack;
import com.qc.service.messageimpl.PolicyStatus;
import com.qc.service.messageimpl.PolicyStatusDobPan;
import com.qc.service.messageimpl.PremiumDue;
import com.qc.service.messageimpl.QualityRecruitment;
import com.qc.service.messageimpl.ReasonWelcomeCallStatus;
import com.qc.service.messageimpl.Recruitment;
import com.qc.service.messageimpl.RecruitmentPlan;
import com.qc.service.messageimpl.RenewalPremium;
import com.qc.service.messageimpl.RollingCollection;
import com.qc.service.messageimpl.WIPCases;
import com.qc.service.messageimpl.WelcomeCallingStatus;
import com.qc.service.messageimpl.WtgMFYP;
/*===================Sprint 3.2============END===================*/
@Service
public class BotApiServiceImpl implements APIConsumerService
{
	@Autowired private CallingJavaService callingJavaService;
	@Autowired private DataBean dataBean;
	@Autowired private AdjMFYP  adjMFYP;
	@Autowired private Collection collection;
	@Autowired private ECSDatePolicy eCSDatePolicy;
	@Autowired private FundValue fundValue;
	@Autowired private MedicalCategory medicalCategory;
	@Autowired private Mpersistency mpersistency;
	@Autowired private NomineeDetails nomineeDetails;
	@Autowired private Ntued ntued;
	@Autowired private PaidCases paidCases;
	@Autowired private PolicyPack policyPack;
	@Autowired private PolicyStatusDobPan policyStatusDobPan;
	@Autowired private PolicyStatus policyStatus;
	@Autowired private PremiumDue premiumDue;
	@Autowired private ReasonWelcomeCallStatus reasonWelcomeCallStatus;
	@Autowired private RenewalPremium renewalPremium;
	@Autowired private RollingCollection rollingCollection;
	@Autowired private WelcomeCallingStatus welcomeCallingStatus;
	@Autowired private WIPCases wIPCases;
	@Autowired private WtgMFYP wtgMFYP;
	@Autowired private AppliedCases appliedCases;
	@Autowired private AppliedFYP appliedFYP;
	@Autowired private Help help;
	/*-----------------Spring 3.2--------------------------*/
	@Autowired private Activation activation;
	@Autowired private ActivationPlan activationPlan;	
	@Autowired private PlanAchievement planAchievement;
	@Autowired private Performance performance;
	@Autowired private PerformanceShortFall performanceShortFall;
	@Autowired private GPA gpa;
	@Autowired private Recruitment recruitment;
	@Autowired private QualityRecruitment qualityRecruitment;
	@Autowired private RecruitmentPlan recruitmentPlan;
	@Autowired private NAT nat;
	@Autowired private Bean bean;
	
	/*-----------------Spring 3.2--------------------------*/
	


	private static Logger logger = LogManager.getLogger(BotApiServiceImpl.class);
	public WebhookResponse getWipDataAll(String action, String channel, String period,String policyNumber,
			String user_ssoid, String user_sub_channel, String sessionId, String source, String raAdmAgtId, String customerName)
	{

		logger.info("Inside ServiceImpl method getWipDataAll :: SSOID :-"+user_ssoid);
		logger.info("Input's :- Action:- "+action+"\n SSOID :-"+user_ssoid+"\n channel:- "+channel+"\n period :- " +period+ "\n user_sub_channel :- "+user_sub_channel
				+ "\n sessionId :- "+ sessionId + "\n source :- "+source+" ");
		String segment="";
		String segmentAction=action.toUpperCase();
		try{
			String [] modifyAction=action.split("FLS.");
			segment=modifyAction[1].toUpperCase();
		}catch(Exception ex)
		{
			segment="AdJMFYP";
		}
		String result = null;
		String finalresponse="";
//		Bean bean = new Bean();
		

		try{
			if("FLS.MPERSISTENCYUNPAID".equalsIgnoreCase(segmentAction))
			{
				segment="MPERSISTENCY";
			}
			else if("FLS.MPERSISTENCYBASE".equalsIgnoreCase(segmentAction))
			{
				segment="MPERSISTENCY";
			}
			else if("FLS.WIPYES".equalsIgnoreCase(segmentAction))
			{
				segment="WIPCASES";
			}
			else if(segment.equalsIgnoreCase("HELP"))
			{
				finalresponse=help.helpIntent();
			}
			if("".equalsIgnoreCase(finalresponse))
			{
				logger.info("Going to call method callservice :: SSOID :- "+user_ssoid);
				result = callingJavaService.callService(segment, user_ssoid, channel, user_sub_channel, raAdmAgtId, policyNumber);
				logger.info("Method callservice has been called :: SSOID :- "+user_ssoid);
			}
		}
		catch(Exception ex)
		{
			logger.info("BotApiServiceImpl :: Exception Occourd While calling java Service :: SSOID :- "+user_ssoid+" :: " + ex);
			finalresponse="Something went wrong in BOT! Please try after sometime! (JavaService)";
		}
		try
		{
			if(result!=null && !result.isEmpty())
			{
				JSONObject object = new JSONObject(result);
				String status="";
				String [] regex = segment.split(",");
				for(int i=0; i<regex.length; i++)
				{
					String split= regex[i];
					String splitIntent=split.toUpperCase();
					if("ACTIVATION".equalsIgnoreCase(splitIntent) || "ACTIVATIONPLAN".equalsIgnoreCase(splitIntent) || "PLANACHIEVEMENT".equalsIgnoreCase(splitIntent)
							||"PERFORMANCE".equalsIgnoreCase(splitIntent) || "PERFORMANCESHORTFALL".equalsIgnoreCase(splitIntent) 
							|| "GPA".equalsIgnoreCase(splitIntent) || "RECRUITMENT".equalsIgnoreCase(splitIntent) || "QUALITYRECRUITMENT".equalsIgnoreCase(splitIntent)
							|| "RECRUITMENTPLAN".equalsIgnoreCase(splitIntent) || "NAT".equalsIgnoreCase(splitIntent))
					{
						if("AXIS BANK".equalsIgnoreCase(channel))
						{
							splitIntent="AXISBANK";
						}
						else if("BancAssurance".equalsIgnoreCase(channel) || "Yes Bank".equalsIgnoreCase(channel))
						{
							splitIntent="YBL";
						}
						else if("CAT".equalsIgnoreCase(channel))
						{
							splitIntent="CAT";
						}
						else if("Agency".equalsIgnoreCase(channel))
						{
							splitIntent="Agency";
						}
					}
					logger.info("Going to call method getDatafromJsonObject to extract value from service response :: SSOID :- "+user_ssoid);
					status = dataBean.getDatafromJsonObject(splitIntent, object,bean);
					logger.info("Method getDatafromJsonObject has been called :: SSOID :- "+user_ssoid +" :: Status :-" +status);
				}
				if("".equalsIgnoreCase(policyNumber) || "null".equalsIgnoreCase(policyNumber))
				{
					policyNumber="N/A";
				}
				if("true".equalsIgnoreCase(status))
				{
					logger.info("Switch CASE Action :: SSOID :- "+user_ssoid + " :: ACTION :- "+segmentAction);
					switch(segmentAction)
					{
					case "FLS.ADJMFYP":
					{
						logger.info("Inside Intent :: FLS.ADJMFYP");
						finalresponse=adjMFYP.adjMFYPIntent();
						logger.info("Outside Intent :: FLS.ADJMFYP");
					}
					break;
					case "FLS.PAIDCASES":
					{
						logger.info("Inside Intent :: FLS.PAIDCASES");
						finalresponse=paidCases.paidCasesIntent();
						logger.info("Outside Intent :: FLS.PAIDCASES");
					}
					break;
					case "FLS.WTGMFYP":
					{
						logger.info("Inside Intent :: FLS.WTGMFYP");
						finalresponse=wtgMFYP.wtgMFYPIntent();
						logger.info("Outside Intent :: FLS.WTGMFYP");
					}
					break;
					case "FLS.POLICYSTATUS":
					{
						logger.info("Inside Intent :: FLS.POLICYSTATUS");
						finalresponse=policyStatus.policyStatusIntent(policyNumber,bean);
						logger.info("Outside Intent :: FLS.POLICYSTATUS");
					}
					break;
					case "FLS.POLICYSTATUSDOBPAN":
					{
						logger.info("Inside Intent :: FLS.POLICYSTATUSDOBPAN");
						finalresponse=policyStatusDobPan.policyStatusDobPanIntent(customerName);
						logger.info("Outside Intent :: FLS.POLICYSTATUSDOBPAN");
					}
					break;
					case "FLS.RENEWALPREMIUM":
					{
						logger.info("Inside Intent :: FLS.RENEWALPREMIUM");
						finalresponse=renewalPremium.renewalPremiumIntent(policyNumber);
						logger.info("Outside Intent :: FLS.RENEWALPREMIUM");
					}
					break;
					case "FLS.PREMIUMDUE":
					{
						logger.info("Inside Intent :: FLS.PREMIUMDUE");
						finalresponse=premiumDue.premiumDueIntent();
						logger.info("Outside Intent :: FLS.PREMIUMDUE");
					}
					break;
					case "FLS.COLLECTION":
					{
						logger.info("Inside Intent :: FLS.COLLECTION");
						finalresponse=collection.collectionIntent();
						logger.info("Outside Intent :: FLS.COLLECTION");
					}
					break;

					case "FLS.ROLLINGCOLLECTION":
					{
						logger.info("Inside Intent :: FLS.ROLLINGCOLLECTION");
						finalresponse=rollingCollection.rollingCollectionIntent();
						logger.info("Outside Intent :: FLS.ROLLINGCOLLECTION");
					}
					break;
					case "FLS.NTUED":
					{
						logger.info("Inside Intent :: FLS.NTUED");
						finalresponse=ntued.ntuedIntent();
						logger.info("Outside Intent :: FLS.NTUED");
					}
					break;
					case "FLS.NOMINEEDETAILS":
					{
						logger.info("Inside Intent :: FLS.NOMINEEDETAILS");
					/*if(!"".equalsIgnoreCase(policyNumber) && policyNumber!=null)
					{
						finalresponse=nomineeDetails.nomineeDetailsIntent(policyNumber, object);
					}
					else
					{
						finalresponse="PolicyNo. required ! ";
					}*/
						finalresponse="Sorry! This information is not available";
						logger.info("Outside Intent :: FLS.NOMINEEDETAILS");
					}
					break;
					case "FLS.POLICYPACK":
					{
						logger.info("Inside Intent :: FLS.POLICYPACK");
						finalresponse=policyPack.policyPackIntent();
						logger.info("Outside Intent :: FLS.POLICYPACK");
					}
					break;
					case "FLS.MEDICALCATEGORY":
					{
						logger.info("Inside Intent :: FLS.MEDICALCATEGORY");
						if(!"".equalsIgnoreCase(policyNumber))
						{
							finalresponse=medicalCategory.medicalCategoryIntent(policyNumber);
						}else
						{
							finalresponse="PolicyNo. required ! ";
						}
						logger.info("Outside Intent :: FLS.MEDICALCATEGORY");
					}
					break;
					case "FLS.FUNDVALUE":
					{
						logger.info("Inside Intent :: FLS.FUNDVALUE");
						finalresponse=fundValue.fundValueIntent(policyNumber);
						logger.info("Outside Intent :: FLS.FUNDVALUE");
					}
					break;
					case "FLS.ECSDATEPOLICY":
					{
						logger.info("Inside Intent :: FLS.ECSDATEPOLICY");
						finalresponse=eCSDatePolicy.eCSDatePolicyIntent(policyNumber);
						logger.info("Outside Intent :: FLS.ECSDATEPOLICY");
					}
					break;
					case "FLS.WELCOMECALLINGSTATUS":
					{
						logger.info("Inside Intent :: FLS.WELCOMECALLINGSTATUS");
						finalresponse=welcomeCallingStatus.welcomeCallingStatusIntent(policyNumber);
						logger.info("Outside Intent :: FLS.WELCOMECALLINGSTATUS");
					}
					break;
					case "FLS.REASONWELCOMECALLSTATUS":
					{
						logger.info("Inside Intent :: FLS.REASONWELCOMECALLSTATUS");
						finalresponse=reasonWelcomeCallStatus.reasonWelcomeCallStatusIntent();
						logger.info("Outside Intent :: FLS.REASONWELCOMECALLSTATUS");
					}
					break;
					case "FLS.MPERSISTENCY":
					{
						logger.info("Inside Intent :: FLS.MPERSISTENCY");
						finalresponse=mpersistency.mPersistencyIntent(segmentAction);
						logger.info("Outside Intent :: FLS.MPERSISTENCY");
					}
					break;
					case "FLS.MPERSISTENCYBASE":
					{
						logger.info("Inside Intent :: FLS.MPERSISTENCYBASE");
						finalresponse=mpersistency.mPersistencyIntent(segmentAction);
						logger.info("Outside Intent :: FLS.MPERSISTENCYBASE");
					}
					break;
					case "FLS.MPERSISTENCYUNPAID":
					{
						logger.info("Inside Intent :: FLS.MPERSISTENCYUNPAID");
						finalresponse=mpersistency.mPersistencyIntent(segmentAction);
						logger.info("Outside Intent :: FLS.MPERSISTENCYUNPAID");
					}
					break;
					case "FLS.WIPCASES":
					{
						logger.info("Inside Intent :: FLS.WIPCASES");
						String wipyes="";
						finalresponse=wIPCases.wipCasesIntent(object, wipyes);
						logger.info("Outside Intent :: FLS.WIPCASES");
					}
					break;
					case "FLS.WIPYES":
					{
						logger.info("Inside Intent :: FLS.WIPYES");
						String wipyes = "WIPYES";
						finalresponse=wIPCases.wipCasesIntent(object, wipyes );
						logger.info("Outside Intent :: FLS.WIPYES");
					}
					break;
					case "FLS.APPLIEDCASES":
					{
						logger.info("Inside Intent :: FLS.APPLIEDCASES");
						finalresponse=appliedCases.appliedCasesIntent();
						logger.info("Outside Intent :: FLS.APPLIEDCASES");

					}
					break;
					case "FLS.APPLIEDFYP":
					{
						logger.info("Inside Intent :: FLS.APPLIEDFYP");
						finalresponse=appliedFYP.appliedFYPIntent();
						logger.info("Outside Intent :: FLS.APPLIEDFYP");

					}
					break;
					/*---------------------------------------------------------------RABOT SPRINT 3.2---------------------------------------------------------------*/
					case "FLS.ACTIVATION":
					{
						logger.info("Inside Intent :: FLS.ACTIVATION");
						finalresponse=activation.activationIntent(channel);
						logger.info("Outside Intent :: FLS.ACTIVATION");
					}
					break;
					case "FLS.ACTIVATIONPLAN":
					{
						logger.info("Inside Intent :: FLS.ACTIVATIONPLAN");
						finalresponse=activationPlan.activationPlanIntent(channel);
						logger.info("Outside Intent :: FLS.ACTIVATIONPLAN");
					}
					break;
					case "FLS.PLANACHIEVEMENT":
					{
						logger.info("Inside Intent :: FLS.PLANACHIEVEMENT");
						finalresponse=planAchievement.planAchievementIntent(channel);
						logger.info("Outside Intent :: FLS.PLANACHIEVEMENT");
					}
					break;
					case "FLS.PERFORMANCE":
					{
						logger.info("Inside Intent :: FLS.PERFORMANCE");
						finalresponse=performance.performanceIntent(channel);
						logger.info("Outside Intent :: FLS.PERFORMANCE");
					}
					break;
					case "FLS.PERFORMANCESHORTFALL":
					{
						logger.info("Inside Intent :: FLS.PERFORMANCESHORTFALL");
						finalresponse=performanceShortFall.performanceShortFallIntent(channel);
						logger.info("Outside Intent :: FLS.PERFORMANCESHORTFALL");
					}
					break;
					case "FLS.GPA":
					{
						logger.info("Inside Intent :: FLS.GPA");
						finalresponse=gpa.gpaIntent(channel);
						logger.info("Outside Intent :: FLS.GPA");
					}
					break;
					case "FLS.RECRUITMENT":
					{
						logger.info("Inside Intent :: FLS.RECRUITMENT");
						finalresponse=recruitment.recruitmentIntent(channel);
						logger.info("Outside Intent :: FLS.RECRUITMENT");
					}
					break;
					case "FLS.QUALITYRECRUITMENT":
					{
						logger.info("Inside Intent :: FLS.QUALITYRECRUITMENT");
						finalresponse=qualityRecruitment.qualityRecruitmentIntent(channel);
						logger.info("Outside Intent :: FLS.QUALITYRECRUITMENT");
					}
					break;
					case "FLS.RECRUITMENTPLAN":
					{
						logger.info("Inside Intent :: FLS.RECRUITMENTPLAN");
						finalresponse=recruitmentPlan.recruitmentPlanIntent(channel);
						logger.info("Outside Intent :: FLS.RECRUITMENTPLAN");
					}
					break;
					case "FLS.NAT":
					{
						logger.info("Inside Intent :: FLS.NAT");
						finalresponse=nat.natIntent(channel);
						logger.info("Outside Intent :: FLS.NAT");
					}
					break;
					default :
						finalresponse="Your action not identified by BOT! Please contact to concern team";
					}
				}
				else
				{
					finalresponse="Bean found Error! Please contact to concern team";
				}
			}
			else
			{
				if(!segment.equalsIgnoreCase("HELP"))
				{
					finalresponse="Fetched result null or empty ! Please contact to concern team";
				}
			}
		}
		catch(Exception e)
		{
			finalresponse="Something went wrong in Bot \n. Please contact to concern team.";
			logger.info("Exception occured in service :: SSOID :-"+user_ssoid +" :: Intent :-"+ segment );
		}
		String speech=finalresponse;
		logger.info("BotApiServiceImpl :: SSOID :-"+user_ssoid+" :: Action :: " + action);
		logger.info("BotApiServiceImpl :: SSOID :-"+user_ssoid+" :: speech :: " +speech);
		WebhookResponse responseObj = new WebhookResponse(speech, speech, null);
		return responseObj;
	}
	public String convertToCamelCase(String channel)
	{

		final String ACTIONABLE_DELIMITERS = " '-/"; // these cause the character following
		StringBuilder sb = new StringBuilder();
		boolean capNext = true;

		for (char c : channel.toCharArray()) {
			c = (capNext)
					? Character.toUpperCase(c)
							: Character.toLowerCase(c);
					sb.append(c);
					capNext = (ACTIONABLE_DELIMITERS.indexOf((int) c) >= 0); // explicit cast not needed
		}
		return sb.toString();
	}
}
