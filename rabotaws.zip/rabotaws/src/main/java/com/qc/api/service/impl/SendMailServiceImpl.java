package com.qc.api.service.impl;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.ResourceBundle;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.BeanProperty;
import com.qc.api.service.SendMailService;



@Service
public class SendMailServiceImpl implements SendMailService{
	
	private static Logger logger = LogManager.getLogger(SendMailServiceImpl.class);
	ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");

	@Override
	public byte[] convertPdfToByteArray(String source) {
		try {
		InputStream inputStream = new FileInputStream(source);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		int data;
		while( (data = inputStream.read()) >= 0 ) {
		    outputStream.write(data);
		}
		inputStream.close();
		return outputStream.toByteArray();
	
	}catch(Exception e) 
	{
		logger.error("Exception in converting pdf to byte array :: "+e);
		return null;
	}
	}

	@Override
	public boolean sendMail(String byteArray,String mailTo,String userName) {
		Date date =new Date();
		SimpleDateFormat formatDate = new SimpleDateFormat("dd-MM-yyyy");
		String todayDate = formatDate.format(date);
		SimpleDateFormat formatMonth = new SimpleDateFormat("MMM");
		String month = formatMonth.format(date);
		byteArray=byteArray.replaceAll("\n","");
		String output = new String();
		StringBuilder result = new StringBuilder();
		Random rand = new Random(); 
		int correlationId = rand.nextInt(10000);
		Boolean status = false;
		String[] temp = userName.split(" ");
		String firstName = getUpperCasedata(temp[0]);
		String lastName = getUpperCasedata(temp[temp.length-1]);
		userName = firstName+" "+lastName;
		try 
		{
			logger.info("Getting sendBuyerMail Process : Start");

			StringBuilder mailReq=new StringBuilder();
					
				String emailccto = "";
				mailTo = "sapna.chaudhary@maxlifeinsurance.com";
				mailReq.append("{");
				mailReq.append("\"request\": {");
				mailReq.append("\"header\": {");
				mailReq.append("\"soaCorrelationId\": \""+correlationId+"\",");
				mailReq.append("\"soaAppId\": \"POS\"");
				mailReq.append("},");
				mailReq.append("\"requestData\": {");
				mailReq.append("\"mailIdTo\": \""+mailTo+"\",");
				mailReq.append("\"mailSubject\": \"Agent Performance Report as on"+ todayDate+"  \",");
				mailReq.append("\"fromName\": \"Maxlife Insurance\",");
				mailReq.append("\"attachments\": [{");
				mailReq.append("\"fileName\": \"Agent Performance Report.xlsx\",");
				mailReq.append("\"byteArrayBase64\": \""+byteArray+"\"}");
				mailReq.append( "],");
				mailReq.append("\"isConsolidate\":false,");
				mailReq.append("\"isFileAttached\":true,");
				mailReq.append("\"fromEmail\": \"Business.intelligence@maxlifeinsurance.com\",");
				mailReq.append("\"mailBody\": \"").append("<p>Dear "+userName+",</p>\r\n" + 
						"<p>Please find attached the Agent Performance Report for the month of "+month+" for your complete patch.</p>\r\n" + 
						"<p>You will need MS-Excel to open the attachment in your computer. If you don't have MS Excel, please log a ticket in CARS with our IT team.</p>\r\n" + 
						"<p>For any queries, please write to <a href=mailto:Abhay.Kumar7@maxlifeinsurance.com>Abhay.Kumar7@maxlifeinsurance.com</a> or <a href=mailto:Alok.Sinha@maxlifeinsurance.com >Alok.Sinha@maxlifeinsurance.com </a> </p>\r\n"+
						"<br>\r\n" + 
						"<p>With regards</p>\r\n" + 
						"<p>Business Intelligence Team </p>").append("\"");
				mailReq.append("}");
				mailReq.append("}");
				mailReq.append("}");

				String pUrl = res.getString("serviceSendMail");
				logger.info("URL : "+pUrl);
				URL url = new URL(pUrl);

				HttpURLConnection conn = null;
				String DevMode = "N";    
				if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
				{
					logger.info("We are running in Development Mode So Proxy Enabled");
					Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
					conn = (HttpURLConnection) url.openConnection(proxy);
				}
				else
				{
					conn = (HttpURLConnection) url.openConnection();
				}

				HttpsURLConnection.setFollowRedirects(true);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestMethod("POST");

				
				//logger.info("Mail request BPMA : "+mailReq.toString());
				OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
				writer.write(mailReq.toString());
				
				writer.flush();
				try {writer.close(); } catch (Exception e1) {}
				int apiResponseCode = conn.getResponseCode(); 
				logger.info("API Response Code :: "+apiResponseCode);
				if(apiResponseCode == 200)
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					while ((output = br.readLine()) != null) 
					{
						result.append(output);
					}
					conn.disconnect();
					br.close();
					status=true;
					logger.info("Send Mail Status Pass : "+result.toString());
				}
				else
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
					while ((output = br.readLine()) != null) 
					{
						result.append(output);
					}
					conn.disconnect();
					br.close();
					logger.info("Send Mail Status Fail : "+result.toString());
				}	
		}catch(Exception e)
		{
			logger.error("Exception in send mail method :: "+e);
			e.printStackTrace();
			
		}
		return status;
	}

	private String getUpperCasedata(String userName) {
		
		String firstLetter = userName.substring(0,1).toUpperCase();
	      String restLetters = userName.substring(1).toLowerCase();
	      return firstLetter + restLetters;
	      
	}

	@Override
	public  String camelCase(String inputString) {
		try {
			if(inputString!=null && !"".equalsIgnoreCase(inputString))
			{
			inputString = inputString.substring(0, 1).toUpperCase() + inputString.substring(1).toLowerCase();
			}
			
		} catch (Exception e) {
			inputString = "";
		}
		return inputString;
	}
}
