/*package com.qc.api.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="TBL_SOAKPI_TRANSACTION_LOGS")
public class WipEntity  
{
	
	private long sequenceGenerated;
	private String sessionId;
	private String ssoId;
	private String kpiAsked;
	private String intentCalled;
	private String plateform;
	@Temporal(TemporalType.TIMESTAMP)
	private Date timesofLogin;
	
	@Id
	@GeneratedValue
	@Column(name="SEQUENCE")
	public long getSequenceGenerated() {
		return sequenceGenerated;
	}
	public void setSequenceGenerated(long sequenceGenerated) {
		this.sequenceGenerated = sequenceGenerated;
	}
	
	@Column(name="SSO_ID")
	public String getSsoId() {
		return ssoId;
	}
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}
	
	@Column(name="SESSION_ID")
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	@Column(name="KPI_ASKED")
	public String getKpiAsked() {
		return kpiAsked;
	}

	public void setKpiAsked(String kpiAsked) {
		this.kpiAsked = kpiAsked;
	}

	@Column(name="INTENT_CALLED")
	public String getIntentCalled() {
		return intentCalled;
	}

	public void setIntentCalled(String intentCalled) {
		this.intentCalled = intentCalled;
	}

	@Column(name="PLATFORM")
	public String getPlateform() {
		return plateform;
	}

	public void setPlateform(String plateform) {
		this.plateform = plateform;
	}
	
	@Column(name="TIME_OF_LOGIN")
	public Date getTimesofLogin() {
		return timesofLogin;
	}

	public void setTimesofLogin(Date timesofLogin) {
		this.timesofLogin = timesofLogin;
	}
	@Override
	public String toString() {
		return "WipEntity [sequenceGenerated=" + sequenceGenerated + ", sessionId=" + sessionId + ", ssoId=" + ssoId
				+ ", kpiAsked=" + kpiAsked + ", intentCalled=" + intentCalled + ", plateform=" + plateform
				+ ", timesofLogin=" + timesofLogin + "]";
	}
	
	
}
*/