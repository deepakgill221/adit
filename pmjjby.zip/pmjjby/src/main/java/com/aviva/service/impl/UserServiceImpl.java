package com.aviva.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aviva.domain.User;
import com.aviva.repository.UserRepository;
import com.aviva.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
    UserRepository userRepository;
	
	@Override
	public User createOrUpdate(User user) {
		return userRepository.saveAndFlush(user);
	}

	@Override
	public List<User> findAll() {
		return userRepository.findAll();
	}

	@Override
	public User findById(Long id) {
	    return userRepository.findOne(id);
	}

	@Override
	public User findByFirstName(String firstName) {
		return userRepository.findByFirstName(firstName);
	}

}
