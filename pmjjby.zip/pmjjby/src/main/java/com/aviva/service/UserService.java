package com.aviva.service;

import java.util.List;

import com.aviva.domain.User;

public interface UserService {

	public User createOrUpdate(User user);
	public List<User> findAll();
	public User findById(Long id);
	public User findByFirstName(String firstName);
}
