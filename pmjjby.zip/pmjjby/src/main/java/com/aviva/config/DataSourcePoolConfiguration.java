package com.aviva.config;

import java.beans.PropertyVetoException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
public class DataSourcePoolConfiguration {
	
	@Value("${hibernate.c3p0.driverClass}")
	private String driverClass;
	
	@Value("${hibernate.c3p0.jdbcUrl}")
	private String jdbcUrl;
	
	@Value("${hibernate.c3p0.username}")
	private String userName;
	
	@Value("${hibernate.c3p0.password}")
	private String password;
	
	@Value("${hibernate.c3p0.max_size}")
	private String poolMaxSize;
	
	@Value("${hibernate.c3p0.min_size}")
	private String poolMinSize;
	
	@Value("${hibernate.c3p0.max_statements}")
	private String maxStatements;
	
	@Value("${hibernate.c3p0.acquireIncrement}")
	private String acquireIncrement;
	
	@Value("${hibernate.c3p0.checkoutTimeout}")
	private String checkoutTimeout;
	
	@Value("${hibernate.c3p0.preferredTestQuery}")
	private String preferredTestQuery;
	
	@Value("${hibernate.c3p0.idleConnectionTestPeriod}")
	private String idleConnectionTestPeriod;
	
	@Value("${hibernate.c3p0.testConnectionOnCheckin}")
	private String testConnectionOnCheckin;
	
	@Value("${hibernate.c3p0.testConnectionOnCheckout}")
	private String testConnectionOnCheckout;
	
	@Value("${hibernate.c3p0.unreturnedConnectionTimeout}")
	private String unreturnedConnectionTimeout;
	
	@Value("${hibernate.c3p0.debugUnreturnedConnectionStackTraces}")
	private String debugUnreturnedConnectionStackTraces;

	
	@Bean
	public ComboPooledDataSource comboPooledDataSource(){
		ComboPooledDataSource pooledDataSource =new ComboPooledDataSource("PMJJBY");
		try {
			pooledDataSource.setDriverClass(driverClass);
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pooledDataSource.setUser(userName);
		pooledDataSource.setPassword(password);
		pooledDataSource.setJdbcUrl(jdbcUrl);
		pooledDataSource.setMinPoolSize(Integer.parseInt(poolMinSize));
		pooledDataSource.setMaxPoolSize(Integer.parseInt(poolMaxSize));
		pooledDataSource.setAcquireIncrement(Integer.parseInt(acquireIncrement));
		pooledDataSource.setCheckoutTimeout(Integer.parseInt(checkoutTimeout));
		pooledDataSource.setPreferredTestQuery(preferredTestQuery);
		pooledDataSource.setIdleConnectionTestPeriod(Integer.parseInt(idleConnectionTestPeriod));
		pooledDataSource.setTestConnectionOnCheckout(false);
		pooledDataSource.setTestConnectionOnCheckin(true);
		pooledDataSource.setUnreturnedConnectionTimeout(Integer.parseInt(unreturnedConnectionTimeout));
		pooledDataSource.setDebugUnreturnedConnectionStackTraces(false);
		return pooledDataSource;
	}
}
