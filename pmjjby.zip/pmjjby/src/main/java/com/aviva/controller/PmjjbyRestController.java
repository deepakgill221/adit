package com.aviva.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PmjjbyRestController {

	@RequestMapping("/hello")
	public String hello() {
		return "hello";
	}
}
