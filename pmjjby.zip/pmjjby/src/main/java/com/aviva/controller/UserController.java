package com.aviva.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aviva.domain.User;
import com.aviva.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService;
	
	@PostMapping("/create")
	public User createOrUpdate(@RequestBody User user) {
		return userService.createOrUpdate(user);
	}
	
	@GetMapping("/all")
	public List<User> findAll(){
		return userService.findAll();
	}
	
	@GetMapping("/{id}")
	public User findOne(@PathVariable Long id) {
		return userService.findById(id);
	}
	
	@GetMapping("/name/{firstName}")
	public User findByFirstName(@PathVariable String firstName) {
		return userService.findByFirstName(firstName);
	}
}
