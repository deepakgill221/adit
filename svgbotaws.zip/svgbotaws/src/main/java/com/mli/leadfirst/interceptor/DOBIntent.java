package com.mli.leadfirst.interceptor;

import java.util.Map;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface DOBIntent {
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String customerDOBIntent(Map<String,Map<String,String>> map, String sessionId);
}
