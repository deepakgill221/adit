package com.mli.leadfirst.serviceimpl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.mli.leadfirst.commons.BeanProperty;
import com.mli.leadfirst.service.SVGLeadCall;

/**
 * @author sc05216
 *
 */
@Service
public class SVGLeadCallImpl implements SVGLeadCall {

	@Autowired 
	private BeanProperty bean;
	private static Logger logger = LogManager.getLogger(SVGLeadCallImpl.class);
	/** (non-Javadoc)
	 * @see com.mli.leadfirst.service.SVGLeadCall#svgLeadCall(java.util.Map, java.lang.String)
	 */
	@Override
	public void svgLeadCall(Map<String, Map<String, String>> externalMap, String sessionId) 
	{
		logger.info("SVG :: SVGLeadCallImpl :: svgLeadCall  start");
		try{
		String name = externalMap.get(sessionId).get("name");
		String mobileNum = externalMap.get(sessionId).get("mobilenum");
		String utmSource = externalMap.get(sessionId).get("utm_source");
		String utmMedium = externalMap.get(sessionId).get("utm_medium");
		String utmCampaign = externalMap.get(sessionId).get("utm_campaign");
		String utmTerm = externalMap.get(sessionId).get("utm_term");
		String utmContent = externalMap.get(sessionId).get("utm_content");
		
		String url = bean.getSvgURL();
		String svgUserId=bean.getSvgUserId();
		String svgPassword=bean.getSvgPassword();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		StringBuilder sb=new StringBuilder();
		
		sb.append("{");
		sb.append("\"user\": \""+svgUserId+"\",");
		sb.append("\"pass\": \""+svgPassword+"\",");
		sb.append("\"camp\": 273,");
		sb.append("\"ref_id\": \"\",");
		sb.append("\"name\": \""+name+"\",");
		sb.append("\"email\": \"\",");
		sb.append("\"city\": \"\",");
		sb.append("\"date_of_birth\": \"\",");
		sb.append("\"mobile_number\": \""+mobileNum+"\",");
		sb.append("\"gender\": \"\",");
		sb.append("\"income\": \"\",");
		sb.append("\"equote\": \"\",");
		sb.append("\"smoker\": \"\",");
		sb.append("\"utm_source\": \""+utmSource + " \",");
		sb.append("\"utm_medium\": \""+utmMedium+"\",");
		sb.append("\"utm_campaign\": \""+utmCampaign+"\",");
		sb.append("\"utm_term\": \""+utmTerm+"\",");
		sb.append("\"utm_keyword\": \"\",");
		sb.append("\"utm_content\": \" "+utmContent+"\",");
		sb.append("\"client_ip\": \"\",	");
		sb.append("\"user_agent\": \"\",	");
		sb.append("\"status\": \"\"	");
		sb.append("}");

		HttpEntity<String> entity=new HttpEntity<>(sb.toString(),	headers);
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity,String.class);
		logger.info("Complete response from SVG :: "+response);
		if(response.getStatusCodeValue() == 200)
		{
			String responses = response.getBody();
			logger.info("Final response :: "+responses);
			logger.info("---sessionId-----"+sessionId+"----Response-----"+responses);
		}
		}
		catch(Exception ex){
			logger.error("Exception in svgLeadCall method for session Id :: " + sessionId + " :: " + ex);
		}
	}
}

