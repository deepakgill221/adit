package com.mli.leadfirst.interceptorimpl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.leadfirst.interceptor.MobileNumberIntent;
import com.mli.leadfirst.service.OtpGeneration;
import com.mli.leadfirst.service.SendSmsService;

/**
 * @author sc05216
 *
 */
@Service
public class MobileNumberIntentImpl implements MobileNumberIntent {
	private static Logger logger = LogManager.getLogger(MobileNumberIntentImpl.class);

	@Autowired
	private OtpGeneration otpGeneration;
	@Autowired
	private SendSmsService sendSmsService;

	private static final String RESPONSE;
	private static final String RESPONSE_DATA;
	private static final String ERROR;

	static {
		RESPONSE = "response";
		RESPONSE_DATA = "responseData";
		ERROR="Error";
	}

	/**
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String mobileNumberResponse(Map<String, Map<String, String>> map, String sessionId) {

		String speech = "";
		String otp;
		String otpUniqueTokenCode;

		try {
			logger.info("Going to call generate OTP method :: sessionId :: " + sessionId);
			String otpResponse = otpGeneration.generateOtp(map, sessionId);
			logger.info("Got response from Generate OTP sessionId :: " + sessionId);

			if (map.containsKey(sessionId)) {

				JSONObject responseJson = new JSONObject(otpResponse);
				String otpStatus = responseJson.getJSONObject(RESPONSE).getJSONObject(RESPONSE_DATA)
						.get("soaStatusCode") + "";
				if ("200".equalsIgnoreCase(otpStatus)) {
					otpUniqueTokenCode = responseJson.getJSONObject(RESPONSE).getJSONObject(RESPONSE_DATA)
							.getJSONObject("payload").get("unqTokenNo") + "";
					otp = responseJson.getJSONObject(RESPONSE).getJSONObject(RESPONSE_DATA).getJSONObject("payload")
							.get("otpCode") + "";
					System.out.println("otp is :: "+otp);
					map.get(sessionId).put("otpUniqueTokenCode", otpUniqueTokenCode);
					map.get(sessionId).put("systemOtp", otp);
					logger.info("Going to call Send SMS API :: sessionid :: " + sessionId);
					String sendSmsResponse = sendSmsService.sendSmsServiceCall(map, sessionId);
					
					JSONObject sendSmsResponseObject = new JSONObject(sendSmsResponse);
					String sendSmsStatus = sendSmsResponseObject.getJSONObject("MliSmsServiceResponse")
							.getJSONObject("responseHeader").getJSONObject("generalResponse").get("status") + "";
					logger.info("Send SMS service has been called for sessionId :: "+sessionId + " SendSmsStatud :: " + sendSmsStatus);
					if ("ok".equalsIgnoreCase(sendSmsStatus)) {
						speech = "please enter the OTP you have received on your mobile number.";
						/*speech = map.get(sessionId + "Msg").get("mobileNumber");*/
						
					} else {
						speech = map.get(sessionId + "Msg").get(ERROR);
					}
				} else {
					speech = map.get(sessionId + "Msg").get(ERROR);
				}
			} else {
				speech = map.get(sessionId + "Msg").get(ERROR) + "mobile";
			}
		} catch (Exception ex) {

			logger.error("Exception in Mobile Number Intent method :: Sessionid :: " + sessionId + " :: " + ex);
		}

		return speech;
	}
}