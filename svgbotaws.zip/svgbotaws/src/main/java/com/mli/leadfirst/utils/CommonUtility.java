package com.mli.leadfirst.utils;

import java.util.Random;

import org.springframework.stereotype.Component;

/**
 * @author sc05216
 *
 */
@Component
public class CommonUtility {
	/**
	 * @return
	 *
	 */
	public int getRandomNumber() {

		return new Random().nextInt(9000000) + 1000000;
	}
	
	
}
