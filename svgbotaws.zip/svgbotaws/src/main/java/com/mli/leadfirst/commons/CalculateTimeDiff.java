package com.mli.leadfirst.commons;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

/**
 * @author sc05216
 *
 */
@Service
public class CalculateTimeDiff 
{
	private static Logger logger = LogManager.getLogger(CalculateTimeDiff.class);
	
	private String dateFormat="MM/dd/yyyy HH:mm:ss";
	
	/**
	 * @param currentTime
	 * @param loginTime
	 * @return
	 */
	public long timeDiffInMinute(String currentTime, String loginTime)
	{
		long diffInMinutes=0;
		SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		Date d1 = null;
		Date d2 = null;
		try 
		{
			d1 = format.parse(loginTime);
			d2 = format.parse(currentTime);
			long diffInMilliseconds = d2.getTime() - d1.getTime();
			diffInMinutes = diffInMilliseconds / (60 * 1000) % 60;
		} 
		catch (Exception e) 
		{
			logger.error("We are in exception while calculating difference in minute - dates : "+currentTime+" : "+loginTime+" :: "+e);
		}
		return diffInMinutes;
	}
}
