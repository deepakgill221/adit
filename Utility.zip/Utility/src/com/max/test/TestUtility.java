package com.max.test;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.max.dao.imp.InsertDataImpl;
import com.max.utility.action.GetFileFromDirectory;

public class TestUtility {
	static Logger logger = Logger.getLogger(InsertDataImpl.class.getName());
	static ResourceBundle res=ResourceBundle.getBundle("com.mli.application.properties.ApplicationResources");
	public static void main(String[] args) {
		logger.debug("Batch Utility Started...");
		System.out.println("UtilityStarted");
		GetFileFromDirectory g1 = new GetFileFromDirectory();
		g1.getFilesAndFilesSubDirectories(res.getString("FolderPath"));
		System.out.println("UtilityFinished");
		logger.debug("Batch Utility Started...");
	}

}
