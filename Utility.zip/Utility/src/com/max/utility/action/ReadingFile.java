package com.max.utility.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mli.entity.PolicyDetails;

import au.com.bytecode.opencsv.CSVReader;

public class ReadingFile {
	
	static Logger logger = Logger.getLogger(ReadingFile.class.getName());
	@SuppressWarnings({ "rawtypes", "static-access" })
	protected  List<PolicyDetails> readingFile(String filePath) throws FileNotFoundException, IOException{
		logger.debug("File reading started for file :: " +filePath);
		System.out.println("readingFile method START for file :: " +filePath);
		String fileExtension =  GetFileFromDirectory.getFileExtension(filePath);
		List<PolicyDetails> policyDetailsList = null;
		PolicyDetails policyDetailsDto = null;
		String cellValue = "";
		String fileName = "";
		int i = 0;
		if(fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("xlsx") ){
			try(FileInputStream fileInputStream = new FileInputStream(filePath)){
				fileName = new File(filePath).getName();
				HSSFWorkbook hssfWorkbook = new HSSFWorkbook(fileInputStream);
				HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(0);
				Iterator<Row> itr = hssfSheet.rowIterator();
				policyDetailsList = new ArrayList<>();
				Row row = null;
				Cell cell = null;
				while(itr.hasNext()){
					row = (Row) itr.next();
					cell = row.getCell(0);
					if(cell != null && cell.getCellType() == Cell.CELL_TYPE_NUMERIC){
						i++;
						cell.setCellType(cell.CELL_TYPE_STRING);
						policyDetailsDto = new PolicyDetails();
						policyDetailsDto.setPolicyNo(cell.getStringCellValue());
						policyDetailsDto.setFileName(fileName);
						policyDetailsDto.setFilePath(filePath);
						policyDetailsDto.setRowNum(row.getRowNum()+"");
						policyDetailsDto.setId(i);
						policyDetailsList.add(policyDetailsDto);
						
					}
					
				}
			}
			catch(Exception ex){
				logger.error("Exception occured while reading excel file :: " +ex);
				logger.error("Issue occured in file format trying one more time :: "+filePath);
				System.out.println("Issue occured in file format trying one more time :: "+filePath);
//				System.out.println("Exception occured 1st time :: " +ex.getMessage());
				if(ex.getMessage().contains("The supplied data appears to be in the Office 2007+ XML")){
					try{
						OPCPackage pkg = OPCPackage.open(new File(filePath));
						 XSSFWorkbook wb = new XSSFWorkbook(pkg);
						 XSSFSheet sheet = wb.getSheetAt(0);
						 Iterator<Row> itr = sheet.rowIterator();
						 XSSFRow row = null;
						 XSSFCell cell = null;
						 policyDetailsList = new ArrayList<>();
						 while(itr.hasNext()){
							 row = (XSSFRow)itr.next();
							 cell = row.getCell(0);
							 if(cell != null && cell.getCellType() == cell.CELL_TYPE_NUMERIC){
								 i++;
									cell.setCellType(cell.CELL_TYPE_STRING);
									policyDetailsDto = new PolicyDetails();
									policyDetailsDto.setPolicyNo(cell.getStringCellValue());
									policyDetailsDto.setFileName(fileName);
									policyDetailsDto.setFilePath(filePath);
									policyDetailsDto.setRowNum(row.getRowNum()+"");
									policyDetailsDto.setId(i);
									policyDetailsList.add(policyDetailsDto);
							 }
						 }
					}
					catch(Exception ex1){
						logger.error("2nd time exception occured while reading excel file :: " +ex);
						System.out.println("Exception occured for 2nd time for the same excel ::  "+ex1);
					}
				}
			}
		}
		else if(fileExtension.equalsIgnoreCase("csv")){
			List<String> lineValue = null;
			try(CSVReader reader = new CSVReader(new FileReader(filePath))){
				fileName = new File(filePath).getName();
				while((lineValue = Arrays.asList(reader.readNext())) != null){
					if(!lineValue.isEmpty()){
						i++;
						policyDetailsDto = new PolicyDetails();
						policyDetailsDto.setPolicyNo(lineValue.get(0));
						policyDetailsDto.setFileName(fileName);
						policyDetailsDto.setFilePath(filePath);
						policyDetailsDto.setRowNum(i+"");
						policyDetailsDto.setId(i);
					}
				}
			}
			catch(Exception ex){
				logger.error("Exception occured while reading csv file :: " +ex);
				System.out.println("Exception occured for file :: "+filePath);
				System.out.println("Exception occured while reading CSV file :: " +ex);
			}
		}
		
		System.out.println("ReadingFile method END");
		logger.debug("File reading ended for file :: " +filePath);
		return policyDetailsList;
	}

}
