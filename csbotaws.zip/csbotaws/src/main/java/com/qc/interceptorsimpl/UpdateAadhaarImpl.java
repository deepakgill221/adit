package com.qc.interceptorsimpl;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.UpdateAadhaarPanService;
import com.qc.interceptors.UpdateAadhaar;

@Service
public class UpdateAadhaarImpl implements UpdateAadhaar{
	
	private static Logger logger = LogManager.getLogger(UpdateAadhaarImpl.class);
	String speech="";
	//String var_policyOwnerId = "";
	String aadhaar_status = "";
	String aadhaarLeadId="";
	String panTicketId="";

	@Autowired
	UpdateAadhaarPanService updateAadhaarPanService;
	
	@Override
	public String getUpdateAadhaar(String sessionId, String Aadhaar, String policyNo) 
	{
		logger.info("Start method :: getUpdateAadhaar");
		Boolean isnumeric = StringUtils.isNumeric(Aadhaar);
		int inputSize = Aadhaar.length();
		if(isnumeric && inputSize==12)
		{
			speech="I'm now updating your Aadhaar. Shall I go ahead & update the policy records?";
		}
		else
		{
			speech="Sorry the Aadhaar number you entered is invalid. Please enter a valid Aadhaar number.";
		}
		updateAadhaarPanService.getPolicy360(sessionId, policyNo);
		logger.info("End method :: getUpdateAadhaar");
		return speech;
	}

	@Override
	public String getUpdateAadhaarYes(String sessionId, Map<String, Map> personal_detail)
	{
		logger.info("Inside method :: getUpdateAadhaarYes");
		updateAadhaarPanService.getPanDetails(sessionId);
		aadhaar_status=updateAadhaarPanService.updateAadhaar(sessionId, personal_detail);
		
		if("Success".equalsIgnoreCase(aadhaar_status))
		{
			speech="Thank you for updating your Aadhaar. It will get updated in our records within 10 days. "
					+ "\n Is there anything else I can assist you with?";
		}
		else
		{
			speech="Sorry, I am unable to process your request. Kindly try again after some time. "
					+ "\n <a href='https://www.maxlifeinsurance.com/customer-service/aadhaar-update.html' target='_blank'> Click here </a> if you wish to update the Aadhar number yourself. "
					+ "\n Is there anything else I can assist you with?";
		}
		logger.info("End method :: getUpdateAadhaarYes");
		return speech;
	}
	
	@Override
	public String getLeadId(String sessionId)
	{
		logger.info("Inside method :: getLeadId");
		try
		{
		aadhaarLeadId=updateAadhaarPanService.getLeadIdForAadhaar(sessionId);
		}
		catch(Exception ex)
		{
			aadhaarLeadId="";
			logger.info("Exception while getting lead id value :: "+ex);
		}
		logger.info("End method :: getLeadId");
		return aadhaarLeadId;
	}
	
	@Override
	public String getTicketId(String sessionId)
	{
		logger.info("Inside method :: getLeadId");
		try
		{
		panTicketId=updateAadhaarPanService.getTicketIdForPan(sessionId);
		}
		catch(Exception ex)
		{
			aadhaarLeadId="";
			logger.info("Exception while getting lead id value :: "+ex);
		}
		logger.info("End method :: getLeadId");
		return panTicketId;
	}

}
