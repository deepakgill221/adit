package com.qc.interceptorsimpl;

import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.AddressDetail;
import com.qc.common.RegexMatcher;
import com.qc.interceptors.LocateusPinCode;

@Service
public class LocateusPinCodeImpl implements LocateusPinCode 
{
	@Autowired
	RegexMatcher regexMatcher;
	@Autowired
	AddressDetail addressDetail;
	String speech="";
	String sessionId = "";
	String status="";
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	private static Logger logger = LogManager.getLogger(PremiumPaymentTermImpl.class);
	@Override
	public String getLocateUsPinCode(String pinCode) {
		try {
			logger.info("Action Invoded:- PinCode");
			RegexMatcher reg = new RegexMatcher();
			status = reg.regexPatternStatus(pinCode);
		} catch (Exception ex) {
			logger.info("Exception occoured in Locateuspincode statement");
		}
		return status;
	}
}
