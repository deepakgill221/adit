package com.qc.common;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.qc.api.service.impl.CsBotServiceImpl;

@Service
public class CalculateTimeDiff 
{
	private static Logger logger = LogManager.getLogger(CsBotServiceImpl.class);
	public long timediff(String currentTime, String logntimevalue)
	{
		long diffMinutes=0;
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date d1 = null;
		Date d2 = null;
		try {
			d1 = format.parse(logntimevalue);
			d2 = format.parse(currentTime);

			//in milliseconds
			long diff = d2.getTime() - d1.getTime();

			long diffSeconds = diff / 1000 % 60;
			diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);
			
			logger.info("difference in seconds :: "+diffSeconds +" :: in minutes :: "+diffMinutes+" :: In hours :: "+diffHours+" :: In Days :: "+diffDays);


		} catch (Exception e) 
		{
			logger.error("Exception in calculating time difference :: "+e);
		}
		return diffMinutes;
	}
}
