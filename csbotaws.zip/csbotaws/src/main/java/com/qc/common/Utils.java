package com.qc.common;

import java.util.Random;

import org.springframework.stereotype.Service;

@Service
public class Utils 
{
	public int getRandomNumber()
	{
		Random rand = new Random(); 
		int randonNumber = rand.nextInt(10000);
		return randonNumber;
	}

}
