package com.qc.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class DbData 
{
	private static Logger logger = LogManager.getLogger(DbData.class);
	public String getDbData(String result)
	{
		String value="";
		try {
		JSONObject buttonObj = new JSONObject(result);
		Object csbot= buttonObj.get("csbotButtonCallPayloadResponse");
		JSONArray array = (JSONArray) csbot; 
		for (int i=0;i<array.length();i++)
		{
			value=array.get(i).toString();
		}}catch(Exception e) {
			logger.error("creating exception in getDbData "+e);
		}
		return value;
	}

}
