package com.qc.common;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

@Component
public class RegexMatcher 
{
	public int regexpattern(String str)
	{
		Pattern pattern = Pattern.compile(".*[^0-9].*");
		if( !pattern.matcher(str).matches())
		{
			Pattern digitPattern = Pattern.compile("\\d{6}");  
			if(digitPattern.matcher(str).matches())
			{
				return 1;
			}
			else
			{
				return 2;
			}
		}
		else
		{
			return 3;
		}
	}
	public String regexPatternStatus(String pincode)
	{
		int matcher = regexpattern(pincode);
		if(matcher==2 || matcher==3 )
		{
			return "Looks like you have entered incorrect PIN code, please enter valid PIN code.";
		}
		/*else if(matcher==3)
		{
			return "Looks like you have entered incorrect PIN code, please enter valid PIN code.";
		}*/
		return "matched";
	}
	
	public boolean isValidEmailAddress(String email){
		   
		 
	        boolean aaaaa = true ;
	    	if(Pattern.matches("\\b[\\w.%-]+@[-.\\w]+\\.[A-Za-z]{2,4}\\b",email)){
	    	
	    		
	    		if(true)
	    		{
	    			String [] a= email.split("@");
	    			String d=a[0];
	    			
	    			boolean dc=a[1].startsWith("1")||a[1].startsWith("2")||a[1].startsWith("3")||a[1].startsWith("4")||a[1].startsWith("5")||
	    					a[1].startsWith("6")||a[1].startsWith("7")||a[1].startsWith("8")||a[1].startsWith("9")||a[1].startsWith("0");
	    			
	    			if(isNumeric(d)||dc)
	    			{
	    				aaaaa= false;
	    			}
	    			else
	    			{
	    				aaaaa= true;
	    			}
	    		}
	    		
	    		
	    	}else
	    		aaaaa=false;
	    	
	    	return aaaaa;
	    }
	   
		public static boolean isNumeric(String d)
		{
		  return d.matches("-?\\d+(\\.\\d+)?");  //match a number with optional '-' and decimal.
		}
	    
}
