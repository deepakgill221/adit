package com.qc.api.service;

import org.springframework.web.bind.annotation.RequestBody;

import com.qc.api.response.WebhookResponse;

/**
 * @author sc05216
 *
 */

public interface CsBotService {

	/**
	 * @param jsonStr : Request data in JSON Format
	 * @return
	 */
	public WebhookResponse csBotProcess(@RequestBody String jsonStr);
	
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	public void removeUnUsedSessionFromCache();
	
	public String instaCallBack(String sessionId);
}
