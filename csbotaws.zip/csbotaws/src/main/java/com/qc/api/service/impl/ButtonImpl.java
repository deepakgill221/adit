package com.qc.api.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.hello.Facebook;
import com.qc.api.hello.InnerButton;
import com.qc.api.hello.InnerData;
import com.qc.api.service.Button;
import com.qc.common.AddressDetailService;

@Service
public class ButtonImpl implements Button 
{
	private static Logger logger = LogManager.getLogger(ButtonImpl.class);
	
	private static final String APINAME="API.AI"; 
	private static final String CHATBOTNAME="Chatbot";
	private static final String MLICHATBOTNAME="MLIChatBot";
	private static final String IMAGEURL = "BOT";
	private static final String CSBOTBUTTONCALLPAYLOADRESPONSE = "csbotButtonCallPayloadResponse";
	private static final String MATURITY_AND_TERM = "maturity and term";
	
	
	private void setFacebook(
			List<InnerButton> buttonList,
			Facebook fb){
		fb.setButtons(buttonList);
		fb.setTitle(MLICHATBOTNAME);
		fb.setPlatform(APINAME);
		fb.setType(CHATBOTNAME);
		fb.setImageUrl(IMAGEURL);
	}
	
	
	@Autowired
	AddressDetailService addressDetailService;
	
	List<InnerButton> innerbuttonlist = new ArrayList<>();
	InnerData innerData = new InnerData();
	InnerButton button = new InnerButton();
	InnerButton button2 = new InnerButton();
	InnerButton button3 = new InnerButton();
	InnerButton button4 = new InnerButton();
	InnerButton button5 = new InnerButton();
	InnerButton button6 = new InnerButton();
	InnerButton button7 = new InnerButton();
	InnerButton button8 = new InnerButton();
	InnerButton button9 = new InnerButton();
	InnerButton button10 = new InnerButton();
	InnerButton button11 = new InnerButton();
	InnerButton button12 = new InnerButton();
	InnerButton button13 = new InnerButton();
	InnerButton button14 = new InnerButton();
	InnerButton button15 = new InnerButton();
	InnerButton button16 = new InnerButton();
	InnerButton button17 = new InnerButton();
	InnerButton button18 = new InnerButton();
	@Override
	public InnerData getButtonsHI(String action) 
	{
		innerbuttonlist=new ArrayList<>();
		innerData=new InnerData();
		Facebook fb = new Facebook();
		
		button.setText("Premium Due");
		button.setPostback("premiumdue");
		button.setLink("");
		innerbuttonlist.add(button);

		button2.setText("Policy Term");
		button2.setPostback(MATURITY_AND_TERM);
		button2.setLink("");
		innerbuttonlist.add(button2);

		button3.setText("Policy Pack");
		button3.setPostback("policypack");
		button3.setLink("");
		innerbuttonlist.add(button3);

		button4.setText("Maturity");
		button4.setPostback(MATURITY_AND_TERM);
		button4.setLink("");
		innerbuttonlist.add(button4);

		button5.setText("Fund Value");
		button5.setPostback("Fundvalue");
		button5.setLink("");
		innerbuttonlist.add(button5);

		button6.setText("Cash Value");
		button6.setPostback("csv");
		button6.setLink("");
		innerbuttonlist.add(button6);

		button7.setText("Premium Payment Term");
		button7.setPostback("ppt");
		button7.setLink("");
		innerbuttonlist.add(button7);

		//On UAT only
		button8.setText("Renewal Payment Procedure");
		button8.setPostback("renewalpayment");
		button8.setLink("");
		innerbuttonlist.add(button8);

		button9.setText("Premium Statement");
		button9.setPostback("premiumreceipt");
		button9.setLink("");
		innerbuttonlist.add(button9);

		//On UAT only
		button10.setText("Locate Us");
		button10.setPostback("locateus");
		button10.setLink("");
		innerbuttonlist.add(button10);

		button11.setText("Loan Inquiry");
		button11.setPostback("LoanInquiry");
		button11.setLink("");
		innerbuttonlist.add(button11);

		button12.setText("Update Personal Details");
		button12.setPostback("UpdatePersonalDetails");
		button12.setLink("");
		innerbuttonlist.add(button12);
		
		button13.setText("NAV Registration");
		button13.setPostback("NavRegistration");
		button13.setLink("");
		innerbuttonlist.add(button13);
		
		button14.setText("NAV Deregistration");
		button14.setPostback("NavDeregistration");
		button14.setLink("");
		innerbuttonlist.add(button14);
		
		//on uat only
		button15.setText("Surrender Procedure");
		button15.setPostback("SurrenderProcedure");
		button15.setLink("");
		innerbuttonlist.add(button15);
		
		button16.setText("Proposal Status");
		button16.setPostback("ProposalStatus");
		button16.setLink("");
		innerbuttonlist.add(button16);
		
		button17.setText("Change of NFO");
		button17.setPostback("ChangeofNFO");
		button17.setLink("");
		innerbuttonlist.add(button17);
		
		button18.setText("Change of Bonus");
		button18.setPostback("ChangeofBonus");
		button18.setLink("");
		innerbuttonlist.add(button18);
		
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;

	}
	@Override
	public InnerData getButtonsYesNo(String action) 
	{
		innerbuttonlist=new ArrayList<>();
		innerData=new InnerData();
		Facebook fb = new Facebook();
		
		button2.setText("Yes");
		button2.setPostback("yes");
		button2.setLink("");
		innerbuttonlist.add(button2);

		button.setText("No");
		button.setPostback("no");
		button.setLink("");
		innerbuttonlist.add(button);

		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	@Override
	public InnerData getButtonsRenewalPaymentProcedure(String action) 
	{
		innerbuttonlist=new ArrayList<>();
		innerData=new InnerData();
		Facebook fb = new Facebook();
		
		button.setText("Pay Online");
		button.setPostback("pay online");
		button.setLink("");
		innerbuttonlist.add(button);

		button2.setText("Direct Debit");
		button2.setPostback("direct debit");
		button2.setLink("");
		innerbuttonlist.add(button2);

		button3.setText("CreditCard Standing Instructions");
		button3.setPostback("credit");
		button3.setLink("");
		innerbuttonlist.add(button3);

		button4.setText("Other Procedure");
		button4.setPostback("other procedure");
		button4.setLink("");
		innerbuttonlist.add(button4);

		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	@Override
	public InnerData getButtonsLoanInquiry(String action) 
	{
		innerbuttonlist=new ArrayList<>();
		innerData=new InnerData();
		Facebook fb = new Facebook();
		
		button.setText("Loan Eligibility Details");
		button.setPostback("loanegigibilitydetails");
		button.setLink("");
		innerbuttonlist.add(button);

		button2.setText("Outstanding Loan Details");
		button2.setPostback("outstandingloandetials");
		button2.setLink("");
		innerbuttonlist.add(button2);

		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	@Override
	public InnerData getButtonsUpdatePersonalDetails(String action) 
	{
		innerbuttonlist=new ArrayList<>();
		innerData=new InnerData();
		Facebook fb = new Facebook();
		
		button6.setText("Update PAN");
		button6.setPostback("UpdatePAN");
		button6.setLink("");
		innerbuttonlist.add(button6);
		
		button.setText("Update Mobile");
		button.setPostback("UpdateMobile");
		button.setLink("");
		innerbuttonlist.add(button);

		button2.setText("Update Email");
		button2.setPostback("UpdateEmail");
		button2.setLink("");
		innerbuttonlist.add(button2);
		
		button3.setText("Address Change");
		button3.setPostback("AddressChange");
		button3.setLink("");
		innerbuttonlist.add(button3);
		
		button4.setText("Nominee Change");
		button4.setPostback("NomineeChange");
		button4.setLink("");
		innerbuttonlist.add(button4);

		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}

	@Override
	public InnerData getHelpfulSomeHelpful(String action)
	{
		innerbuttonlist=new ArrayList<>();
		innerData=new InnerData();
		Facebook fb = new Facebook();
		
		button10.setText("Helpful");
		button10.setPostback("helpful");
		button10.setLink("");
		innerbuttonlist.add(button10);

		button11.setText("Somewhat helpful");
		button11.setPostback("somewhatHelpful");
		button11.setLink("");
		innerbuttonlist.add(button11);

		button12.setText("Not helpful");
		button12.setPostback("notHelpful");
		button12.setLink("");
		innerbuttonlist.add(button12);

		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	
	// cs button call
	@Override
	public InnerData getButtonFromDB(String result)
	{   try {
		int i=0;
	    JSONObject buttonObj = new JSONObject(result);
	    Object csbot= buttonObj.get(CSBOTBUTTONCALLPAYLOADRESPONSE);
	    JSONArray array = (JSONArray) csbot; 
	    innerbuttonlist=new ArrayList<>();
	    innerData=new InnerData();
	    Facebook fb = new Facebook();
		
		for (i=0;i<array.length();i++)
		{
		button = new InnerButton();
		button.setText(array.get(i)+"");
		button.setPostback(array.get(i)+"");
		button.setLink("");
		innerbuttonlist.add(button);
		}
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
	}catch(Exception e) {
		logger.error("creating exception in getButtonFromDB "+e);
	}
		return innerData;
	}
	
	@Override
	public InnerData getButtonGoalDB(String result)
	
	{   int i=0;
	   try {
	    JSONObject buttonObj = new JSONObject(result);
	    Object csbot= buttonObj.get(CSBOTBUTTONCALLPAYLOADRESPONSE);
	    JSONArray array = (JSONArray) csbot; 
	    innerbuttonlist=new ArrayList<>();
	    innerData=new InnerData();
	    Facebook fb = new Facebook();
		
		for (i=0;i<3;i++)
		{
		button = new InnerButton();
		button.setText(array.get(i)+"");
		button.setPostback(array.get(i)+"");
		button.setLink("");
		innerbuttonlist.add(button);
		}
		
		if(array.length()>3)
		{
		button2 = new InnerButton();
		button2.setText("Others");
		button2.setPostback("Others Product Name");
		button2.setLink("");
		innerbuttonlist.add(button2);
		}
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
	   }catch(Exception e) {
		   logger.error("creating exception in getButtonGoalDB "+e);
	   }
		return innerData;
	}
	
	@Override
	public InnerData getButtonBuyNow(String result, String url)
	{   
		try {
		int i=0;
	    JSONObject buttonObj = new JSONObject(result);
	    Object csbot= buttonObj.get(CSBOTBUTTONCALLPAYLOADRESPONSE);
	    JSONArray array = (JSONArray) csbot; 
	    innerbuttonlist=new ArrayList<>();
	    innerData=new InnerData();
	    Facebook fb = new Facebook();
		
		for (i=0;i<array.length();i++)
		{
		button = new InnerButton();
		button.setText(array.get(i)+"");
		button.setPostback(array.get(i)+"");
		button.setLink("");
		innerbuttonlist.add(button);
		
		}
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		}catch(Exception e) {
			logger.error("creating exception in getButtonBuyNow "+e);
		}
		return innerData;
	}
	
	@Override
	public InnerData getButtonOnlineOffline(String result)
	{  
		try {
		int i=0;
		int j=0;
		String type="";
		String dbBuyNowUrl="";
		String dbKnowMoreUrl="";
	    JSONObject buttonObj = new JSONObject(result);
	    Object csbot= buttonObj.get(CSBOTBUTTONCALLPAYLOADRESPONSE);
	    JSONArray array = (JSONArray) csbot; 
	    innerbuttonlist=new ArrayList<>();
	    innerData=new InnerData();
	    Facebook fb = new Facebook();
	    for (i=0;i<array.length();i++)
		{
	    	JSONArray innerArray=(JSONArray) array.get(i);
	    	for(j=0;j<innerArray.length();j++)
	    	{
	    	if(j==0)
	    	{
	    		type=innerArray.get(j)+"";
	    	}
	    	else if(j==2)
	    	{
	    		dbBuyNowUrl=innerArray.get(j)+"";
	    	}
	    	else if(j==3)
	    	{
	    		dbKnowMoreUrl=innerArray.get(j)+"";
	    	}
		}
		}
			
			if("online".equalsIgnoreCase(type))
			{
				button.setText("Buy Now");
				button.setPostback("Buy Now");
				button.setLink(dbBuyNowUrl);
				innerbuttonlist.add(button);
				
				button2.setText("Know More");
				button2.setPostback("Know More Online");
				button2.setLink(dbKnowMoreUrl);
				innerbuttonlist.add(button2);
			}
			
			else if ("offline".equalsIgnoreCase(type))
			{
				button.setText("Request an Agent");
				button.setPostback("Request an Agent");
				button.setLink("https://www.maxlifeinsurance.com/contact-us");
				innerbuttonlist.add(button);
				
				button2.setText("Know More");
				button2.setPostback("Know More Offline");
				button2.setLink(dbKnowMoreUrl);
				innerbuttonlist.add(button2);
			}
	    

			setFacebook(innerbuttonlist,fb);
			innerData.setFacebook(fb);
		}catch(Exception e) {
			logger.error("creating exception in "+e);
		}
			return innerData;
	}
	
	@Override
	public InnerData getButtonHello(String action)
	{
		innerbuttonlist=new ArrayList<>();
		innerData=new InnerData();
		Facebook fb = new Facebook();

		button.setText("Existing Policy");
		button.setPostback("Service Existing Policy");
		button.setLink("");
		innerbuttonlist.add(button);

		button2.setText("New Products");
		button2.setPostback("Check out New Products");
		button2.setLink("");
		innerbuttonlist.add(button2);

		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	

	
}
