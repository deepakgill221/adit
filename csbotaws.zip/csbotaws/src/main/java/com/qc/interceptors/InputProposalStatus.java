package com.qc.interceptors;

public interface InputProposalStatus {
	
	public String getProposalStatus(String sessionId);

}
