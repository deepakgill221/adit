package com.qc.interceptors;

import java.util.Map;

public interface InputReceipt 
{

	public String getInputReceipt(String sessionId, Map<String, Map> responsecacheOnSessionId);

}
