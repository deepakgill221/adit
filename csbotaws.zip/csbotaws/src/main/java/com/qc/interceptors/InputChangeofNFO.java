package com.qc.interceptors;

public interface InputChangeofNFO {
	
	public String getChangeOfNFO(String sessionId);

}
