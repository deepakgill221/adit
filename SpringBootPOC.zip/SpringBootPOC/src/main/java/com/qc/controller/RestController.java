package com.qc.controller;

public class RestController {

}
