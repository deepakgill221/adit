package com.qc.dao;

import com.qc.UserRegistration;

public interface UserDao {
	public String saveUserData(UserRegistration userRegistration);
	public boolean userLogin(String id, String password);
	
}
