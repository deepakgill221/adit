package com.qc.daoImpl;

import java.util.List;


import javax.transaction.Transactional;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import com.qc.UserRegistration;
import com.qc.bean.Employee;
import com.qc.dao.UserDao;


@Repository
@Transactional
public class UserDaoImpl implements UserDao{

	@Autowired
	@Qualifier("sessionfactory2")
	private SessionFactory sessionFactory;
	
	@Override
	public String saveUserData(UserRegistration user) {
		String registrationStatus="";
		
		
		try {
		  
			Session session =  sessionFactory.getCurrentSession();
			   Employee eb=new Employee();
			   eb.setEid(107);
			   eb.setFname("Rahul");
			   eb.setLname("kumar");
			   eb.setEmail("ravi@com.com");
			   int a=(int)session.save(eb);
			   System.out.println("a value is "+a);
			   System.out.println("Result inserted successfully");
			   
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		/*try {
			Connection conn= MyConnection.getConnection();
				java.sql.PreparedStatement stmt = conn.prepareStatement("insert into QC_User_Detail(id,password,name,address,mobile)values(?,?,?,?,?)");
				
				stmt.setString(1,user.getId());
				stmt.setString(2, user.getPassword());
				stmt.setString(3,user.getName());
				stmt.setString(4,user.getAddress());
				stmt.setString(5,user.getMobile());
				
				int i = stmt.executeUpdate();
	           
	            if (i > 0) {
	            	registrationStatus="Data saved successfully";
	            	System.out.println("Data saved successfully");
	            	
	            }else {
	            	registrationStatus="Failure";
	            }
	            conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				registrationStatus="Failure : " +e.getMessage() ;
			}*/
		
		return registrationStatus;
	}

	@Override
	public boolean userLogin(String id, String password) {
		
		try {
			/* Connection conn= MyConnection.getConnection(); */
		//	java.sql.Statement stmt=conn.createStatement(); 
			/*
			 * java.sql.PreparedStatement ps=null;
			 * 
			 * //ResultSet rs = stmt.executeQuery("select * from QC_User_Detail where id='"
			 * +id+"'AND password='"+password+"'"); String queryString =
			 * "SELECT * FROM QC_User_Detail where id=? and password=?"; ps =
			 * conn.prepareStatement(queryString); ps.setString(1,id);
			 * ps.setString(2,password); ResultSet rs = ps.executeQuery();
			 * 
			 * while(rs.next()) { return true; } rs.close(); conn.close();
			 */		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
