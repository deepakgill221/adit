package com.qualtech.mpro.scheduler;

import java.util.Date;

import org.apache.log4j.Logger;

public class DateDifferentExample {
	static Logger logger = Logger.getLogger(DateDifferentExample.class.getName());

	public static void main(String[] args) {
		Date d1 = new Date();
		Date d2 = null;
		try {
			Thread.sleep(61000);
			d2 = new Date();
//			System.out.println("----------------");
//			System.out.println(getDiffInMunutes(d1, d2));
//			System.out.println("----------------");
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		// String dateStart = "01/14/2012 09:29:58";
		// String dateStop = "01/15/2012 10:31:48";
		//
		// //HH converts hour in 24 hours format (0-23), day calculation
		// SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy
		// HH:mm:ss");
		// Date d1 = null;
		// Date d2 = null;
		// try
		// {
		// d1 = format.parse(dateStart);
		// d2 = format.parse(dateStop);
		//
		// //in milliseconds
		// long diff = d2.getTime() - d1.getTime();
		//
		// long diffSeconds = diff / 1000 % 60;
		// long diffMinutes = diff / (60 * 1000) % 60;
		// long diffHours = diff / (60 * 60 * 1000) % 24;
		// long diffDays = diff / (24 * 60 * 60 * 1000);
		//
		// System.out.print(diffDays + " days, ");
		// System.out.print(diffHours + " hours, ");
		// System.out.print(diffMinutes + " minutes, ");
		// System.out.print(diffSeconds + " seconds.");
		//
		// }
		// catch (Exception e)
		// {
		// e.printStackTrace();
		// }
	}

	public static long getDiffInMunutes(Date d1, Date d2) {
		// HH converts hour in 24 hours format (0-23), day calculation
		long data = 999;
		try {
			// in milliseconds
			long diff = d2.getTime() - d1.getTime();
			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			/*
			 * long diffHours = diff / (60 * 60 * 1000) % 24; long diffDays =
			 * diff / (24 * 60 * 60 * 1000);
			 */
			data = diffMinutes;
			logger.info(diffMinutes + "minutes, " + diffSeconds + "seconds.");
			/*
			 * System.out.print(diffDays + " days, ");
			 * System.out.print(diffHours + " hours, ");
			 * System.out.print(diffMinutes + " minutes, ");
			 * System.out.println(diffSeconds + " seconds.");
			 */
		} catch (Exception e) {
			logger.error("Exception :: getDiffInMunutes :: Method");
		}
		return data;
	}
}