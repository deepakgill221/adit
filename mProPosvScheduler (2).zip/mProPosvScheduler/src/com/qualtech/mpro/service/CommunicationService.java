package com.qualtech.mpro.service;

import java.util.List;

public interface CommunicationService {

	public boolean sendMail(List<String> list,String idToEncode);
	
	public boolean sendSms(List<String> list,String idToEncode); 
}
