package com.qualtech.mpro.action;



import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import com.mli.db.DBConnection;
import com.qualtech.mpro.service.CommunicationService;
import com.qualtech.mpro.serviceimpl.CommunicationServiceImpl;

public class MProPosvCallAction 
{
	static Logger logger = Logger.getLogger(MProPosvCallAction.class.getName());
	

	public void processMProPosv() 
	{
		List<List<String>> posvfetchedList = null;
		String trackerId = "" + System.currentTimeMillis();
		logger.info("MProPosvCallAction :: mProPosv Call : processMProPosv : Start : " + trackerId);
		DBConnection con = new DBConnection();
						
		try 
		{
			logger.info("mProPosv Call : Proc Call : Start : " + trackerId);
			
			posvfetchedList = con.posvCallProcedures();
			logger.info("mProPosv Call : Proc Call : End : " + trackerId);
				    if(!posvfetchedList.isEmpty())
				    {
						logger.info("mProPosv data found");
						
						for (int i = 0; i <posvfetchedList.size(); i++)
						{
						List<String> custList=posvfetchedList.get(i);
						
						if(!custList.isEmpty()){
							ExecutorService execSemService=Executors.newSingleThreadExecutor();
							Callable<Boolean> callable1=new Callable<Boolean>() {
								@Override
								public Boolean call() throws Exception {
									return sendSmsAndEmail(custList,con);
								}
							};
							execSemService.submit(callable1);
							execSemService.shutdown();
							if (execSemService.awaitTermination(5, TimeUnit.SECONDS)){
								logger.info("Thread ... done .... job");
			           	    }
							
						}	
						
						}
					}
			} catch (Exception ex) {
			logger.error("We Are in Exception : " + trackerId);
		}
		logger.info("mProPosv Call : processMProPosv : End : " + trackerId);
	}

	public Boolean sendSmsAndEmail(List<String> list, DBConnection con){
		CommunicationService mailservice = new CommunicationServiceImpl();
		logger.info("MproPosvCallAction :: sendSmsAndEmail Start ::");
		    
			if(list.get(8).equalsIgnoreCase("YES"))
			{
				boolean smsStatus =false;
				boolean mailStatus = false;
				if(list.get(0) != null)
				{
					mailStatus = mailservice.sendMail(list,list.get(0));
					smsStatus =mailservice.sendSms(list,list.get(0));
				}
				if(smsStatus)
				{
					logger.info("sms delivered successfully : updating seller record in db"); 
					con.updateSellerRecords(list.get(0),"Y");
				}
				logger.info("mailStatus: "+mailStatus);
			}else
			{
				logger.info("Bittely link  found No for txn id "+list.get(0));
			}
			
			
			
			logger.info("MproPosvCallAction :: sendSmsAndEmail End ::");
	  return true;
	}
}
