package com.qualtech.mpro.serviceimpl;

public class AESEncryptor 
{
	public static String encrypt(String str)
	{
		char[] chars = str.toCharArray();
		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < chars.length; i++)
		{
			sb.append(Integer.toHexString((int)chars[i]));
		}		 
		return sb.toString();
	}

	public static String decrypt(String str)
	{
		StringBuilder sb = new StringBuilder();
		StringBuilder temp = new StringBuilder();
		for( int i=0; i<str.length()-1; i+=2 )
		{
			String output = str.substring(i, (i + 2));
			int decimal = Integer.parseInt(output, 16);
			sb.append((char)decimal);		 
			temp.append(decimal);
		}
		return sb.toString();
	}

	public static void main(String[] args)
	{
		String str1 = AESEncryptor.encrypt("1230000");
		String dec = AESEncryptor.decrypt(str1);
		System.out.println(str1);
		System.out.println(dec);
	}

	///AES Encription is commented below when ever required uncomment it

	//import javax.crypto.Cipher;
	//import javax.crypto.spec.IvParameterSpec;
	//import javax.crypto.spec.SecretKeySpec;
	//import org.apache.commons.codec.binary.Base64;
	
	//	private static String key = "QC-MLI-PRE-ISUNC"; // 128 bit key
	//	private static String initVector = "PREISSUANCELOGIC"; // 16 bytes IV
	//    
	//	public static String encrypt(String value)
	//    {
	//        try 
	//        {
	//            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
	//            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
	//
	//            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	//            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
	//
	//            byte[] encrypted = cipher.doFinal(value.getBytes());
	//
	//            return Base64.encodeBase64String(encrypted);
	//        } 
	//        catch (Exception ex) 
	//        {
	//            ex.printStackTrace();
	//        }
	//        return null;
	//    }
	//
	//	public static String decrypt(String encrypted)
	//    {
	//        try 
	//        {
	//            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
	//            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
	//
	//            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	//            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
	//
	//            byte[] original = cipher.doFinal(Base64.decodeBase64(encrypted));
	//
	//            return new String(original);
	//        }
	//        catch (Exception ex) 
	//        {
	//            ex.printStackTrace();
	//        }
	//
	//        return null;
	//    }
	//
	//    public static void main(String[] args) 
	//    {
	//    	String key = "QC-MLI-PRE-ISUNC"; // 128 bit key
	//        String initVector = "PREISSUANCELOGIC"; // 16 bytes IV
	//        String msg = "10000006";
	//        String encMsg = encrypt(msg);
	//        System.out.println("encMsg : " +encMsg);
	//        System.out.println("decMsg : " +decrypt(encMsg));
	//    }
}
