package com.qualtech.mpro.serviceimpl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javax.net.ssl.HttpsURLConnection;

import org.apache.log4j.Logger;

import com.mli.action.MainAction;
import com.mli.util.StringUtility;
import com.mli.util.XTrustProvider;
import com.qualtech.mpro.service.CommunicationService;

public class CommunicationServiceImpl implements CommunicationService{

	static Logger logger = Logger.getLogger(MainAction.class.getName());
	static ResourceBundle res = ResourceBundle.getBundle("com.qualtech.mpro.resources.ConfigResources");
	
	@Override
	public boolean sendMail(List<String> list,String idToEncode) {

		String output = new String();
		StringBuilder result = new StringBuilder();				
		try 
		{
			logger.info("mpro sendMail Process : Start");

			String encTxnId = AESEncryptor.encrypt(idToEncode+"||"+"E"+"||"+"mpro");
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();

			StringBuilder mailReq=new StringBuilder();

			mailReq.append("{");
			mailReq.append("\"request\": {");
			mailReq.append("\"header\": {");
			mailReq.append("\"soaCorrelationId\": \""+list.get(0)+"\",");
			mailReq.append("\"soaAppId\": \"POS\"");
			mailReq.append("},");
			mailReq.append("\"requestData\": {");
			mailReq.append("\"mailIdTo\": \""+list.get(6).toLowerCase()+"\",");
			mailReq.append("\"mailSubject\": \"Pre Issuance Verification Link\",");
			mailReq.append("\"fromName\": \"Maxlife Insurance\",");
			mailReq.append("\"attachments\": [],");
			mailReq.append("\"isConsolidate\":false,");
			mailReq.append("\"isFileAttached\":true,");
			mailReq.append("\"fromEmail\": \"DoNotReply@maxlifeinsurance.com\",");
			mailReq.append("\"mailBody\": \"").append("<html><body>Dear "+((StringUtility.checkStringNullOrBlank(list.get(1))+" "+StringUtility.checkStringNullOrBlank(list.get(2))).trim()+" "+StringUtility.checkStringNullOrBlank(list.get(3))).toUpperCase()+",<br/><br/>Thank you for choosing "+StringUtility.checkStringNullOrBlank(list.get(5))+".<br/>Your Pre Issuance Verification process for Reference no. "+StringUtility.checkStringNullOrBlank(list.get(0))+" has started which is mandatory for policy issuance.<br/>Kindly click on <a href='"+res.getString("com.qc.preissuance.buyerURL")+encTxnId+"'>"+res.getString("com.qc.preissuance.buyerURL")+encTxnId+"</a> to submit your response.</body></html>").append("\"");
			
			mailReq.append("}");
			mailReq.append("}");
			mailReq.append("}");

			String pUrl = res.getString("com.qc.preissuance.sendMailURLConf");
			logger.info("URL : "+pUrl);
			URL url = new URL(pUrl);


			HttpURLConnection conn = null;
			String devMode = res.getString("spring.enable.proxy.development");
			if(devMode!=null && !devMode.equalsIgnoreCase("") && devMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}

			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("POST");

			logger.info("Mail request : "+mailReq.toString());
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(mailReq.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			logger.info("API Response Code :: Response:"+apiResponseCode);
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("Send Mail Status Pass : Response:"+result.toString());
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("Send Mail Status Fail : "+result.toString());
				return false;
			}
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo While Calling sendMail in Mpro::",e);
			return false;
		}
		return true;
	
	}

	@Override
	public boolean sendSms(List<String> list,String idToEncode) {

		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("Mpro send sms  Process : Start");
			String encTxnId = AESEncryptor.encrypt(idToEncode+"||"+"M"+"||"+"mpro");
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			StringBuilder sb = new StringBuilder();
			sb.append("{");
			sb.append("	   \"MliSmsService\": {");
			sb.append("      \"requestHeader\": {");
			sb.append("         \"generalConsumerInformation\": {");
			sb.append("            \"messageVersion\": \"1.0\",");
			sb.append("            \"consumerId\": \"").append(res.getString("com.qc.preissuance.smsapi.consumerid")).append("\",");
			sb.append("            \"correlationId\": \"").append(encTxnId).append("\"");
			sb.append("         }");
			sb.append("      },");
			sb.append("      \"requestBody\": {");
			sb.append("        \"appAccId\": \"").append(res.getString("com.qc.preissuance.smsapi.appaccessid")).append("\",");
			sb.append("      \"appAccPass\": \"").append(res.getString("com.qc.preissuance.smsapi.appaccesspass")).append("\",");
			sb.append("        \"appId\": \"").append(res.getString("com.qc.preissuance.smsapi.appid")).append("\",");
			sb.append("        \"msgTo\": \""+list.get(4)+"\",");
			sb.append("         \"msgText\": \"Dear "+((StringUtility.checkStringNullOrBlank(list.get(1))+" "+StringUtility.checkStringNullOrBlank(list.get(2))).trim()+" "+StringUtility.checkStringNullOrBlank(list.get(3))).toUpperCase()+", Thank you for choosing "+StringUtility.checkStringNullOrBlank(list.get(5))+". Your Pre Issuance Verification process for Reference no. "+StringUtility.checkStringNullOrBlank(list.get(0))+" has started which is mandatory for policy issuance. Kindly click on "+res.getString("com.qc.preissuance.buyerURL")+encTxnId+" to submit your response.\" ");			
			sb.append("      }");
			sb.append("  }");
			sb.append("}");
			String pUrl = res.getString("com.qc.preissuance.sendSmsURL");
			logger.info("URL : "+pUrl);
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = res.getString("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				logger.info("We are running in Development Mode So Proxy Enabled");
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}

			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("POST");

			logger.info("SMS request : "+sb.toString());
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(sb.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			logger.info("API Response Code :: "+apiResponseCode);
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("Send sms Status Pass :Response: "+result.toString());
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("Send sms Status Fail :Response: "+result.toString());
				return false;
			}
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo While Calling SMS API ::",e);
			return false;
		}
		logger.info("Mpro send sms  Process : End");
		return true;
	}

}
