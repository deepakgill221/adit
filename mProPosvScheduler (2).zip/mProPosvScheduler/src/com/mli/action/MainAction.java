package com.mli.action;


import org.apache.log4j.Logger;

public class MainAction
{
	static Logger logger = Logger.getLogger(MainAction.class.getName());
	public static void main(String arg[]) 
	{
		try
		{
			logger.info("MPro Posv Schedular Main : Start");
			MainActionTask.work(); 
			logger.info("MPro Posv Schedular Main : End");
		}
		catch (Exception e)
		{
			logger.error("creating exception in MPro Posv main : "+e);
		}
	}   

}
