package com.mli.action;


import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import com.qualtech.mpro.action.MProPosvCallAction;


public class MainActionTask
{
	static Logger logger = Logger.getLogger(MainActionTask.class.getName());
	static ResourceBundle res = ResourceBundle.getBundle("com.qualtech.mpro.scheduler.Scheduler");
	public static void work() 
	{
		int dataCount=0;
		MProPosvCallAction mProPosvCallAction=new MProPosvCallAction();
			
		try
		{
			
			NDC.push("mProPosv Scheduler : " + System.currentTimeMillis());
			logger.info("mProPosv  Scheduler  Run Method Started.");

			if (dataCount == 0) 
			{
				try 
				{
					logger.info("-------------Calling action to mpro posv sechedular ----------------------------------");
					mProPosvCallAction.processMProPosv();
				}
				catch (Exception e) 
				{
					logger.error("Exception in posv  Scheduler Run :-" + e);
				}
				
			}else{
				logger.info("Scheduler count found:: " + dataCount);
			}
			logger.info("mProPosv Scheduler Run Method End.");
		} 
		catch (Exception e)
		{
			logger.error("we are in Exception  : " + e);
		}
		finally 
		{
			NDC.pop();
		}
		logger.info("Task Completed!!!!!!");
	}   
}

