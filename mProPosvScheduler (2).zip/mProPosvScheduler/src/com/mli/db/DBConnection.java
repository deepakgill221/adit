package com.mli.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;
import oracle.jdbc.OracleTypes;

public class DBConnection {

	static ResourceBundle res = ResourceBundle.getBundle("com.qualtech.mpro.resources.ConfigResources");
	static Logger logger = Logger.getLogger(DBConnection.class);

	

	public List<List<String>> posvCallProcedures() {

		logger.debug("Comes to DBConnection in posvCallProcedures Method: ");
		List<List<String>> posvList = new ArrayList<List<String>>();
		ResultSet rs = null;
		Connection con = null;
		CallableStatement clblStmt = null;
		try{
			
			con = DBSQLHelper.getInstance().getPosvSourceConnection();
			if (con != null) {
				con.setAutoCommit(true);
				String finalScript = " { call PROC_mPro_Bitly_Link (?) } ";
				logger.info("Proc is : " + finalScript);
				clblStmt = con.prepareCall(finalScript);
				clblStmt.registerOutParameter(1, OracleTypes.CURSOR);
				clblStmt.setQueryTimeout(0);
				clblStmt.executeUpdate();
				logger.info("Proc Execute : Start : " + System.currentTimeMillis());
				rs = (ResultSet) clblStmt.getObject(1);
				logger.info("Proc Execute : End : " + System.currentTimeMillis());
				logger.info("Proc Iteration Start : " + System.currentTimeMillis());
				
				while (rs.next()) {
					List<String> posvInnerList = new ArrayList<String>();
					
					posvInnerList.add(rs.getString("txnid"));
					posvInnerList.add(rs.getString("custfname"));
					posvInnerList.add(rs.getString("custmname"));
					posvInnerList.add(rs.getString("custlname"));
					posvInnerList.add(rs.getString("custmobileno"));
					posvInnerList.add(rs.getString("custbenefitname"));
					posvInnerList.add(rs.getString("custemailid"));
					posvInnerList.add(rs.getString("policynumber"));
					posvInnerList.add(rs.getString("bitly_link"));
					posvList.add(posvInnerList);
				}
				logger.info("Proc Iteration End : " + System.currentTimeMillis());
				logger.info("list from posv proc="+posvList.size());
			} else {
				logger.error("Connection is Not Available Service unavailable.");
			}
		} catch (Exception e) {
			logger.error("Some exception occured while fetching records : " + e, new Throwable());

		} finally {
			try {
				
				logger.info("Trying to close Resources DBConnection in mProPosvCallProcedures Method:- ");
				if (rs != null) {
					rs.close();
				}
				if (clblStmt != null) {
					clblStmt.close();
				}
				if (con != null) {
					con.close();
				}
				logger.info("Successfully closed Resources DBConnection in mProPosvCallProcedures Method:- ");
			} catch (Exception e) {
				logger.error("SQL exception while closing resources DBConnection in mProPosvCallProcedures Method: " + e, new Throwable());

			}
		}
		logger.info("Getting out from DBConnection in mProPosvCallProcedures Method : ");
		return posvList;
	
	}
	
	public boolean updateSellerRecords(String txn_id, String isSmsTrigered) 
	{
		logger.debug("Comes to DBConnection in updateSellerRecords method ");
		
		Boolean result = true;
		try(Connection con = DBSQLHelper.getInstance().getPosvSourceConnection(); Statement stmt = con.createStatement();) {

			if (con != null)
			{
				String query = "UPDATE PI_SELLER_TXN SET SMSTRIGERED='"+isSmsTrigered+"', SMS_DATE=systimestamp  WHERE txnid='"+txn_id+"'";
				logger.info("SQL query to be executed : " + query);
				stmt.setQueryTimeout(0);
				stmt.executeQuery(query);
				logger.info("seller record updated successfully ");
			}
			else
			{
				logger.info("connection obj not found when update in pi_seller_txn "+con);
			}
		} catch (Exception e) {
			result = false;
			logger.error("Some exception occured while updating seller record : " + e, new Throwable());
		} 
		logger.info("Getting out from DBConnection in getSeqNextValue Method : ");
		return result;
	}

}

