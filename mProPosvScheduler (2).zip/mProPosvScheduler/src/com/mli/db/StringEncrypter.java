package com.mli.db;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;



public class StringEncrypter {
	public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
	public static final String DES_ENCRYPTION_SCHEME = "DES";
	private static final String DEFAULT_ENCRYPTION_KEY = "This is a fairly long phrase used to encrypt";
	private static final String UNICODE_FORMAT = "UTF8";
	private KeySpec keySpec;
	private SecretKeyFactory keyFactory;
	private static final String DEFAULT_ENCRYPTION_KEY1 = "peGas@#235X798c5TEV23*9peGaT@#234X758c5TEV23*9";
	private Cipher cipher;

	public StringEncrypter() throws Exception {
		this("DES", "peGas@#235X798c5TEV23*9peGaT@#234X758c5TEV23*9");
	}

	public StringEncrypter(String encryptionScheme)/* 39: */ throws Exception {
		this(encryptionScheme, "This is a fairly long phrase used to encrypt");
	}

	public StringEncrypter(String encryptionScheme, String encryptionKey)/* 45: */ throws Exception {
		if (encryptionKey == null) {
			throw new Exception(new IllegalArgumentException("Encryption key was null"));
		}
		if (encryptionKey.trim().length() < 24) {
			throw new Exception(new IllegalArgumentException("Encryption key was less than 24 characters"));
		}
		try {
			byte[] keyAsBytes = encryptionKey.getBytes("UTF8");
			if (encryptionScheme.equals("DESede")) {
				this.keySpec = new DESedeKeySpec(keyAsBytes);
			} else if (encryptionScheme.equals("DES")) {
				this.keySpec = new DESKeySpec(keyAsBytes);
			} else {
				throw new Exception(new IllegalArgumentException("Encryption scheme not supported: " + encryptionScheme));
			}
			this.keyFactory = SecretKeyFactory.getInstance(encryptionScheme);
			this.cipher = Cipher.getInstance(encryptionScheme);
		} catch (InvalidKeyException e) {
			throw new Exception(e);
		} catch (UnsupportedEncodingException e) {
			throw new Exception(e);
		} catch (NoSuchAlgorithmException e) {
			throw new Exception(e);
		} catch (NoSuchPaddingException e) {
			throw new Exception(e);
		}
	}

	public String encrypt(String unencryptedString)/* 85: */ throws Exception {
		if ((unencryptedString == null) || (unencryptedString.trim().length() == 0)) {
			throw new Exception(new IllegalArgumentException("unencrypted string was null or empty"));
		}
		try {
			SecretKey key = this.keyFactory.generateSecret(this.keySpec);
			this.cipher.init(1, key);

			byte[] cleartext = unencryptedString.getBytes("UTF8");
			byte[] ciphertext = this.cipher.doFinal(cleartext);
			return Base64.getEncoder().encodeToString(ciphertext);
		} catch (InvalidKeyException e) {
			throw new Exception(e);
		} catch (InvalidKeySpecException e) {
			throw new Exception(e);
		} catch (UnsupportedEncodingException e) {
			throw new Exception(e);
		} catch (IllegalStateException e) {
			throw new Exception(e);
		} catch (IllegalBlockSizeException e) {
			throw new Exception(e);
		} catch (BadPaddingException e) {
			throw new Exception(e);
		}
	}

	public String decrypt(String encryptedString)/* 129: */ throws Exception {
		if ((encryptedString == null) || (encryptedString.trim().length() <= 0)) {
			throw new Exception(new IllegalArgumentException("encrypted string was null or empty"));
		}
		try {
			SecretKey key = this.keyFactory.generateSecret(this.keySpec);
			this.cipher.init(2, key);

			byte[] cleartext = Base64.getDecoder().decode(encryptedString);
			byte[] ciphertext = this.cipher.doFinal(cleartext);

			return bytes2String(ciphertext);
		} catch (InvalidKeyException e) {
			throw new Exception(e);
		} catch (InvalidKeySpecException e) {
			throw new Exception(e);
		} catch (IllegalStateException e) {
			throw new Exception(e);
		} catch (IllegalBlockSizeException e) {
			throw new Exception(e);
		} catch (BadPaddingException e) {
			throw new Exception(e);
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	private static String bytes2String(byte[] bytes) {
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < bytes.length; i++) {
			stringBuffer.append((char) bytes[i]);
		}
		return stringBuffer.toString();
	}

	public String getPassword(String args)/* 181: */ throws Exception {
		String encryptionKey = "peGas@#235X798c5TEV23*9peGaT@#234X758c5TEV23*9";
		String encryptionScheme = "DES";
		StringEncrypter encrypter = new StringEncrypter(encryptionScheme, encryptionKey);
		return encrypter.decrypt(args);
	}

	public static void main(String[] args) {
		try {
			String pwd = new StringEncrypter().getPassword("u5/n1kcdp2pb/+UNJfF+Fg==");
		} catch (Exception localException) {
		}
	}
}

/*
 * Location: D:\LatestWarFile\CrackReport\Crack_Batch_Report.jar
 * 
 * Qualified Name: com.max.report.db.StringEncrypter
 * 
 * JD-Core Version: 0.7.0.1
 * 
 */