package com.mli.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;


import org.apache.log4j.Logger;

public class DBSQLHelper {
	private static DBSQLHelper instance = null;
	static Logger logger = Logger.getLogger(DBSQLHelper.class.getName());
	ResourceBundle resourceBundle = null;
	static {
		try {
			ResourceBundle resourceBundle1 = ResourceBundle.getBundle("com.qualtech.mpro.resources.dbConfig");
		} catch (Exception ex) {
			logger.error(ex);
		}

	}
	
	public Connection getPosvSourceConnection() throws SQLException {
		logger.debug("Inside getPosvSourceConnection... Method");
		Connection con = null;
		try {
			if (this.resourceBundle != null) {
				Class.forName(resourceBundle.getString("jdbc.driverClassName"));
				con = DriverManager.getConnection(this.resourceBundle.getString("jdbc.url"), this.resourceBundle.getString("jdbc.username"), this.resourceBundle.getString("jdbc.password"));
			}

		} catch (Exception e) {
			logger.error("Error while getting connection from data source " + e, new Throwable());
		}
		logger.debug("Exiting getSourceConnection... Method");
		return con;

	}

	public static DBSQLHelper getInstance() {
		logger.debug("Inside getInstance... Method");

		DBSQLHelper dbsqlhelper = new DBSQLHelper();
		dbsqlhelper.resourceBundle = ResourceBundle.getBundle("com.qualtech.mpro.resources.dbConfig");

		logger.debug("Exiting getInstance... Method");

		return dbsqlhelper;
	}
}