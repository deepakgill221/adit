package com.mli.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

public class DBHelper {
	private static DBHelper instance = null;
	static Logger logger = Logger.getLogger(DBHelper.class.getName());
	ResourceBundle resourceBundle = null;
	static {
		try {
			ResourceBundle resourceBundle1 = ResourceBundle.getBundle("com.qualtech.mpro.resources.dbConfig");
			//Class.forName(resourceBundle1.getString("com.qualtech.resource.dbConfig.driverClass"));
		} catch (Exception ex) {
			logger.error(ex);
			ex.printStackTrace();
		}

	}


	
	public static DBHelper getInstance() {
		logger.debug("Inside getInstance... Method");

		DBHelper helper = new DBHelper();
		helper.resourceBundle = ResourceBundle.getBundle("com.qualtech.mpro.resources.dbConfig");

		logger.debug("Exiting getInstance... Method");

		return helper;
	}
}