package com.mli.util;

public class Common {

	public static String checkStringNullOrBlank(String str) {

		if (str != null && !str.equals("")) {
			str = str.trim();
		} else {
			str = "";
		}

		return str;
	}

}
