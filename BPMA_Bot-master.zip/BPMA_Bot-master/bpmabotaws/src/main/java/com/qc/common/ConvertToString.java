package com.qc.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ConvertToString {
	
	private static Logger logger = LogManager.getLogger(ConvertToString.class);
	
	public String getValue(Object obj){
		
		String value="";
		try{
		if(obj != null && !(obj.toString()).isEmpty())
		{
			value = obj.toString();
		}
		}
		catch(Exception ex)
		{
			logger.error("Exception in converting object into String :: "+ex);
		}
		return value;
	}

}
