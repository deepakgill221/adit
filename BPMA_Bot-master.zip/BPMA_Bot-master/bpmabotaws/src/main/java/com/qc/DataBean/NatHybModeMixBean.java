package com.qc.dataBean;

public class NatHybModeMixBean 
{
	private String nativ_annual_adj_mfyp_mtd;
	private String nativ_semi_annual_adj_mfyp_mtd;
	private String nativ_quarterly_adj_mfyp_mtd;
	private String nativ_monthly_adj_mfyp_mtd;
	private String nativ_single_adj_mfyp_mtd;
	private String nativ_annual_adj_mfyp_ytd;
	private String nativ_semi_annual_adj_mfyp_ytd;
	private String nativ_quarterly_adj_mfyp_ytd;
	private String nativ_monthly_adj_mfyp_ytd;
	private String nativ_single_adj_mfyp_ytd;
	private String hybride_annual_adj_mfyp_mtd;
	private String hybre_semi_annual_adj_mfyp_mtd;
	private String hybre_quarterly_adj_mfyp_mtd;
	private String hybre_monthly_adj_mfyp_mtd;
	private String hybre_single_adj_mfyp_mtd;
	private String hybre_annual_adj_mfyp_ytd;
	private String hybre_semi_annual_adj_mfyp_ytd;
	private String hybre_quarterly_adj_mfyp_ytd;
	private String hybre_monthly_adj_mfyp_ytd;
	private String hybre_single_adj_mfyp_ytd;
	private String real_tim_timstamp;
	
	public String getNativ_annual_adj_mfyp_mtd() {
		return nativ_annual_adj_mfyp_mtd;
	}
	public void setNativ_annual_adj_mfyp_mtd(String nativ_annual_adj_mfyp_mtd) {
		this.nativ_annual_adj_mfyp_mtd = nativ_annual_adj_mfyp_mtd;
	}
	public String getNativ_semi_annual_adj_mfyp_mtd() {
		return nativ_semi_annual_adj_mfyp_mtd;
	}
	public void setNativ_semi_annual_adj_mfyp_mtd(String nativ_semi_annual_adj_mfyp_mtd) {
		this.nativ_semi_annual_adj_mfyp_mtd = nativ_semi_annual_adj_mfyp_mtd;
	}
	public String getNativ_quarterly_adj_mfyp_mtd() {
		return nativ_quarterly_adj_mfyp_mtd;
	}
	public void setNativ_quarterly_adj_mfyp_mtd(String nativ_quarterly_adj_mfyp_mtd) {
		this.nativ_quarterly_adj_mfyp_mtd = nativ_quarterly_adj_mfyp_mtd;
	}
	public String getNativ_monthly_adj_mfyp_mtd() {
		return nativ_monthly_adj_mfyp_mtd;
	}
	public void setNativ_monthly_adj_mfyp_mtd(String nativ_monthly_adj_mfyp_mtd) {
		this.nativ_monthly_adj_mfyp_mtd = nativ_monthly_adj_mfyp_mtd;
	}
	public String getNativ_single_adj_mfyp_mtd() {
		return nativ_single_adj_mfyp_mtd;
	}
	public void setNativ_single_adj_mfyp_mtd(String nativ_single_adj_mfyp_mtd) {
		this.nativ_single_adj_mfyp_mtd = nativ_single_adj_mfyp_mtd;
	}
	public String getNativ_annual_adj_mfyp_ytd() {
		return nativ_annual_adj_mfyp_ytd;
	}
	public void setNativ_annual_adj_mfyp_ytd(String nativ_annual_adj_mfyp_ytd) {
		this.nativ_annual_adj_mfyp_ytd = nativ_annual_adj_mfyp_ytd;
	}
	public String getNativ_semi_annual_adj_mfyp_ytd() {
		return nativ_semi_annual_adj_mfyp_ytd;
	}
	public void setNativ_semi_annual_adj_mfyp_ytd(String nativ_semi_annual_adj_mfyp_ytd) {
		this.nativ_semi_annual_adj_mfyp_ytd = nativ_semi_annual_adj_mfyp_ytd;
	}
	public String getNativ_quarterly_adj_mfyp_ytd() {
		return nativ_quarterly_adj_mfyp_ytd;
	}
	public void setNativ_quarterly_adj_mfyp_ytd(String nativ_quarterly_adj_mfyp_ytd) {
		this.nativ_quarterly_adj_mfyp_ytd = nativ_quarterly_adj_mfyp_ytd;
	}
	public String getNativ_monthly_adj_mfyp_ytd() {
		return nativ_monthly_adj_mfyp_ytd;
	}
	public void setNativ_monthly_adj_mfyp_ytd(String nativ_monthly_adj_mfyp_ytd) {
		this.nativ_monthly_adj_mfyp_ytd = nativ_monthly_adj_mfyp_ytd;
	}
	public String getNativ_single_adj_mfyp_ytd() {
		return nativ_single_adj_mfyp_ytd;
	}
	public void setNativ_single_adj_mfyp_ytd(String nativ_single_adj_mfyp_ytd) {
		this.nativ_single_adj_mfyp_ytd = nativ_single_adj_mfyp_ytd;
	}
	public String getHybride_annual_adj_mfyp_mtd() {
		return hybride_annual_adj_mfyp_mtd;
	}
	public void setHybride_annual_adj_mfyp_mtd(String hybride_annual_adj_mfyp_mtd) {
		this.hybride_annual_adj_mfyp_mtd = hybride_annual_adj_mfyp_mtd;
	}
	public String getHybre_semi_annual_adj_mfyp_mtd() {
		return hybre_semi_annual_adj_mfyp_mtd;
	}
	public void setHybre_semi_annual_adj_mfyp_mtd(String hybre_semi_annual_adj_mfyp_mtd) {
		this.hybre_semi_annual_adj_mfyp_mtd = hybre_semi_annual_adj_mfyp_mtd;
	}
	public String getHybre_quarterly_adj_mfyp_mtd() {
		return hybre_quarterly_adj_mfyp_mtd;
	}
	public void setHybre_quarterly_adj_mfyp_mtd(String hybre_quarterly_adj_mfyp_mtd) {
		this.hybre_quarterly_adj_mfyp_mtd = hybre_quarterly_adj_mfyp_mtd;
	}
	public String getHybre_monthly_adj_mfyp_mtd() {
		return hybre_monthly_adj_mfyp_mtd;
	}
	public void setHybre_monthly_adj_mfyp_mtd(String hybre_monthly_adj_mfyp_mtd) {
		this.hybre_monthly_adj_mfyp_mtd = hybre_monthly_adj_mfyp_mtd;
	}
	public String getHybre_single_adj_mfyp_mtd() {
		return hybre_single_adj_mfyp_mtd;
	}
	public void setHybre_single_adj_mfyp_mtd(String hybre_single_adj_mfyp_mtd) {
		this.hybre_single_adj_mfyp_mtd = hybre_single_adj_mfyp_mtd;
	}
	public String getHybre_annual_adj_mfyp_ytd() {
		return hybre_annual_adj_mfyp_ytd;
	}
	public void setHybre_annual_adj_mfyp_ytd(String hybre_annual_adj_mfyp_ytd) {
		this.hybre_annual_adj_mfyp_ytd = hybre_annual_adj_mfyp_ytd;
	}
	public String getHybre_semi_annual_adj_mfyp_ytd() {
		return hybre_semi_annual_adj_mfyp_ytd;
	}
	public void setHybre_semi_annual_adj_mfyp_ytd(String hybre_semi_annual_adj_mfyp_ytd) {
		this.hybre_semi_annual_adj_mfyp_ytd = hybre_semi_annual_adj_mfyp_ytd;
	}
	public String getHybre_quarterly_adj_mfyp_ytd() {
		return hybre_quarterly_adj_mfyp_ytd;
	}
	public void setHybre_quarterly_adj_mfyp_ytd(String hybre_quarterly_adj_mfyp_ytd) {
		this.hybre_quarterly_adj_mfyp_ytd = hybre_quarterly_adj_mfyp_ytd;
	}
	public String getHybre_monthly_adj_mfyp_ytd() {
		return hybre_monthly_adj_mfyp_ytd;
	}
	public void setHybre_monthly_adj_mfyp_ytd(String hybre_monthly_adj_mfyp_ytd) {
		this.hybre_monthly_adj_mfyp_ytd = hybre_monthly_adj_mfyp_ytd;
	}
	public String getHybre_single_adj_mfyp_ytd() {
		return hybre_single_adj_mfyp_ytd;
	}
	public void setHybre_single_adj_mfyp_ytd(String hybre_single_adj_mfyp_ytd) {
		this.hybre_single_adj_mfyp_ytd = hybre_single_adj_mfyp_ytd;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
}
