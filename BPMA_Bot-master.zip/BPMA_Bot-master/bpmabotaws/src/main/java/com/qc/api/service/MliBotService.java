package com.qc.api.service;

import com.qc.api.response.WebhookResponse;

public interface MliBotService 
{
	public  WebhookResponse getBpmaData(String obj);
	
	public void removeCashethirtyminute();
}
