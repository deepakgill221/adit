package com.qc.dataBean;

public class NatHybPenetrationBean 
{
	private String nt_mtd_inforced_count; 
	private String nt_mtd_inforced_afyp;
	private String nt_ytd_inforced_afyp; 
	private String nt_ytd_inforced_count; 
	private String nt_trad_penet_mtd_afyp;       
	private String nt_trad_penet_ytd_afyp;
	private String nt_trad_penet_mtd_pol_cnt; 
	private String nt_trad_penet_ytd_pol_cnt; 
	private String nt_trad_mtd_afyp; 
	private String nt_trad_ytd_afyp; 
	private String nt_trad_mtd_pol_cnt; 
	private String nt_trad_ytd_pol_cnt; 
	private String nt_ul_penet_mtd_afyp;       
	private String nt_ul_penet_ytd_afyp; 
	private String nt_ul_penet_mtd_pol_cnt; 
	private String nt_ul_penet_ytd_pol_cnt; 
	private String nt_ul_mtd_afyp; 
	private String nt_ul_ytd_afyp; 
	private String nt_ul_mtd_pol_cnt; 
	private String nt_ul_ytd_pol_cnt; 
	private String nt_par_penet_mtd_afyp; 
	private String nt_par_penet_ytd_afyp; 
	private String nt_par_penet_mtd_pol_cnt; 
	private String nt_par_penet_ytd_pol_cnt; 
	private String nt_par_mtd_afyp; 
	private String nt_par_ytd_afyp;
	private String nt_par_mtd_pol_cnt; 
	private String nt_par_ytd_pol_cnt; 
	private String nt_nonpar_penet_mtd_afyp; 
	private String nt_nonpar_penet_ytd_afyp; 
	private String nt_nonpar_penet_mtd_pol_cnt; 
	private String nt_nonpar_penet_ytd_pol_cnt; 
	private String nt_nonpar_mtd_afyp; 
	private String nt_nonpar_ytd_afyp; 
	private String nt_nonpar_mtd_pol_cnt; 
	private String nt_nonpar_ytd_pol_cnt; 
	private String nt_protec_penet_mtd_afyp; 
	private String nt_protec_penet_ytd_afyp; 
	private String nt_protec_penet_mtd_pol_cnt; 
	private String nt_protec_penet_ytd_pol_cnt; 
	private String nt_protec_mtd_afyp;
	private String nt_protec_ytd_afyp; 
	private String nt_protec_mtd_pol_cnt; 
	private String nt_protec_ytd_pol_cnt; 
	private String nt_mtd_inforced_adj_mfyp;   
	private String nt_ytd_inforced_adj_mfyp; 
	private String nt_ul_penet_mtd_adj_mfyp; 
	private String nt_ul_penet_ytd_adj_mfyp; 
	private String nt_ul_mtd_adj_mfyp; 
	private String nt_ul_ytd_adj_mfyp; 
	private String nt_par_penet_mtd_adj_mfyp; 
	private String nt_par_penet_ytd_adj_mfyp; 
	private String nt_par_mtd_adj_mfyp; 
	private String nt_par_ytd_adj_mfyp; 
	private String nt_nonpar_penet_mtd_adj_mfyp; 
	private String nt_nonpar_penet_ytd_adj_mfyp; 
	private String nt_nonpar_mtd_adj_mfyp;
	private String nt_nonpar_ytd_adj_mfyp; 
	private String nt_protec_penet_mtd_adj_mfyp; 
	private String nt_protec_penet_ytd_adj_mfyp ;
	private String nt_protec_mtd_adj_mfyp ;
	private String nt_protec_ytd_adj_mfyp ;
	private String hy_mtd_inforced_count ;
	private String hy_mtd_inforced_afyp ;
	private String hy_ytd_inforced_afyp ;
	private String hy_ytd_inforced_count ;
	private String hy_trad_penet_mtd_afyp ;      
	private String hy_trad_penet_ytd_afyp ;
	private String hy_trad_penet_mtd_pol_cnt; 
	private String hy_trad_penet_ytd_pol_cnt ;
	private String hy_trad_mtd_afyp ;
	private String hy_trad_ytd_afyp ;
	private String hy_trad_mtd_pol_cnt; 
	private String hy_trad_ytd_pol_cnt; 
	private String hy_ul_penet_mtd_afyp;       
	private String hy_ul_penet_ytd_afyp ;
	private String hy_ul_penet_mtd_pol_cnt; 
	private String hy_ul_penet_ytd_pol_cnt ;
	private String hy_ul_mtd_afyp ;
	private String hy_ul_ytd_afyp ;
	private String hy_ul_mtd_pol_cnt; 
	private String hy_ul_ytd_pol_cnt ;
	private String hy_par_penet_mtd_afyp; 
	private String hy_par_penet_ytd_afyp; 
	private String hy_par_penet_mtd_pol_cnt; 
	private String hy_par_penet_ytd_pol_cnt ;
	private String hy_par_mtd_afyp ;
	private String hy_par_ytd_afyp ;
	private String hy_par_mtd_pol_cnt; 
	private String hy_par_ytd_pol_cnt ;
	private String hy_nonpar_penet_mtd_afyp; 
	private String hy_nonpar_penet_ytd_afyp ;
	private String hy_nonpar_penet_mtd_pol_cnt; 
	private String hy_nonpar_penet_ytd_pol_cnt ;
	private String hy_nonpar_mtd_afyp ;
	private String hy_nonpar_ytd_afyp ;
	private String hy_nonpar_mtd_pol_cnt; 
	private String hy_nonpar_ytd_pol_cnt ;
	private String hy_protec_penet_mtd_afyp; 
	private String hy_protec_penet_ytd_afyp ;
	private String hy_protec_penet_mtd_pol_cnt; 
	private String hy_protec_penet_ytd_pol_cnt ;
	private String hy_protec_mtd_afyp ;
	private String hy_protec_ytd_afyp ;
	private String hy_protec_mtd_pol_cnt; 
	private String hy_protec_ytd_pol_cnt ;
	private String hy_mtd_inforced_adj_mfyp;  
	private String hy_ytd_inforced_adj_mfyp ;
	private String hy_ul_penet_mtd_adj_mfyp ;
	private String hy_ul_penet_ytd_adj_mfyp ;
	private String hy_ul_mtd_adj_mfyp ;
	private String hy_ul_ytd_adj_mfyp ;
	private String hy_par_penet_mtd_adj_mfyp; 
	private String hy_par_penet_ytd_adj_mfyp ;
	private String hy_par_mtd_adj_mfyp ;
	private String hy_par_ytd_adj_mfyp ;
	private String hy_nonpar_penet_mtd_adj_mfyp; 
	private String hy_nonpar_penet_ytd_adj_mfyp ;
	private String hy_nonpar_mtd_adj_mfyp ;
	private String hy_nonpar_ytd_adj_mfyp ;
	private String hy_protec_penet_mtd_adj_mfyp; 
	private String hy_protec_penet_ytd_adj_mfyp ;
	private String hy_protec_mtd_adj_mfyp ;
	private String hy_protec_ytd_adj_mfyp ;
	private String real_tim_timstamp;
	
	public String getNt_mtd_inforced_count() {
		return nt_mtd_inforced_count;
	}
	public void setNt_mtd_inforced_count(String nt_mtd_inforced_count) {
		this.nt_mtd_inforced_count = nt_mtd_inforced_count;
	}
	public String getNt_mtd_inforced_afyp() {
		return nt_mtd_inforced_afyp;
	}
	public void setNt_mtd_inforced_afyp(String nt_mtd_inforced_afyp) {
		this.nt_mtd_inforced_afyp = nt_mtd_inforced_afyp;
	}
	public String getNt_ytd_inforced_afyp() {
		return nt_ytd_inforced_afyp;
	}
	public void setNt_ytd_inforced_afyp(String nt_ytd_inforced_afyp) {
		this.nt_ytd_inforced_afyp = nt_ytd_inforced_afyp;
	}
	public String getNt_ytd_inforced_count() {
		return nt_ytd_inforced_count;
	}
	public void setNt_ytd_inforced_count(String nt_ytd_inforced_count) {
		this.nt_ytd_inforced_count = nt_ytd_inforced_count;
	}
	public String getNt_trad_penet_mtd_afyp() {
		return nt_trad_penet_mtd_afyp;
	}
	public void setNt_trad_penet_mtd_afyp(String nt_trad_penet_mtd_afyp) {
		this.nt_trad_penet_mtd_afyp = nt_trad_penet_mtd_afyp;
	}
	public String getNt_trad_penet_ytd_afyp() {
		return nt_trad_penet_ytd_afyp;
	}
	public void setNt_trad_penet_ytd_afyp(String nt_trad_penet_ytd_afyp) {
		this.nt_trad_penet_ytd_afyp = nt_trad_penet_ytd_afyp;
	}
	public String getNt_trad_penet_mtd_pol_cnt() {
		return nt_trad_penet_mtd_pol_cnt;
	}
	public void setNt_trad_penet_mtd_pol_cnt(String nt_trad_penet_mtd_pol_cnt) {
		this.nt_trad_penet_mtd_pol_cnt = nt_trad_penet_mtd_pol_cnt;
	}
	public String getNt_trad_penet_ytd_pol_cnt() {
		return nt_trad_penet_ytd_pol_cnt;
	}
	public void setNt_trad_penet_ytd_pol_cnt(String nt_trad_penet_ytd_pol_cnt) {
		this.nt_trad_penet_ytd_pol_cnt = nt_trad_penet_ytd_pol_cnt;
	}
	public String getNt_trad_mtd_afyp() {
		return nt_trad_mtd_afyp;
	}
	public void setNt_trad_mtd_afyp(String nt_trad_mtd_afyp) {
		this.nt_trad_mtd_afyp = nt_trad_mtd_afyp;
	}
	public String getNt_trad_ytd_afyp() {
		return nt_trad_ytd_afyp;
	}
	public void setNt_trad_ytd_afyp(String nt_trad_ytd_afyp) {
		this.nt_trad_ytd_afyp = nt_trad_ytd_afyp;
	}
	public String getNt_trad_mtd_pol_cnt() {
		return nt_trad_mtd_pol_cnt;
	}
	public void setNt_trad_mtd_pol_cnt(String nt_trad_mtd_pol_cnt) {
		this.nt_trad_mtd_pol_cnt = nt_trad_mtd_pol_cnt;
	}
	public String getNt_trad_ytd_pol_cnt() {
		return nt_trad_ytd_pol_cnt;
	}
	public void setNt_trad_ytd_pol_cnt(String nt_trad_ytd_pol_cnt) {
		this.nt_trad_ytd_pol_cnt = nt_trad_ytd_pol_cnt;
	}
	public String getNt_ul_penet_mtd_afyp() {
		return nt_ul_penet_mtd_afyp;
	}
	public void setNt_ul_penet_mtd_afyp(String nt_ul_penet_mtd_afyp) {
		this.nt_ul_penet_mtd_afyp = nt_ul_penet_mtd_afyp;
	}
	public String getNt_ul_penet_ytd_afyp() {
		return nt_ul_penet_ytd_afyp;
	}
	public void setNt_ul_penet_ytd_afyp(String nt_ul_penet_ytd_afyp) {
		this.nt_ul_penet_ytd_afyp = nt_ul_penet_ytd_afyp;
	}
	public String getNt_ul_penet_mtd_pol_cnt() {
		return nt_ul_penet_mtd_pol_cnt;
	}
	public void setNt_ul_penet_mtd_pol_cnt(String nt_ul_penet_mtd_pol_cnt) {
		this.nt_ul_penet_mtd_pol_cnt = nt_ul_penet_mtd_pol_cnt;
	}
	public String getNt_ul_penet_ytd_pol_cnt() {
		return nt_ul_penet_ytd_pol_cnt;
	}
	public void setNt_ul_penet_ytd_pol_cnt(String nt_ul_penet_ytd_pol_cnt) {
		this.nt_ul_penet_ytd_pol_cnt = nt_ul_penet_ytd_pol_cnt;
	}
	public String getNt_ul_mtd_afyp() {
		return nt_ul_mtd_afyp;
	}
	public void setNt_ul_mtd_afyp(String nt_ul_mtd_afyp) {
		this.nt_ul_mtd_afyp = nt_ul_mtd_afyp;
	}
	public String getNt_ul_ytd_afyp() {
		return nt_ul_ytd_afyp;
	}
	public void setNt_ul_ytd_afyp(String nt_ul_ytd_afyp) {
		this.nt_ul_ytd_afyp = nt_ul_ytd_afyp;
	}
	public String getNt_ul_mtd_pol_cnt() {
		return nt_ul_mtd_pol_cnt;
	}
	public void setNt_ul_mtd_pol_cnt(String nt_ul_mtd_pol_cnt) {
		this.nt_ul_mtd_pol_cnt = nt_ul_mtd_pol_cnt;
	}
	public String getNt_ul_ytd_pol_cnt() {
		return nt_ul_ytd_pol_cnt;
	}
	public void setNt_ul_ytd_pol_cnt(String nt_ul_ytd_pol_cnt) {
		this.nt_ul_ytd_pol_cnt = nt_ul_ytd_pol_cnt;
	}
	public String getNt_par_penet_mtd_afyp() {
		return nt_par_penet_mtd_afyp;
	}
	public void setNt_par_penet_mtd_afyp(String nt_par_penet_mtd_afyp) {
		this.nt_par_penet_mtd_afyp = nt_par_penet_mtd_afyp;
	}
	public String getNt_par_penet_ytd_afyp() {
		return nt_par_penet_ytd_afyp;
	}
	public void setNt_par_penet_ytd_afyp(String nt_par_penet_ytd_afyp) {
		this.nt_par_penet_ytd_afyp = nt_par_penet_ytd_afyp;
	}
	public String getNt_par_penet_mtd_pol_cnt() {
		return nt_par_penet_mtd_pol_cnt;
	}
	public void setNt_par_penet_mtd_pol_cnt(String nt_par_penet_mtd_pol_cnt) {
		this.nt_par_penet_mtd_pol_cnt = nt_par_penet_mtd_pol_cnt;
	}
	public String getNt_par_penet_ytd_pol_cnt() {
		return nt_par_penet_ytd_pol_cnt;
	}
	public void setNt_par_penet_ytd_pol_cnt(String nt_par_penet_ytd_pol_cnt) {
		this.nt_par_penet_ytd_pol_cnt = nt_par_penet_ytd_pol_cnt;
	}
	public String getNt_par_mtd_afyp() {
		return nt_par_mtd_afyp;
	}
	public void setNt_par_mtd_afyp(String nt_par_mtd_afyp) {
		this.nt_par_mtd_afyp = nt_par_mtd_afyp;
	}
	public String getNt_par_ytd_afyp() {
		return nt_par_ytd_afyp;
	}
	public void setNt_par_ytd_afyp(String nt_par_ytd_afyp) {
		this.nt_par_ytd_afyp = nt_par_ytd_afyp;
	}
	public String getNt_par_mtd_pol_cnt() {
		return nt_par_mtd_pol_cnt;
	}
	public void setNt_par_mtd_pol_cnt(String nt_par_mtd_pol_cnt) {
		this.nt_par_mtd_pol_cnt = nt_par_mtd_pol_cnt;
	}
	public String getNt_par_ytd_pol_cnt() {
		return nt_par_ytd_pol_cnt;
	}
	public void setNt_par_ytd_pol_cnt(String nt_par_ytd_pol_cnt) {
		this.nt_par_ytd_pol_cnt = nt_par_ytd_pol_cnt;
	}
	public String getNt_nonpar_penet_mtd_afyp() {
		return nt_nonpar_penet_mtd_afyp;
	}
	public void setNt_nonpar_penet_mtd_afyp(String nt_nonpar_penet_mtd_afyp) {
		this.nt_nonpar_penet_mtd_afyp = nt_nonpar_penet_mtd_afyp;
	}
	public String getNt_nonpar_penet_ytd_afyp() {
		return nt_nonpar_penet_ytd_afyp;
	}
	public void setNt_nonpar_penet_ytd_afyp(String nt_nonpar_penet_ytd_afyp) {
		this.nt_nonpar_penet_ytd_afyp = nt_nonpar_penet_ytd_afyp;
	}
	public String getNt_nonpar_penet_mtd_pol_cnt() {
		return nt_nonpar_penet_mtd_pol_cnt;
	}
	public void setNt_nonpar_penet_mtd_pol_cnt(String nt_nonpar_penet_mtd_pol_cnt) {
		this.nt_nonpar_penet_mtd_pol_cnt = nt_nonpar_penet_mtd_pol_cnt;
	}
	public String getNt_nonpar_penet_ytd_pol_cnt() {
		return nt_nonpar_penet_ytd_pol_cnt;
	}
	public void setNt_nonpar_penet_ytd_pol_cnt(String nt_nonpar_penet_ytd_pol_cnt) {
		this.nt_nonpar_penet_ytd_pol_cnt = nt_nonpar_penet_ytd_pol_cnt;
	}
	public String getNt_nonpar_mtd_afyp() {
		return nt_nonpar_mtd_afyp;
	}
	public void setNt_nonpar_mtd_afyp(String nt_nonpar_mtd_afyp) {
		this.nt_nonpar_mtd_afyp = nt_nonpar_mtd_afyp;
	}
	public String getNt_nonpar_ytd_afyp() {
		return nt_nonpar_ytd_afyp;
	}
	public void setNt_nonpar_ytd_afyp(String nt_nonpar_ytd_afyp) {
		this.nt_nonpar_ytd_afyp = nt_nonpar_ytd_afyp;
	}
	public String getNt_nonpar_mtd_pol_cnt() {
		return nt_nonpar_mtd_pol_cnt;
	}
	public void setNt_nonpar_mtd_pol_cnt(String nt_nonpar_mtd_pol_cnt) {
		this.nt_nonpar_mtd_pol_cnt = nt_nonpar_mtd_pol_cnt;
	}
	public String getNt_nonpar_ytd_pol_cnt() {
		return nt_nonpar_ytd_pol_cnt;
	}
	public void setNt_nonpar_ytd_pol_cnt(String nt_nonpar_ytd_pol_cnt) {
		this.nt_nonpar_ytd_pol_cnt = nt_nonpar_ytd_pol_cnt;
	}
	public String getNt_protec_penet_mtd_afyp() {
		return nt_protec_penet_mtd_afyp;
	}
	public void setNt_protec_penet_mtd_afyp(String nt_protec_penet_mtd_afyp) {
		this.nt_protec_penet_mtd_afyp = nt_protec_penet_mtd_afyp;
	}
	public String getNt_protec_penet_ytd_afyp() {
		return nt_protec_penet_ytd_afyp;
	}
	public void setNt_protec_penet_ytd_afyp(String nt_protec_penet_ytd_afyp) {
		this.nt_protec_penet_ytd_afyp = nt_protec_penet_ytd_afyp;
	}
	public String getNt_protec_penet_mtd_pol_cnt() {
		return nt_protec_penet_mtd_pol_cnt;
	}
	public void setNt_protec_penet_mtd_pol_cnt(String nt_protec_penet_mtd_pol_cnt) {
		this.nt_protec_penet_mtd_pol_cnt = nt_protec_penet_mtd_pol_cnt;
	}
	public String getNt_protec_penet_ytd_pol_cnt() {
		return nt_protec_penet_ytd_pol_cnt;
	}
	public void setNt_protec_penet_ytd_pol_cnt(String nt_protec_penet_ytd_pol_cnt) {
		this.nt_protec_penet_ytd_pol_cnt = nt_protec_penet_ytd_pol_cnt;
	}
	public String getNt_protec_mtd_afyp() {
		return nt_protec_mtd_afyp;
	}
	public void setNt_protec_mtd_afyp(String nt_protec_mtd_afyp) {
		this.nt_protec_mtd_afyp = nt_protec_mtd_afyp;
	}
	public String getNt_protec_ytd_afyp() {
		return nt_protec_ytd_afyp;
	}
	public void setNt_protec_ytd_afyp(String nt_protec_ytd_afyp) {
		this.nt_protec_ytd_afyp = nt_protec_ytd_afyp;
	}
	public String getNt_protec_mtd_pol_cnt() {
		return nt_protec_mtd_pol_cnt;
	}
	public void setNt_protec_mtd_pol_cnt(String nt_protec_mtd_pol_cnt) {
		this.nt_protec_mtd_pol_cnt = nt_protec_mtd_pol_cnt;
	}
	public String getNt_protec_ytd_pol_cnt() {
		return nt_protec_ytd_pol_cnt;
	}
	public void setNt_protec_ytd_pol_cnt(String nt_protec_ytd_pol_cnt) {
		this.nt_protec_ytd_pol_cnt = nt_protec_ytd_pol_cnt;
	}
	public String getNt_mtd_inforced_adj_mfyp() {
		return nt_mtd_inforced_adj_mfyp;
	}
	public void setNt_mtd_inforced_adj_mfyp(String nt_mtd_inforced_adj_mfyp) {
		this.nt_mtd_inforced_adj_mfyp = nt_mtd_inforced_adj_mfyp;
	}
	public String getNt_ytd_inforced_adj_mfyp() {
		return nt_ytd_inforced_adj_mfyp;
	}
	public void setNt_ytd_inforced_adj_mfyp(String nt_ytd_inforced_adj_mfyp) {
		this.nt_ytd_inforced_adj_mfyp = nt_ytd_inforced_adj_mfyp;
	}
	public String getNt_ul_penet_mtd_adj_mfyp() {
		return nt_ul_penet_mtd_adj_mfyp;
	}
	public void setNt_ul_penet_mtd_adj_mfyp(String nt_ul_penet_mtd_adj_mfyp) {
		this.nt_ul_penet_mtd_adj_mfyp = nt_ul_penet_mtd_adj_mfyp;
	}
	public String getNt_ul_penet_ytd_adj_mfyp() {
		return nt_ul_penet_ytd_adj_mfyp;
	}
	public void setNt_ul_penet_ytd_adj_mfyp(String nt_ul_penet_ytd_adj_mfyp) {
		this.nt_ul_penet_ytd_adj_mfyp = nt_ul_penet_ytd_adj_mfyp;
	}
	public String getNt_ul_mtd_adj_mfyp() {
		return nt_ul_mtd_adj_mfyp;
	}
	public void setNt_ul_mtd_adj_mfyp(String nt_ul_mtd_adj_mfyp) {
		this.nt_ul_mtd_adj_mfyp = nt_ul_mtd_adj_mfyp;
	}
	public String getNt_ul_ytd_adj_mfyp() {
		return nt_ul_ytd_adj_mfyp;
	}
	public void setNt_ul_ytd_adj_mfyp(String nt_ul_ytd_adj_mfyp) {
		this.nt_ul_ytd_adj_mfyp = nt_ul_ytd_adj_mfyp;
	}
	public String getNt_par_penet_mtd_adj_mfyp() {
		return nt_par_penet_mtd_adj_mfyp;
	}
	public void setNt_par_penet_mtd_adj_mfyp(String nt_par_penet_mtd_adj_mfyp) {
		this.nt_par_penet_mtd_adj_mfyp = nt_par_penet_mtd_adj_mfyp;
	}
	public String getNt_par_penet_ytd_adj_mfyp() {
		return nt_par_penet_ytd_adj_mfyp;
	}
	public void setNt_par_penet_ytd_adj_mfyp(String nt_par_penet_ytd_adj_mfyp) {
		this.nt_par_penet_ytd_adj_mfyp = nt_par_penet_ytd_adj_mfyp;
	}
	public String getNt_par_mtd_adj_mfyp() {
		return nt_par_mtd_adj_mfyp;
	}
	public void setNt_par_mtd_adj_mfyp(String nt_par_mtd_adj_mfyp) {
		this.nt_par_mtd_adj_mfyp = nt_par_mtd_adj_mfyp;
	}
	public String getNt_par_ytd_adj_mfyp() {
		return nt_par_ytd_adj_mfyp;
	}
	public void setNt_par_ytd_adj_mfyp(String nt_par_ytd_adj_mfyp) {
		this.nt_par_ytd_adj_mfyp = nt_par_ytd_adj_mfyp;
	}
	public String getNt_nonpar_penet_mtd_adj_mfyp() {
		return nt_nonpar_penet_mtd_adj_mfyp;
	}
	public void setNt_nonpar_penet_mtd_adj_mfyp(String nt_nonpar_penet_mtd_adj_mfyp) {
		this.nt_nonpar_penet_mtd_adj_mfyp = nt_nonpar_penet_mtd_adj_mfyp;
	}
	public String getNt_nonpar_penet_ytd_adj_mfyp() {
		return nt_nonpar_penet_ytd_adj_mfyp;
	}
	public void setNt_nonpar_penet_ytd_adj_mfyp(String nt_nonpar_penet_ytd_adj_mfyp) {
		this.nt_nonpar_penet_ytd_adj_mfyp = nt_nonpar_penet_ytd_adj_mfyp;
	}
	public String getNt_nonpar_mtd_adj_mfyp() {
		return nt_nonpar_mtd_adj_mfyp;
	}
	public void setNt_nonpar_mtd_adj_mfyp(String nt_nonpar_mtd_adj_mfyp) {
		this.nt_nonpar_mtd_adj_mfyp = nt_nonpar_mtd_adj_mfyp;
	}
	public String getNt_nonpar_ytd_adj_mfyp() {
		return nt_nonpar_ytd_adj_mfyp;
	}
	public void setNt_nonpar_ytd_adj_mfyp(String nt_nonpar_ytd_adj_mfyp) {
		this.nt_nonpar_ytd_adj_mfyp = nt_nonpar_ytd_adj_mfyp;
	}
	public String getNt_protec_penet_mtd_adj_mfyp() {
		return nt_protec_penet_mtd_adj_mfyp;
	}
	public void setNt_protec_penet_mtd_adj_mfyp(String nt_protec_penet_mtd_adj_mfyp) {
		this.nt_protec_penet_mtd_adj_mfyp = nt_protec_penet_mtd_adj_mfyp;
	}
	public String getNt_protec_penet_ytd_adj_mfyp() {
		return nt_protec_penet_ytd_adj_mfyp;
	}
	public void setNt_protec_penet_ytd_adj_mfyp(String nt_protec_penet_ytd_adj_mfyp) {
		this.nt_protec_penet_ytd_adj_mfyp = nt_protec_penet_ytd_adj_mfyp;
	}
	public String getNt_protec_mtd_adj_mfyp() {
		return nt_protec_mtd_adj_mfyp;
	}
	public void setNt_protec_mtd_adj_mfyp(String nt_protec_mtd_adj_mfyp) {
		this.nt_protec_mtd_adj_mfyp = nt_protec_mtd_adj_mfyp;
	}
	public String getNt_protec_ytd_adj_mfyp() {
		return nt_protec_ytd_adj_mfyp;
	}
	public void setNt_protec_ytd_adj_mfyp(String nt_protec_ytd_adj_mfyp) {
		this.nt_protec_ytd_adj_mfyp = nt_protec_ytd_adj_mfyp;
	}
	public String getHy_mtd_inforced_count() {
		return hy_mtd_inforced_count;
	}
	public void setHy_mtd_inforced_count(String hy_mtd_inforced_count) {
		this.hy_mtd_inforced_count = hy_mtd_inforced_count;
	}
	public String getHy_mtd_inforced_afyp() {
		return hy_mtd_inforced_afyp;
	}
	public void setHy_mtd_inforced_afyp(String hy_mtd_inforced_afyp) {
		this.hy_mtd_inforced_afyp = hy_mtd_inforced_afyp;
	}
	public String getHy_ytd_inforced_afyp() {
		return hy_ytd_inforced_afyp;
	}
	public void setHy_ytd_inforced_afyp(String hy_ytd_inforced_afyp) {
		this.hy_ytd_inforced_afyp = hy_ytd_inforced_afyp;
	}
	public String getHy_ytd_inforced_count() {
		return hy_ytd_inforced_count;
	}
	public void setHy_ytd_inforced_count(String hy_ytd_inforced_count) {
		this.hy_ytd_inforced_count = hy_ytd_inforced_count;
	}
	public String getHy_trad_penet_mtd_afyp() {
		return hy_trad_penet_mtd_afyp;
	}
	public void setHy_trad_penet_mtd_afyp(String hy_trad_penet_mtd_afyp) {
		this.hy_trad_penet_mtd_afyp = hy_trad_penet_mtd_afyp;
	}
	public String getHy_trad_penet_ytd_afyp() {
		return hy_trad_penet_ytd_afyp;
	}
	public void setHy_trad_penet_ytd_afyp(String hy_trad_penet_ytd_afyp) {
		this.hy_trad_penet_ytd_afyp = hy_trad_penet_ytd_afyp;
	}
	public String getHy_trad_penet_mtd_pol_cnt() {
		return hy_trad_penet_mtd_pol_cnt;
	}
	public void setHy_trad_penet_mtd_pol_cnt(String hy_trad_penet_mtd_pol_cnt) {
		this.hy_trad_penet_mtd_pol_cnt = hy_trad_penet_mtd_pol_cnt;
	}
	public String getHy_trad_penet_ytd_pol_cnt() {
		return hy_trad_penet_ytd_pol_cnt;
	}
	public void setHy_trad_penet_ytd_pol_cnt(String hy_trad_penet_ytd_pol_cnt) {
		this.hy_trad_penet_ytd_pol_cnt = hy_trad_penet_ytd_pol_cnt;
	}
	public String getHy_trad_mtd_afyp() {
		return hy_trad_mtd_afyp;
	}
	public void setHy_trad_mtd_afyp(String hy_trad_mtd_afyp) {
		this.hy_trad_mtd_afyp = hy_trad_mtd_afyp;
	}
	public String getHy_trad_ytd_afyp() {
		return hy_trad_ytd_afyp;
	}
	public void setHy_trad_ytd_afyp(String hy_trad_ytd_afyp) {
		this.hy_trad_ytd_afyp = hy_trad_ytd_afyp;
	}
	public String getHy_trad_mtd_pol_cnt() {
		return hy_trad_mtd_pol_cnt;
	}
	public void setHy_trad_mtd_pol_cnt(String hy_trad_mtd_pol_cnt) {
		this.hy_trad_mtd_pol_cnt = hy_trad_mtd_pol_cnt;
	}
	public String getHy_trad_ytd_pol_cnt() {
		return hy_trad_ytd_pol_cnt;
	}
	public void setHy_trad_ytd_pol_cnt(String hy_trad_ytd_pol_cnt) {
		this.hy_trad_ytd_pol_cnt = hy_trad_ytd_pol_cnt;
	}
	public String getHy_ul_penet_mtd_afyp() {
		return hy_ul_penet_mtd_afyp;
	}
	public void setHy_ul_penet_mtd_afyp(String hy_ul_penet_mtd_afyp) {
		this.hy_ul_penet_mtd_afyp = hy_ul_penet_mtd_afyp;
	}
	public String getHy_ul_penet_ytd_afyp() {
		return hy_ul_penet_ytd_afyp;
	}
	public void setHy_ul_penet_ytd_afyp(String hy_ul_penet_ytd_afyp) {
		this.hy_ul_penet_ytd_afyp = hy_ul_penet_ytd_afyp;
	}
	public String getHy_ul_penet_mtd_pol_cnt() {
		return hy_ul_penet_mtd_pol_cnt;
	}
	public void setHy_ul_penet_mtd_pol_cnt(String hy_ul_penet_mtd_pol_cnt) {
		this.hy_ul_penet_mtd_pol_cnt = hy_ul_penet_mtd_pol_cnt;
	}
	public String getHy_ul_penet_ytd_pol_cnt() {
		return hy_ul_penet_ytd_pol_cnt;
	}
	public void setHy_ul_penet_ytd_pol_cnt(String hy_ul_penet_ytd_pol_cnt) {
		this.hy_ul_penet_ytd_pol_cnt = hy_ul_penet_ytd_pol_cnt;
	}
	public String getHy_ul_mtd_afyp() {
		return hy_ul_mtd_afyp;
	}
	public void setHy_ul_mtd_afyp(String hy_ul_mtd_afyp) {
		this.hy_ul_mtd_afyp = hy_ul_mtd_afyp;
	}
	public String getHy_ul_ytd_afyp() {
		return hy_ul_ytd_afyp;
	}
	public void setHy_ul_ytd_afyp(String hy_ul_ytd_afyp) {
		this.hy_ul_ytd_afyp = hy_ul_ytd_afyp;
	}
	public String getHy_ul_mtd_pol_cnt() {
		return hy_ul_mtd_pol_cnt;
	}
	public void setHy_ul_mtd_pol_cnt(String hy_ul_mtd_pol_cnt) {
		this.hy_ul_mtd_pol_cnt = hy_ul_mtd_pol_cnt;
	}
	public String getHy_ul_ytd_pol_cnt() {
		return hy_ul_ytd_pol_cnt;
	}
	public void setHy_ul_ytd_pol_cnt(String hy_ul_ytd_pol_cnt) {
		this.hy_ul_ytd_pol_cnt = hy_ul_ytd_pol_cnt;
	}
	public String getHy_par_penet_mtd_afyp() {
		return hy_par_penet_mtd_afyp;
	}
	public void setHy_par_penet_mtd_afyp(String hy_par_penet_mtd_afyp) {
		this.hy_par_penet_mtd_afyp = hy_par_penet_mtd_afyp;
	}
	public String getHy_par_penet_ytd_afyp() {
		return hy_par_penet_ytd_afyp;
	}
	public void setHy_par_penet_ytd_afyp(String hy_par_penet_ytd_afyp) {
		this.hy_par_penet_ytd_afyp = hy_par_penet_ytd_afyp;
	}
	public String getHy_par_penet_mtd_pol_cnt() {
		return hy_par_penet_mtd_pol_cnt;
	}
	public void setHy_par_penet_mtd_pol_cnt(String hy_par_penet_mtd_pol_cnt) {
		this.hy_par_penet_mtd_pol_cnt = hy_par_penet_mtd_pol_cnt;
	}
	public String getHy_par_penet_ytd_pol_cnt() {
		return hy_par_penet_ytd_pol_cnt;
	}
	public void setHy_par_penet_ytd_pol_cnt(String hy_par_penet_ytd_pol_cnt) {
		this.hy_par_penet_ytd_pol_cnt = hy_par_penet_ytd_pol_cnt;
	}
	public String getHy_par_mtd_afyp() {
		return hy_par_mtd_afyp;
	}
	public void setHy_par_mtd_afyp(String hy_par_mtd_afyp) {
		this.hy_par_mtd_afyp = hy_par_mtd_afyp;
	}
	public String getHy_par_ytd_afyp() {
		return hy_par_ytd_afyp;
	}
	public void setHy_par_ytd_afyp(String hy_par_ytd_afyp) {
		this.hy_par_ytd_afyp = hy_par_ytd_afyp;
	}
	public String getHy_par_mtd_pol_cnt() {
		return hy_par_mtd_pol_cnt;
	}
	public void setHy_par_mtd_pol_cnt(String hy_par_mtd_pol_cnt) {
		this.hy_par_mtd_pol_cnt = hy_par_mtd_pol_cnt;
	}
	public String getHy_par_ytd_pol_cnt() {
		return hy_par_ytd_pol_cnt;
	}
	public void setHy_par_ytd_pol_cnt(String hy_par_ytd_pol_cnt) {
		this.hy_par_ytd_pol_cnt = hy_par_ytd_pol_cnt;
	}
	public String getHy_nonpar_penet_mtd_afyp() {
		return hy_nonpar_penet_mtd_afyp;
	}
	public void setHy_nonpar_penet_mtd_afyp(String hy_nonpar_penet_mtd_afyp) {
		this.hy_nonpar_penet_mtd_afyp = hy_nonpar_penet_mtd_afyp;
	}
	public String getHy_nonpar_penet_ytd_afyp() {
		return hy_nonpar_penet_ytd_afyp;
	}
	public void setHy_nonpar_penet_ytd_afyp(String hy_nonpar_penet_ytd_afyp) {
		this.hy_nonpar_penet_ytd_afyp = hy_nonpar_penet_ytd_afyp;
	}
	public String getHy_nonpar_penet_mtd_pol_cnt() {
		return hy_nonpar_penet_mtd_pol_cnt;
	}
	public void setHy_nonpar_penet_mtd_pol_cnt(String hy_nonpar_penet_mtd_pol_cnt) {
		this.hy_nonpar_penet_mtd_pol_cnt = hy_nonpar_penet_mtd_pol_cnt;
	}
	public String getHy_nonpar_penet_ytd_pol_cnt() {
		return hy_nonpar_penet_ytd_pol_cnt;
	}
	public void setHy_nonpar_penet_ytd_pol_cnt(String hy_nonpar_penet_ytd_pol_cnt) {
		this.hy_nonpar_penet_ytd_pol_cnt = hy_nonpar_penet_ytd_pol_cnt;
	}
	public String getHy_nonpar_mtd_afyp() {
		return hy_nonpar_mtd_afyp;
	}
	public void setHy_nonpar_mtd_afyp(String hy_nonpar_mtd_afyp) {
		this.hy_nonpar_mtd_afyp = hy_nonpar_mtd_afyp;
	}
	public String getHy_nonpar_ytd_afyp() {
		return hy_nonpar_ytd_afyp;
	}
	public void setHy_nonpar_ytd_afyp(String hy_nonpar_ytd_afyp) {
		this.hy_nonpar_ytd_afyp = hy_nonpar_ytd_afyp;
	}
	public String getHy_nonpar_mtd_pol_cnt() {
		return hy_nonpar_mtd_pol_cnt;
	}
	public void setHy_nonpar_mtd_pol_cnt(String hy_nonpar_mtd_pol_cnt) {
		this.hy_nonpar_mtd_pol_cnt = hy_nonpar_mtd_pol_cnt;
	}
	public String getHy_nonpar_ytd_pol_cnt() {
		return hy_nonpar_ytd_pol_cnt;
	}
	public void setHy_nonpar_ytd_pol_cnt(String hy_nonpar_ytd_pol_cnt) {
		this.hy_nonpar_ytd_pol_cnt = hy_nonpar_ytd_pol_cnt;
	}
	public String getHy_protec_penet_mtd_afyp() {
		return hy_protec_penet_mtd_afyp;
	}
	public void setHy_protec_penet_mtd_afyp(String hy_protec_penet_mtd_afyp) {
		this.hy_protec_penet_mtd_afyp = hy_protec_penet_mtd_afyp;
	}
	public String getHy_protec_penet_ytd_afyp() {
		return hy_protec_penet_ytd_afyp;
	}
	public void setHy_protec_penet_ytd_afyp(String hy_protec_penet_ytd_afyp) {
		this.hy_protec_penet_ytd_afyp = hy_protec_penet_ytd_afyp;
	}
	public String getHy_protec_penet_mtd_pol_cnt() {
		return hy_protec_penet_mtd_pol_cnt;
	}
	public void setHy_protec_penet_mtd_pol_cnt(String hy_protec_penet_mtd_pol_cnt) {
		this.hy_protec_penet_mtd_pol_cnt = hy_protec_penet_mtd_pol_cnt;
	}
	public String getHy_protec_penet_ytd_pol_cnt() {
		return hy_protec_penet_ytd_pol_cnt;
	}
	public void setHy_protec_penet_ytd_pol_cnt(String hy_protec_penet_ytd_pol_cnt) {
		this.hy_protec_penet_ytd_pol_cnt = hy_protec_penet_ytd_pol_cnt;
	}
	public String getHy_protec_mtd_afyp() {
		return hy_protec_mtd_afyp;
	}
	public void setHy_protec_mtd_afyp(String hy_protec_mtd_afyp) {
		this.hy_protec_mtd_afyp = hy_protec_mtd_afyp;
	}
	public String getHy_protec_ytd_afyp() {
		return hy_protec_ytd_afyp;
	}
	public void setHy_protec_ytd_afyp(String hy_protec_ytd_afyp) {
		this.hy_protec_ytd_afyp = hy_protec_ytd_afyp;
	}
	public String getHy_protec_mtd_pol_cnt() {
		return hy_protec_mtd_pol_cnt;
	}
	public void setHy_protec_mtd_pol_cnt(String hy_protec_mtd_pol_cnt) {
		this.hy_protec_mtd_pol_cnt = hy_protec_mtd_pol_cnt;
	}
	public String getHy_protec_ytd_pol_cnt() {
		return hy_protec_ytd_pol_cnt;
	}
	public void setHy_protec_ytd_pol_cnt(String hy_protec_ytd_pol_cnt) {
		this.hy_protec_ytd_pol_cnt = hy_protec_ytd_pol_cnt;
	}
	public String getHy_mtd_inforced_adj_mfyp() {
		return hy_mtd_inforced_adj_mfyp;
	}
	public void setHy_mtd_inforced_adj_mfyp(String hy_mtd_inforced_adj_mfyp) {
		this.hy_mtd_inforced_adj_mfyp = hy_mtd_inforced_adj_mfyp;
	}
	public String getHy_ytd_inforced_adj_mfyp() {
		return hy_ytd_inforced_adj_mfyp;
	}
	public void setHy_ytd_inforced_adj_mfyp(String hy_ytd_inforced_adj_mfyp) {
		this.hy_ytd_inforced_adj_mfyp = hy_ytd_inforced_adj_mfyp;
	}
	public String getHy_ul_penet_mtd_adj_mfyp() {
		return hy_ul_penet_mtd_adj_mfyp;
	}
	public void setHy_ul_penet_mtd_adj_mfyp(String hy_ul_penet_mtd_adj_mfyp) {
		this.hy_ul_penet_mtd_adj_mfyp = hy_ul_penet_mtd_adj_mfyp;
	}
	public String getHy_ul_penet_ytd_adj_mfyp() {
		return hy_ul_penet_ytd_adj_mfyp;
	}
	public void setHy_ul_penet_ytd_adj_mfyp(String hy_ul_penet_ytd_adj_mfyp) {
		this.hy_ul_penet_ytd_adj_mfyp = hy_ul_penet_ytd_adj_mfyp;
	}
	public String getHy_ul_mtd_adj_mfyp() {
		return hy_ul_mtd_adj_mfyp;
	}
	public void setHy_ul_mtd_adj_mfyp(String hy_ul_mtd_adj_mfyp) {
		this.hy_ul_mtd_adj_mfyp = hy_ul_mtd_adj_mfyp;
	}
	public String getHy_ul_ytd_adj_mfyp() {
		return hy_ul_ytd_adj_mfyp;
	}
	public void setHy_ul_ytd_adj_mfyp(String hy_ul_ytd_adj_mfyp) {
		this.hy_ul_ytd_adj_mfyp = hy_ul_ytd_adj_mfyp;
	}
	public String getHy_par_penet_mtd_adj_mfyp() {
		return hy_par_penet_mtd_adj_mfyp;
	}
	public void setHy_par_penet_mtd_adj_mfyp(String hy_par_penet_mtd_adj_mfyp) {
		this.hy_par_penet_mtd_adj_mfyp = hy_par_penet_mtd_adj_mfyp;
	}
	public String getHy_par_penet_ytd_adj_mfyp() {
		return hy_par_penet_ytd_adj_mfyp;
	}
	public void setHy_par_penet_ytd_adj_mfyp(String hy_par_penet_ytd_adj_mfyp) {
		this.hy_par_penet_ytd_adj_mfyp = hy_par_penet_ytd_adj_mfyp;
	}
	public String getHy_par_mtd_adj_mfyp() {
		return hy_par_mtd_adj_mfyp;
	}
	public void setHy_par_mtd_adj_mfyp(String hy_par_mtd_adj_mfyp) {
		this.hy_par_mtd_adj_mfyp = hy_par_mtd_adj_mfyp;
	}
	public String getHy_par_ytd_adj_mfyp() {
		return hy_par_ytd_adj_mfyp;
	}
	public void setHy_par_ytd_adj_mfyp(String hy_par_ytd_adj_mfyp) {
		this.hy_par_ytd_adj_mfyp = hy_par_ytd_adj_mfyp;
	}
	public String getHy_nonpar_penet_mtd_adj_mfyp() {
		return hy_nonpar_penet_mtd_adj_mfyp;
	}
	public void setHy_nonpar_penet_mtd_adj_mfyp(String hy_nonpar_penet_mtd_adj_mfyp) {
		this.hy_nonpar_penet_mtd_adj_mfyp = hy_nonpar_penet_mtd_adj_mfyp;
	}
	public String getHy_nonpar_penet_ytd_adj_mfyp() {
		return hy_nonpar_penet_ytd_adj_mfyp;
	}
	public void setHy_nonpar_penet_ytd_adj_mfyp(String hy_nonpar_penet_ytd_adj_mfyp) {
		this.hy_nonpar_penet_ytd_adj_mfyp = hy_nonpar_penet_ytd_adj_mfyp;
	}
	public String getHy_nonpar_mtd_adj_mfyp() {
		return hy_nonpar_mtd_adj_mfyp;
	}
	public void setHy_nonpar_mtd_adj_mfyp(String hy_nonpar_mtd_adj_mfyp) {
		this.hy_nonpar_mtd_adj_mfyp = hy_nonpar_mtd_adj_mfyp;
	}
	public String getHy_nonpar_ytd_adj_mfyp() {
		return hy_nonpar_ytd_adj_mfyp;
	}
	public void setHy_nonpar_ytd_adj_mfyp(String hy_nonpar_ytd_adj_mfyp) {
		this.hy_nonpar_ytd_adj_mfyp = hy_nonpar_ytd_adj_mfyp;
	}
	public String getHy_protec_penet_mtd_adj_mfyp() {
		return hy_protec_penet_mtd_adj_mfyp;
	}
	public void setHy_protec_penet_mtd_adj_mfyp(String hy_protec_penet_mtd_adj_mfyp) {
		this.hy_protec_penet_mtd_adj_mfyp = hy_protec_penet_mtd_adj_mfyp;
	}
	public String getHy_protec_penet_ytd_adj_mfyp() {
		return hy_protec_penet_ytd_adj_mfyp;
	}
	public void setHy_protec_penet_ytd_adj_mfyp(String hy_protec_penet_ytd_adj_mfyp) {
		this.hy_protec_penet_ytd_adj_mfyp = hy_protec_penet_ytd_adj_mfyp;
	}
	public String getHy_protec_mtd_adj_mfyp() {
		return hy_protec_mtd_adj_mfyp;
	}
	public void setHy_protec_mtd_adj_mfyp(String hy_protec_mtd_adj_mfyp) {
		this.hy_protec_mtd_adj_mfyp = hy_protec_mtd_adj_mfyp;
	}
	public String getHy_protec_ytd_adj_mfyp() {
		return hy_protec_ytd_adj_mfyp;
	}
	public void setHy_protec_ytd_adj_mfyp(String hy_protec_ytd_adj_mfyp) {
		this.hy_protec_ytd_adj_mfyp = hy_protec_ytd_adj_mfyp;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
}