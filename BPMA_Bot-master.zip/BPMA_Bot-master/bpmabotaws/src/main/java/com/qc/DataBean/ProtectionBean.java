package com.qc.dataBean;

public class ProtectionBean {

	private String designation_desc;
	private String channel;
	private String sub_channel;
	private String zone;
	private String region;
	private String circle;
	private String clusters;
	private String go;
	private String cmo;
	private String amo;
	private String protec_ho_wip_count;
	private String protec_go_wip_count;
	private String protec_it_wip_count;
	private String protec_fin_wip_count;
	private String protec_misc_wip_count;
	private String protec_welcome_wip_count;
	private String protec_total_wip_count;
	private String protec_ho_wip_adj_mfyp;
	private String protec_go_wip_adj_mfyp;
	private String protec_it_wip_adj_mfyp;
	private String protec_fin_wip_adj_mfyp;
	private String protec_misc_wip_adj_mfyp;
	private String protec_welcome_wip_adj_mfyp;
	private String protec_total_wip_adj_mfyp;
	private String protec_paid_daily_pol_cnt;
	private String protec_paid_mtd_pol_cnt;
	private String protec_paid_ytd_pol_cnt;
	private String protec_paid_daily_adj_mfyp;
	private String protec_paid_mtd_adj_mfyp;
	private String protec_paid_ytd_adj_mfyp;
	private String protec_daily_applied_afyp;
	private String protec_daily_applied_count;
	private String protec_mtd_applied_afyp;
	private String protec_mtd_applied_count;
	private String protec_ytd_applied_afyp;  
	private String protec_ytd_applied_count;
	private String protec_mtd_applied_adj_ifyp;
	private String protec_ytd_applied_adj_ifyp;
	private String protec_daily_applied_adj_ifyp;
	private String btch_timstamp;
	private String real_tim_timstamp;
	private String protec_paid_daily_afyp;
	private String protec_paid_mtd_afyp;
	private String protec_paid_ytd_afyp;
	private String protec_plan_paid_mtd_afyp;
	private String protec_paln_paid_ytd_afyp;
	private String protec_plan_paid_mtd_adj_mfyp;
	private String protec_plan_paid_ytd_adj_mfyp;
	private String protec_plan_paid_mtd_pol_count;
	private String protec_plan_paid_ytd_pol_count;
	private String protec_paid_achv_mtd_adj_mfyp;
	private String protec_paid_achv_ytd_adj_mfyp;
	private String protec_paid_achv_mtd_afyp;
	private String protec_paid_achv_ytd_afyp;
	private String protec_paid_achv_mtd_nop;
	private String protec_paid_achv_ytd_nop;    

	
	public String getDesignation_desc() {
		return designation_desc;
	}
	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSub_channel() {
		return sub_channel;
	}
	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getClusters() {
		return clusters;
	}
	public void setClusters(String clusters) {
		this.clusters = clusters;
	}
	public String getGo() {
		return go;
	}
	public void setGo(String go) {
		this.go = go;
	}
	public String getCmo() {
		return cmo;
	}
	public void setCmo(String cmo) {
		this.cmo = cmo;
	}
	public String getAmo() {
		return amo;
	}
	public void setAmo(String amo) {
		this.amo = amo;
	}
	public String getProtec_ho_wip_count() {
		return protec_ho_wip_count;
	}
	public void setProtec_ho_wip_count(String protec_ho_wip_count) {
		this.protec_ho_wip_count = protec_ho_wip_count;
	}
	public String getProtec_go_wip_count() {
		return protec_go_wip_count;
	}
	public void setProtec_go_wip_count(String protec_go_wip_count) {
		this.protec_go_wip_count = protec_go_wip_count;
	}
	public String getProtec_it_wip_count() {
		return protec_it_wip_count;
	}
	public void setProtec_it_wip_count(String protec_it_wip_count) {
		this.protec_it_wip_count = protec_it_wip_count;
	}
	public String getProtec_fin_wip_count() {
		return protec_fin_wip_count;
	}
	public void setProtec_fin_wip_count(String protec_fin_wip_count) {
		this.protec_fin_wip_count = protec_fin_wip_count;
	}
	public String getProtec_misc_wip_count() {
		return protec_misc_wip_count;
	}
	public void setProtec_misc_wip_count(String protec_misc_wip_count) {
		this.protec_misc_wip_count = protec_misc_wip_count;
	}
	public String getProtec_welcome_wip_count() {
		return protec_welcome_wip_count;
	}
	public void setProtec_welcome_wip_count(String protec_welcome_wip_count) {
		this.protec_welcome_wip_count = protec_welcome_wip_count;
	}
	public String getProtec_total_wip_count() {
		return protec_total_wip_count;
	}
	public void setProtec_total_wip_count(String protec_total_wip_count) {
		this.protec_total_wip_count = protec_total_wip_count;
	}
	public String getProtec_ho_wip_adj_mfyp() {
		return protec_ho_wip_adj_mfyp;
	}
	public void setProtec_ho_wip_adj_mfyp(String protec_ho_wip_adj_mfyp) {
		this.protec_ho_wip_adj_mfyp = protec_ho_wip_adj_mfyp;
	}
	public String getProtec_go_wip_adj_mfyp() {
		return protec_go_wip_adj_mfyp;
	}
	public void setProtec_go_wip_adj_mfyp(String protec_go_wip_adj_mfyp) {
		this.protec_go_wip_adj_mfyp = protec_go_wip_adj_mfyp;
	}
	public String getProtec_it_wip_adj_mfyp() {
		return protec_it_wip_adj_mfyp;
	}
	public void setProtec_it_wip_adj_mfyp(String protec_it_wip_adj_mfyp) {
		this.protec_it_wip_adj_mfyp = protec_it_wip_adj_mfyp;
	}
	public String getProtec_fin_wip_adj_mfyp() {
		return protec_fin_wip_adj_mfyp;
	}
	public void setProtec_fin_wip_adj_mfyp(String protec_fin_wip_adj_mfyp) {
		this.protec_fin_wip_adj_mfyp = protec_fin_wip_adj_mfyp;
	}
	public String getProtec_misc_wip_adj_mfyp() {
		return protec_misc_wip_adj_mfyp;
	}
	public void setProtec_misc_wip_adj_mfyp(String protec_misc_wip_adj_mfyp) {
		this.protec_misc_wip_adj_mfyp = protec_misc_wip_adj_mfyp;
	}
	public String getProtec_welcome_wip_adj_mfyp() {
		return protec_welcome_wip_adj_mfyp;
	}
	public void setProtec_welcome_wip_adj_mfyp(String protec_welcome_wip_adj_mfyp) {
		this.protec_welcome_wip_adj_mfyp = protec_welcome_wip_adj_mfyp;
	}
	public String getProtec_total_wip_adj_mfyp() {
		return protec_total_wip_adj_mfyp;
	}
	public void setProtec_total_wip_adj_mfyp(String protec_total_wip_adj_mfyp) {
		this.protec_total_wip_adj_mfyp = protec_total_wip_adj_mfyp;
	}
	public String getProtec_paid_daily_pol_cnt() {
		return protec_paid_daily_pol_cnt;
	}
	public void setProtec_paid_daily_pol_cnt(String protec_paid_daily_pol_cnt) {
		this.protec_paid_daily_pol_cnt = protec_paid_daily_pol_cnt;
	}
	public String getProtec_paid_mtd_pol_cnt() {
		return protec_paid_mtd_pol_cnt;
	}
	public void setProtec_paid_mtd_pol_cnt(String protec_paid_mtd_pol_cnt) {
		this.protec_paid_mtd_pol_cnt = protec_paid_mtd_pol_cnt;
	}
	public String getProtec_paid_ytd_pol_cnt() {
		return protec_paid_ytd_pol_cnt;
	}
	public void setProtec_paid_ytd_pol_cnt(String protec_paid_ytd_pol_cnt) {
		this.protec_paid_ytd_pol_cnt = protec_paid_ytd_pol_cnt;
	}
	public String getProtec_paid_daily_adj_mfyp() {
		return protec_paid_daily_adj_mfyp;
	}
	public void setProtec_paid_daily_adj_mfyp(String protec_paid_daily_adj_mfyp) {
		this.protec_paid_daily_adj_mfyp = protec_paid_daily_adj_mfyp;
	}
	public String getProtec_paid_mtd_adj_mfyp() {
		return protec_paid_mtd_adj_mfyp;
	}
	public void setProtec_paid_mtd_adj_mfyp(String protec_paid_mtd_adj_mfyp) {
		this.protec_paid_mtd_adj_mfyp = protec_paid_mtd_adj_mfyp;
	}
	public String getProtec_paid_ytd_adj_mfyp() {
		return protec_paid_ytd_adj_mfyp;
	}
	public void setProtec_paid_ytd_adj_mfyp(String protec_paid_ytd_adj_mfyp) {
		this.protec_paid_ytd_adj_mfyp = protec_paid_ytd_adj_mfyp;
	}
	public String getProtec_daily_applied_afyp() {
		return protec_daily_applied_afyp;
	}
	public void setProtec_daily_applied_afyp(String protec_daily_applied_afyp) {
		this.protec_daily_applied_afyp = protec_daily_applied_afyp;
	}
	public String getProtec_daily_applied_count() {
		return protec_daily_applied_count;
	}
	public void setProtec_daily_applied_count(String protec_daily_applied_count) {
		this.protec_daily_applied_count = protec_daily_applied_count;
	}
	public String getProtec_mtd_applied_afyp() {
		return protec_mtd_applied_afyp;
	}
	public void setProtec_mtd_applied_afyp(String protec_mtd_applied_afyp) {
		this.protec_mtd_applied_afyp = protec_mtd_applied_afyp;
	}
	public String getProtec_mtd_applied_count() {
		return protec_mtd_applied_count;
	}
	public void setProtec_mtd_applied_count(String protec_mtd_applied_count) {
		this.protec_mtd_applied_count = protec_mtd_applied_count;
	}
	public String getProtec_ytd_applied_afyp() {
		return protec_ytd_applied_afyp;
	}
	public void setProtec_ytd_applied_afyp(String protec_ytd_applied_afyp) {
		this.protec_ytd_applied_afyp = protec_ytd_applied_afyp;
	}
	public String getProtec_ytd_applied_count() {
		return protec_ytd_applied_count;
	}
	public void setProtec_ytd_applied_count(String protec_ytd_applied_count) {
		this.protec_ytd_applied_count = protec_ytd_applied_count;
	}
	public String getProtec_mtd_applied_adj_ifyp() {
		return protec_mtd_applied_adj_ifyp;
	}
	public void setProtec_mtd_applied_adj_ifyp(String protec_mtd_applied_adj_ifyp) {
		this.protec_mtd_applied_adj_ifyp = protec_mtd_applied_adj_ifyp;
	}
	public String getProtec_ytd_applied_adj_ifyp() {
		return protec_ytd_applied_adj_ifyp;
	}
	public void setProtec_ytd_applied_adj_ifyp(String protec_ytd_applied_adj_ifyp) {
		this.protec_ytd_applied_adj_ifyp = protec_ytd_applied_adj_ifyp;
	}
	public String getProtec_daily_applied_adj_ifyp() {
		return protec_daily_applied_adj_ifyp;
	}
	public void setProtec_daily_applied_adj_ifyp(String protec_daily_applied_adj_ifyp) {
		this.protec_daily_applied_adj_ifyp = protec_daily_applied_adj_ifyp;
	}
	public String getBtch_timstamp() {
		return btch_timstamp;
	}
	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
	public String getProtec_paid_daily_afyp() {
		return protec_paid_daily_afyp;
	}
	public void setProtec_paid_daily_afyp(String protec_paid_daily_afyp) {
		this.protec_paid_daily_afyp = protec_paid_daily_afyp;
	}
	public String getProtec_paid_mtd_afyp() {
		return protec_paid_mtd_afyp;
	}
	public void setProtec_paid_mtd_afyp(String protec_paid_mtd_afyp) {
		this.protec_paid_mtd_afyp = protec_paid_mtd_afyp;
	}
	public String getProtec_paid_ytd_afyp() {
		return protec_paid_ytd_afyp;
	}
	public void setProtec_paid_ytd_afyp(String protec_paid_ytd_afyp) {
		this.protec_paid_ytd_afyp = protec_paid_ytd_afyp;
	}
	public String getProtec_plan_paid_mtd_afyp() {
		return protec_plan_paid_mtd_afyp;
	}
	public void setProtec_plan_paid_mtd_afyp(String protec_plan_paid_mtd_afyp) {
		this.protec_plan_paid_mtd_afyp = protec_plan_paid_mtd_afyp;
	}
	public String getProtec_paln_paid_ytd_afyp() {
		return protec_paln_paid_ytd_afyp;
	}
	public void setProtec_paln_paid_ytd_afyp(String protec_paln_paid_ytd_afyp) {
		this.protec_paln_paid_ytd_afyp = protec_paln_paid_ytd_afyp;
	}
	public String getProtec_plan_paid_mtd_adj_mfyp() {
		return protec_plan_paid_mtd_adj_mfyp;
	}
	public void setProtec_plan_paid_mtd_adj_mfyp(String protec_plan_paid_mtd_adj_mfyp) {
		this.protec_plan_paid_mtd_adj_mfyp = protec_plan_paid_mtd_adj_mfyp;
	}
	public String getProtec_plan_paid_ytd_adj_mfyp() {
		return protec_plan_paid_ytd_adj_mfyp;
	}
	public void setProtec_plan_paid_ytd_adj_mfyp(String protec_plan_paid_ytd_adj_mfyp) {
		this.protec_plan_paid_ytd_adj_mfyp = protec_plan_paid_ytd_adj_mfyp;
	}
	public String getProtec_plan_paid_mtd_pol_count() {
		return protec_plan_paid_mtd_pol_count;
	}
	public void setProtec_plan_paid_mtd_pol_count(String protec_plan_paid_mtd_pol_count) {
		this.protec_plan_paid_mtd_pol_count = protec_plan_paid_mtd_pol_count;
	}
	public String getProtec_plan_paid_ytd_pol_count() {
		return protec_plan_paid_ytd_pol_count;
	}
	public void setProtec_plan_paid_ytd_pol_count(String protec_plan_paid_ytd_pol_count) {
		this.protec_plan_paid_ytd_pol_count = protec_plan_paid_ytd_pol_count;
	}
	public String getProtec_paid_achv_mtd_adj_mfyp() {
		return protec_paid_achv_mtd_adj_mfyp;
	}
	public void setProtec_paid_achv_mtd_adj_mfyp(String protec_paid_achv_mtd_adj_mfyp) {
		this.protec_paid_achv_mtd_adj_mfyp = protec_paid_achv_mtd_adj_mfyp;
	}
	public String getProtec_paid_achv_ytd_adj_mfyp() {
		return protec_paid_achv_ytd_adj_mfyp;
	}
	public void setProtec_paid_achv_ytd_adj_mfyp(String protec_paid_achv_ytd_adj_mfyp) {
		this.protec_paid_achv_ytd_adj_mfyp = protec_paid_achv_ytd_adj_mfyp;
	}
	public String getProtec_paid_achv_mtd_afyp() {
		return protec_paid_achv_mtd_afyp;
	}
	public void setProtec_paid_achv_mtd_afyp(String protec_paid_achv_mtd_afyp) {
		this.protec_paid_achv_mtd_afyp = protec_paid_achv_mtd_afyp;
	}
	public String getProtec_paid_achv_ytd_afyp() {
		return protec_paid_achv_ytd_afyp;
	}
	public void setProtec_paid_achv_ytd_afyp(String protec_paid_achv_ytd_afyp) {
		this.protec_paid_achv_ytd_afyp = protec_paid_achv_ytd_afyp;
	}
	public String getProtec_paid_achv_mtd_nop() {
		return protec_paid_achv_mtd_nop;
	}
	public void setProtec_paid_achv_mtd_nop(String protec_paid_achv_mtd_nop) {
		this.protec_paid_achv_mtd_nop = protec_paid_achv_mtd_nop;
	}
	public String getProtec_paid_achv_ytd_nop() {
		return protec_paid_achv_ytd_nop;
	}
	public void setProtec_paid_achv_ytd_nop(String protec_paid_achv_ytd_nop) {
		this.protec_paid_achv_ytd_nop = protec_paid_achv_ytd_nop;
	}
	
}
