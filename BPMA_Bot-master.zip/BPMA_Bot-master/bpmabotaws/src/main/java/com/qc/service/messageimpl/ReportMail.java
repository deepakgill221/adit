package com.qc.service.messageimpl;

import java.io.File;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.axis2.util.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.impl.SendMailServiceImpl;
import com.qc.jsonImpl.MailReportJson;
import com.qc.utils.AprApiCall;

@Service
public class ReportMail {
	
	@Autowired
	private AprApiCall aprApiCall;
	@Autowired
	private MailReportJson mailReportJson;
	@Autowired
	private SendMailServiceImpl sendMailServiceImpl;
	
	private static Logger logger = LogManager.getLogger(ReportMail.class);
	
	public String getMailReport(Map<String, Map<String, String>> map, String sessionId){
		
		ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");
		
		String ssoId=map.get(sessionId).get("validSSOID");
		String agentId = map.get(sessionId).get("agentId");
		String emailId = map.get(sessionId).get("emailId");
		String name = map.get(sessionId).get("AgentName");
		String emailField ="YES";
		String aprResponse = aprApiCall.getAprData( ssoId,  agentId,  emailField);
		try{
		JSONObject obj = new JSONObject(aprResponse);
		String status = obj.getJSONObject("errorInfo").get("status").toString();
		
		if("SUCCESS".equalsIgnoreCase(status)){
			
			
			Map<String, Object[] > newMap = mailReportJson.getMailReportData(sessionId, obj);
			
			String fileName=sessionId+".xlsx";
		    String workingDir =  res.getString("workingDirectory");
			String realFile=workingDir+File.separator+fileName;	
		    
     		byte[] bytedata=sendMailServiceImpl.convertPdfToByteArray(workingDir+File.separator+fileName);
     		String filedata=Base64.encode(bytedata);
     		sendMailServiceImpl.sendMail(filedata, emailId, name);
		}
		}
		catch(Exception ex){
			logger.error("Creating excetpion in getMailReport "+ex);
		}
		
	return "";
	}
}
