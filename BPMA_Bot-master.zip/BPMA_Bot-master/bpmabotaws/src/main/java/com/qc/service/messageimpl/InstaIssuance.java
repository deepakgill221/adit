package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.dataBean.InstaIssuanceBean;
import com.qc.utils.HierarchyManage;

@Service
public class InstaIssuance {
	
	@Autowired
	HierarchyManage hierarchyManage;
	public String getInstaIssuanceMsg(String channel, String period, String zone, String region, 
			String circle, String subChannel, String cluster, String go, String lacsCr, 
			InstaIssuanceBean instaIssuanceBean, String superZone, String keyMarket, String instaType){
				
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			period=period.toUpperCase();
		}
		if(!"".equalsIgnoreCase(circle))
		{
			region="Circle "+circle;
		}
		/*------------------------------------------------*/
		if(!"".equalsIgnoreCase(go))
		{
			cluster="Office "+go;
		}
		/*------------------------------------------------*/
		if(!"".equalsIgnoreCase(subChannel))
		{
			channel = subChannel;
		}
		
		String hierarchylevel = hierarchyManage.getHierarchyData(channel, subChannel, superZone, zone, keyMarket, region, cluster, circle, go);
		
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(zone) && "".equalsIgnoreCase(region) && "".equalsIgnoreCase(cluster)
				&& "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			finalresponse = "As of "+instaIssuanceBean.getIiTimeStamp()+" Insta-issuance "+instaType+" MTD for MLI is:"+
				"Insta-Isuance : NOP - <NOP%>, Adj MFYP - <Adj. MFYP%>"+
				"Insta 6hrs : NOP - <NOP%>, Adj MFYP - <Adj. MFYP%>"+
				"Insta 12hrs : NOP - <NOP%>, Adj MFYP - <Adj. MFYP%>"+
				"Insta 24hrs : NOP - <NOP%>, Adj MFYP - <Adj. MFYP%>";
				
		}
		else 
		{
			finalresponse = "As of "+instaIssuanceBean.getIiTimeStamp()+" Insta-issuance "+instaType+" MTD for "+hierarchylevel+" is:"+
					"Insta-Isuance : NOP - <NOP%>, Adj MFYP - <Adj. MFYP%>"+
					"Insta 6hrs : NOP - <NOP%>, Adj MFYP - <Adj. MFYP%>"+
					"Insta 12hrs : NOP - <NOP%>, Adj MFYP - <Adj. MFYP%>"+
					"Insta 24hrs : NOP - <NOP%>, Adj MFYP - <Adj. MFYP%>";
		}
		return finalresponse;
		
	}

}
