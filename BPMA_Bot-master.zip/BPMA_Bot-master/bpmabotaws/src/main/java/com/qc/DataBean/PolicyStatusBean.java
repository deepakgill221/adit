package com.qc.dataBean;


public class PolicyStatusBean 
{
	private String channel;
	private String subChannel;
	private String raAdmAgtId;
	private String policyNumber;
	private String policyStatusDesc;
	private String polDueDate;
	private String btchTimstamp;
	private String realTimTimstamp;
	private String workitemDescription;
	private String pendingRequirement;
	private String tppComment;
	
	
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSubChannel() {
		return subChannel;
	}
	public void setSubChannel(String subChannel) {
		this.subChannel = subChannel;
	}
	public String getRaAdmAgtId() {
		return raAdmAgtId;
	}
	public void setRaAdmAgtId(String raAdmAgtId) {
		this.raAdmAgtId = raAdmAgtId;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPolicyStatusDesc() {
		return policyStatusDesc;
	}
	public void setPolicyStatusDesc(String policyStatusDesc) {
		this.policyStatusDesc = policyStatusDesc;
	}
	public String getPolDueDate() {
		return polDueDate;
	}
	public void setPolDueDate(String polDueDate) {
		this.polDueDate = polDueDate;
	}
	public String getBtchTimstamp() {
		return btchTimstamp;
	}
	public void setBtchTimstamp(String btchTimstamp) {
		this.btchTimstamp = btchTimstamp;
	}
	public String getRealTimTimstamp() {
		return realTimTimstamp;
	}
	public void setRealTimTimstamp(String realTimTimstamp) {
		this.realTimTimstamp = realTimTimstamp;
	}
	public String getWorkitemDescription() {
		return workitemDescription;
	}
	public void setWorkitemDescription(String workitemDescription) {
		this.workitemDescription = workitemDescription;
	}
	public String getPendingRequirement() {
		return pendingRequirement;
	}
	public void setPendingRequirement(String pendingRequirement) {
		this.pendingRequirement = pendingRequirement;
	}
	public String getTppComment() {
		return tppComment;
	}
	public void setTppComment(String tppComment) {
		this.tppComment = tppComment;
	}
	
	
}
