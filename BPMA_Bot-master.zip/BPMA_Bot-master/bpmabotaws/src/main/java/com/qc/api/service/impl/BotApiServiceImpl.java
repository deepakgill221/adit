package com.qc.api.service.impl;
import java.net.HttpURLConnection;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/*import com.qc.api.dao.APIConsumerDao;*/
/*import com.qc.api.entity.WipEntity;*/
import com.qc.api.response.WebhookResponse;
import com.qc.api.service.APIConsumerService;
import com.qc.common.CallingJavaService;
import com.qc.common.CustomizeChannel;
import com.qc.common.Facebook;
import com.qc.common.InnerButton;
import com.qc.common.InnerData;
import com.qc.common.TimeStamp;
import com.qc.dataBean.HubHoldBean;
import com.qc.dataBean.InstaIssuanceBean;
import com.qc.dataBean.NTUBean;
import com.qc.dataBean.PolicyStatusBean;
import com.qc.dataBean.ProtectionBean;
import com.qc.jsonImpl.HubHold;
import com.qc.jsonImpl.InstaIssuanceJson;
import com.qc.jsonImpl.NTU;
import com.qc.jsonImpl.NatHybApplied;
import com.qc.jsonImpl.NatHybCaseSize;
import com.qc.jsonImpl.NatHybGrowth;
import com.qc.jsonImpl.NatHybInforced;
import com.qc.jsonImpl.NatHybModeMix;
import com.qc.jsonImpl.NatHybPenetration;
import com.qc.jsonImpl.NatHybWIP;
import com.qc.jsonImpl.PolicyStatus;
import com.qc.jsonImpl.Protection;
import com.qc.service.messageimpl.Achievement;
import com.qc.service.messageimpl.AdjMFYP;
import com.qc.service.messageimpl.Applied;
import com.qc.service.messageimpl.AppliedADJIFYP;
import com.qc.service.messageimpl.Appliedcases;
import com.qc.service.messageimpl.CaseSizePercentage;
import com.qc.service.messageimpl.Growth;
import com.qc.service.messageimpl.GrowthCaseSize;
import com.qc.service.messageimpl.GrowthLPCADJMFYP;
import com.qc.service.messageimpl.GrowthLPCAPLADJIFYP;
import com.qc.service.messageimpl.GrowthLPCAPLAFYP;
import com.qc.service.messageimpl.GrowthLPCAPLCases;
import com.qc.service.messageimpl.GrowthLPCPaidCases;
import com.qc.service.messageimpl.GrowthPaidcases;
import com.qc.service.messageimpl.GrowthRecruitment;
import com.qc.service.messageimpl.HubHoldCases;
import com.qc.service.messageimpl.InstaIssuance;
import com.qc.service.messageimpl.LpcAPPAdJIFYP;
import com.qc.service.messageimpl.LpcPAIDADJMFYP;
import com.qc.service.messageimpl.LpcPAIDCASES;
import com.qc.service.messageimpl.Lpcaplcases;
import com.qc.service.messageimpl.Lpcappadjafyp;
import com.qc.service.messageimpl.ModeMix;
import com.qc.service.messageimpl.NBAdjMFYP;
import com.qc.service.messageimpl.NBApplied;
import com.qc.service.messageimpl.NBCaseSize;
import com.qc.service.messageimpl.NBGROWTHAPLADGIFYP;
import com.qc.service.messageimpl.NBGROWTHAPLAFYP;
import com.qc.service.messageimpl.NBGROWTHAPLCASES;
import com.qc.service.messageimpl.NBGrowth;
import com.qc.service.messageimpl.NTUCases;
import com.qc.service.messageimpl.NbAchievement;
import com.qc.service.messageimpl.Numbers;
import com.qc.service.messageimpl.PaidCases;
import com.qc.service.messageimpl.Penetration;
import com.qc.service.messageimpl.PolicyStatusMessage;
import com.qc.service.messageimpl.ProductMix;
import com.qc.service.messageimpl.ProductMixADJMFYP;
import com.qc.service.messageimpl.ProductMixPaidCase;
import com.qc.service.messageimpl.ProtectionCases;
import com.qc.service.messageimpl.ProtectionYes;
import com.qc.service.messageimpl.Recruitment;
import com.qc.service.messageimpl.Recruitmentpercentage;
import com.qc.service.messageimpl.Renewal;
import com.qc.service.messageimpl.WIPYES;
import com.qc.utils.AprApiCall;


@Service
public class BotApiServiceImpl implements APIConsumerService
{
	@Autowired
	CustomizeChannel customizeChannel;
	@Autowired
	CallingJavaService callingJavaService;
	@Autowired
	TimeStamp timestamp;
	
	@Autowired
	AprApiCall aprApiCall;


	@Autowired
	InstaIssuance instaIssuance;

	
	private static Logger logger = LogManager.getLogger(BotApiServiceImpl.class);
	
	PolicyStatusBean policyStatusBean = new PolicyStatusBean();
	PolicyStatus policyStatus = new PolicyStatus();
	PolicyStatusMessage policyStatusMessage = new PolicyStatusMessage();
	NTU ntu = new NTU(); 
	HubHold hubHold = new HubHold();
	Protection protection = new Protection();
	InstaIssuanceJson instaIssuanceJson = new InstaIssuanceJson();
	InstaIssuanceBean instaIssuanceBean = new InstaIssuanceBean();
	boolean isAuthorizedKeymarket = true;
	public WebhookResponse getWipDataAll(String action, String channel, String period, String productType, String planType,
			String user_ssoid, String user_sub_channel, String user_designation_desc, 
			String userzone, String user_region, String user_circle, String user_clusters, String user_go, String user_cmo, 
			String user_amo, String kpiAsked, String sessionId, String source, String employeeIdentification, String policyNumber,
			String agentId, String emailId, String user_superzone, String user_keyMarket)
	{
		
		
		logger.info("Action             :-"+action +"\n "
				+"Channel            :-"+channel +"\n "
				+"Period             :-"+period +"\n "
				+"ProductType        :-"+productType +"\n "
				+"PlanType           :-"+planType +"\n "
				+"User_SSOID         :-"+user_ssoid +"\n "
				+"User_Sub_Channel   :-"+user_sub_channel +"\n "
				+"UserZone           :-"+userzone +"\n "
				+"User_Region        :-"+user_region +"\n "
				+"User_Circle        :-"+user_circle +"\n "
				+"User_Clusters      :-"+user_clusters +"\n "
				+"User_Go            :-"+user_go+"\n"
				+"User_Superzone	 :-"+user_superzone+"\n"
				+"User_keyMarket	 :-"+user_keyMarket);
		
		if(!channel.equalsIgnoreCase("Axis")&&!user_keyMarket.isEmpty()
				&&user_circle.isEmpty()&&user_clusters.isEmpty()) {
			isAuthorizedKeymarket = false;
		}else {
			isAuthorizedKeymarket = true;
		}
		
		
		NTUBean ntubean=null;
		HubHoldBean hubHoldBean = null;
		ProtectionBean protectionBean = null;
		List<InnerButton> innerbuttonlist = new ArrayList<InnerButton>();
		Facebook fb = new Facebook();
		InnerData innerData= new InnerData();
		String msgChannel="";
		String LacsCr="";
		String instaType = "";
		
		if("".equalsIgnoreCase(channel))
		{channel="MLI";}
		if("".equalsIgnoreCase(productType))
		{productType="Protection";}
		if("".equalsIgnoreCase(period))
		{period="MONTHLY";}
		try
		{
			String [] messageresult = customizeChannel.messageChannel(user_ssoid,user_circle, user_region, userzone, user_sub_channel, source, 
					channel,user_clusters, user_go, employeeIdentification,user_superzone,user_keyMarket).split("~");
			for(int i=0; i<messageresult.length; i++)
			{
				if(i==0)
				{
					LacsCr = messageresult[i];
				}
				else
				{
					msgChannel = messageresult[i];
				}
			}
		}
		catch(Exception ex)
		{
			logger.error("Exception Occoured in CustomizeChannel Class");
		}
		if("MLI".equalsIgnoreCase(channel)||"CAT".equalsIgnoreCase(channel))
		{
			channel=channel.toUpperCase();
		}
		else{
			channel=convertToCamelCase(channel);
		}
		String output = new String();
		String DevMode = "N";
		HttpURLConnection conn = null;
		String segment="", serviceChannel="";
		String result = null;
		String speech="", finalresponse="";
		try 
		{
			if("NUMBERS".equalsIgnoreCase(action))
			{
				if("".equalsIgnoreCase(channel) || "MLI".equalsIgnoreCase(channel) || "Axis".equalsIgnoreCase(channel))
				{
					if("MLI".equalsIgnoreCase(channel) ||  "".equalsIgnoreCase(channel))
					{
						segment = "paid,wip,applied";
						serviceChannel = "";
					}else
					{
						segment = "paid,wip,applied";
						serviceChannel = "Axis Bank";
					}
				}else
				{
					segment = "paid,wip,applied";
					serviceChannel = channel;
				}
			}
			else if("AdjMFYP".equalsIgnoreCase(action) || "NB.Paidcases".equalsIgnoreCase(action) 
					|| "NB.AdjMFYP".equalsIgnoreCase(action))
			{
				if("MLI".equalsIgnoreCase(channel) || "Axis".equalsIgnoreCase(channel) || "".equalsIgnoreCase(channel))
				{
					if("MLI".equalsIgnoreCase(channel) ||  "".equalsIgnoreCase(channel))
					{
						segment="paid";
						serviceChannel = "";
					}else
					{
						segment="paid";
						serviceChannel = "Axis Bank";
					}
				}else
				{
					segment="paid";
					serviceChannel = channel;
				}
			}
			else if("WIP".equalsIgnoreCase(action)||"WIP.YES".equalsIgnoreCase(action))
			{
				if("".equalsIgnoreCase(channel) || "Axis".equalsIgnoreCase(channel) || "MLI".equalsIgnoreCase(channel))
				{
					if("".equalsIgnoreCase(channel) || "MLI".equalsIgnoreCase(channel))
					{
						segment="wip";
						serviceChannel = "";
					}else
					{
						segment="wip";
						serviceChannel = "Axis Bank";
					}
				}else{
					segment="wip";
					serviceChannel = channel;
				}
			}
			else if("APPLIED".equalsIgnoreCase(action) || "NB.Applied".equalsIgnoreCase(action) ||"NB.AppliedAdjIFYP".equalsIgnoreCase(action)
					||"NB.AppliedCases".equalsIgnoreCase(action))
			{

				if("MLI".equalsIgnoreCase(channel) || "".equalsIgnoreCase(channel) || "Axis".equalsIgnoreCase(channel))
				{
					if("MLI".equalsIgnoreCase(channel) || "".equalsIgnoreCase(channel))
					{
						segment="applied";
						serviceChannel = "";
					}
					else
					{
						segment="applied";
						serviceChannel = "Axis Bank";
					}
				}else
				{
					segment="applied";
					serviceChannel = channel;
				}
			}

			else if("Penetration".equalsIgnoreCase(action) ||"NB.ProductMix".equalsIgnoreCase(action) 
					|| "NB.ProductMixADJMFYP".equalsIgnoreCase(action) || "NB.Productmixpaidcase".equalsIgnoreCase(action))
			{
				System.out.println("Action to be called before JavaService Call :"+action);
				if("MLI".equalsIgnoreCase(channel))
				{
					segment="penetration";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel))
					{
						segment="penetration";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="penetration";
						serviceChannel = channel;
					}
				}
			}
			else if("Achievement".equalsIgnoreCase(action) || "NB.casesize%".equalsIgnoreCase(action) ||"NB.Recruitment%".equalsIgnoreCase(action)
					||"NB.Achievement".equalsIgnoreCase(action))
			{
				if("MLI".equalsIgnoreCase(channel))
				{
					segment="achievement";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel))
					{
						segment="achievement";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="achievement";
						serviceChannel = channel;
					}
				}
			} 
			else if("Growth".equalsIgnoreCase(action) || "NB.Growth".equalsIgnoreCase(action) ||"NB.GROWTHAPLADJIFYP".equalsIgnoreCase(action)||"NB.GROWTHAPLAFYP".equalsIgnoreCase(action)
					||"NB.GROWTHAPLCASES".equalsIgnoreCase(action) ||"NB.GROWTHCASESIZE".equalsIgnoreCase(action)||"NB.GROWTHLPCADJMFYP".equalsIgnoreCase(action) 
					||"NB.GROWTHLPCAPLADJIFYP".equalsIgnoreCase(action)	||"NB.GROWTHLPCAPLAFYP".equalsIgnoreCase(action)||"NB.GROWTHLPCAPLCASES".equalsIgnoreCase(action)
					||"NB.GROWTHLPCPAIDCASES".equalsIgnoreCase(action)||"NB.GROWTHPAIDCASES".equalsIgnoreCase(action)||"NB.GROWTHRECRUITMENT".equalsIgnoreCase(action))
			{
				if("MLI".equalsIgnoreCase(channel))
				{
					segment="growth";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel))
					{
						segment="growth";
						serviceChannel="Axis Bank";
					}else
					{
						segment="growth";
						serviceChannel = channel;
					}
				}
			}
			else if("NB.casesize".equalsIgnoreCase(action))
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="CASE_SIZE";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="CASE_SIZE";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="CASE_SIZE";
						serviceChannel = channel;
					}
				}
			}
			else if("NB.LPCAPPADJIFYP".equalsIgnoreCase(action) || "NB.LPCAPPADJAFYP".equalsIgnoreCase(action) 
					|| "NB.LPCAPLCASES".equalsIgnoreCase(action) || "NB.LPCPAIDADJMFYP".equalsIgnoreCase(action)
					|| "NB.LPCPAIDCASES".equalsIgnoreCase(action))
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="LPC_PERFORMANCE";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="LPC_PERFORMANCE";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="LPC_PERFORMANCE";
						serviceChannel = channel;
					}
				}
			}
			else if("NB.Recruitment".equalsIgnoreCase(action)) 
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="REC";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="REC";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="REC";
						serviceChannel = channel;
					}
				}
			}
			else if("NB.MODEMIX".equalsIgnoreCase(action)) 
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="MODE_MIX";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="MODE_MIX";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="MODE_MIX";
						serviceChannel = channel;
					}
				}
			}
			else if("NB.HUBHOLD".equalsIgnoreCase(action)) 
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="HUB_HOLD";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="HUB_HOLD";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="HUB_HOLD";
						serviceChannel = channel;
					}
				}
			}
			else if("NB.RENEWAL".equalsIgnoreCase(action)) 
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="RENEWAL";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="RENEWAL";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="RENEWAL";
						serviceChannel = channel;
					}
				}
			}
			else if("NB.NTU".equalsIgnoreCase(action)) 
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="NTU";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="NTU";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="NTU";
						serviceChannel = channel;
					}
				}
			}
          else if("NB.Protection".equalsIgnoreCase(action) || "PROTECTION.YES".equalsIgnoreCase(action)
			      ||"NBRegion.NBRegion-yes".equalsIgnoreCase(action) ||"NBZONE.NBZONE-YES".equalsIgnoreCase(action)
			      ||"NBCLUSTER.NBCLUSTER-YES".equalsIgnoreCase(action)||"NBCIRCLE.NBCIRCLE-YES".equalsIgnoreCase(action)
			      ||"NBSUBCHANNEL.NBSUBCHANNEL-YES".equalsIgnoreCase(action)||"nbchannel.nbchannel-yes".equalsIgnoreCase(action)
			      ||"NBGO.NBGO-YES".equalsIgnoreCase(action)||"nbperiod.nbperiod-yes".equalsIgnoreCase(action)) 
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="PROTECTION";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="PROTECTION";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="PROTECTION";
						serviceChannel = channel;
					}
				}
			}
			
          else if("NB.POLICYSTATUS".equalsIgnoreCase(action) ) 
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="POLICYSTATUS";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="POLICYSTATUS";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="POLICYSTATUS";
						serviceChannel = channel;
					}
				}
			}
			if("NUMBERS".equalsIgnoreCase(action) && "Internet Sales".equalsIgnoreCase(channel) )
			{
				segment="NAT_HYB_APPLIED,NAT_HYB_WIP,NAT_HYB_INFORCED";
			}
			
			if("Penetration".equalsIgnoreCase(action) && "Internet Sales".equalsIgnoreCase(channel))
			{
				segment="NAT_HYB_PENETRATION";
			}
			if("WIP".equalsIgnoreCase(action) && "Internet Sales".equalsIgnoreCase(channel))
			{
				segment="WIP,NAT_HYB_WIP";
			}
			if(("APPLIED".equalsIgnoreCase(action) || "NB.AppliedAdjIFYP".equalsIgnoreCase(action)
					||"NB.AppliedCases".equalsIgnoreCase(action)) && "Internet Sales".equalsIgnoreCase(channel))
			{
				segment="NAT_HYB_APPLIED";
			}
			if("NB.casesize".equalsIgnoreCase(action) && "Internet Sales".equalsIgnoreCase(channel))
			{
				segment="NAT_HYB_CASE_SIZE";
			}
			else if("NB.MODEMIX".equalsIgnoreCase(action) && "Internet Sales".equalsIgnoreCase(channel)) 
			{
				segment="NAT_HYB_MODEMIX";
			}
			else if(("NB.PaidCases".equalsIgnoreCase(action) ||"AdjMFYP".equalsIgnoreCase(action)) && "Internet Sales".equalsIgnoreCase(channel))
			{
				segment="NAT_HYB_INFORCED";
			}
			else if("NB.INSTAISSUANCE".equalsIgnoreCase(action) || "NB.INSTAISSUANCEMED".equalsIgnoreCase(action))
			{
				if("MLI".equalsIgnoreCase(channel)){
					segment="INSTA_ISSUANCE";
					serviceChannel = "";
				}else
				{
					if("Axis".equalsIgnoreCase(channel)){
						segment="INSTA_ISSUANCE";
						serviceChannel = "Axis Bank";
					}else
					{
						segment="INSTA_ISSUANCE";
						serviceChannel = channel;
					}
				}
				
				if("NB.INSTAISSUANCE".equalsIgnoreCase(action))
				{
					instaType = "(Non Protection Non Med)";
				}
				else
				{
					instaType = "(Non Protection Non Med & Med)";
				}
			}
				
				
			try{ 
				if("West Bengal".equalsIgnoreCase(user_circle))
				{
					user_circle=user_circle.replaceAll("\\s","");
				}
				
				//The change is to merge the channels IM and IMF and showing their business collectively
				//Request Raised By: Bhavneet
				//Date: 14 Jun 2018
				if("IMF".equalsIgnoreCase(channel) || "IM Channel".equalsIgnoreCase(channel) || "IM".equalsIgnoreCase(channel))
				{
					serviceChannel="IMF";
					user_sub_channel="";
					userzone="";
					user_region="";
					user_circle="";
					user_clusters="";
					user_go="";
					user_cmo="";
					user_amo="";
					planType="";
					user_superzone="";
					user_keyMarket="";
				}
				logger.info("---------------------------For testing----------------------");
			
				logger.info("Segment            :-"+segment +"\n "
						+"Action             :-"+action +"\n "
						+"Period             :-"+period +"\n "
						+"Channel            :-"+serviceChannel +"\n "
						+"ProductType        :-"+productType +"\n "
						+"User_Sub_Channel   :-"+user_sub_channel +"\n "
						+"UserZone           :-"+userzone +"\n "
						+"User_Region        :-"+user_region +"\n "
						+"User_Circle        :-"+user_circle +"\n "
						+"User_Clusters      :-"+user_clusters +"\n "
						+"User_Go            :-"+user_go +"\n "
						+"User_SSOID         :-"+user_ssoid);
				/*---------------------------For testing----------------------*/
				
				if(serviceChannel.equalsIgnoreCase("Agency")&&
						user_sub_channel.equalsIgnoreCase("Agency")) {
					user_sub_channel = "";
				}
				logger.info("Going to call java web service-----Start");
				result = callingJavaService.callService(action, segment, serviceChannel, user_sub_channel, 
						userzone, user_region, user_circle, user_clusters, user_go, user_cmo, user_amo, planType, policyNumber, user_superzone, user_keyMarket);

				logger.info("Calling java web service-----end");
			}
			catch(Exception ex)
			{
				logger.error("Exception Occourd While calling java Service");
				finalresponse="Exception Occourd While calling java Service";
			}
			try
			{
				DecimalFormat df = new DecimalFormat("####0.00");
				DecimalFormat df1 = new DecimalFormat("####");
				JSONObject object = new JSONObject(result.toString());
				double dailyAdjustMFYP1=0; 	double mtdAdjustMFYP1=0;    double dailyAppliedAFYP1=0;
				double mtdAppliedAFYP1=0;	double wipAFYP=0;           double hoWIPAFYP=0;
				double goWIPAFYP=0; 		double itWIPAFYP=0;	    double finWIPAFYP=0;
				double miscWIPAFYP=0;		double welcomeWIPAFYP=0;    double wip_count=0;
				double ho_wip_count=0;		double go_wip_count=0;	    double it_wip_count=0;
				double fin_wip_count=0;		double misc_wip_count=0;    double welcome_wip_count=0;
				double ytd_inforced_afyp1=0;double ytd_applied_afyp1=0; double mtd_inforced_afyp1=0;
				double ytd_adj_mfyp1=0; double daily_inforced_count_aaplied=0; double mtd_adj_mfyp1=0;
				double daily_adj_mfyp1=0; double daily_applied_count1=0;
				double ytd_applied_adj_ifyp1=0, mtd_applied_adj_ifyp1=0, mtd_applied_count1=0, ytd_applied_count1=0,
				       mtd_inforced_count1=0,ytd_inforced_count1=0;
				String daily_inforced_count1="";
				double sum = 0; double sum2=0; double sum3 = 0; double sum4 = 0;
				/*-------------------------------------------New Valiable added on 15-02-2018-------------------------------------------------------*/
				double ho_wip_adj_mfyp=0, go_wip_adj_mfyp=0, it_wip_adj_mfyp=0, 
						fin_wip_adj_mfyp=0, misc_wip_adj_mfyp=0, welcome_wip_adj_mfyp=0;
			        /*-------------------------------------------New Valiable added on 15-02-2018-------------------------------------------------------*/
				String 	ul_penet_mtd_afyp="";	String 	ul_penet_ytd_afyp="";  String 	ul_penet_mtd_pol_cnt="";   String ul_penet_ytd_pol_cnt="";
				String 	ul_mtd_afyp="";	String 	ul_ytd_afyp="";	String 	ul_mtd_pol_cnt="";	String 	ul_ytd_pol_cnt="";	String 	trad_penet_mtd_afyp="";
				String 	trad_penet_ytd_afyp="";    String trad_penet_mtd_pol_cnt="";	String trad_penet_ytd_pol_cnt=""; String trad_mtd_afyp="";
				String 	trad_ytd_afyp="";   String trad_mtd_pol_cnt="";	String 	trad_ytd_pol_cnt=""; String	protec_penet_mtd_afyp="";
				String 	protec_penet_ytd_afyp="";	String 	protec_penet_mtd_pol_cnt="";	String 	protec_penet_ytd_pol_cnt="";
				String 	protec_mtd_afyp="";	String 	protec_ytd_afyp=""; String	protec_mtd_pol_cnt="";	String 	protec_ytd_pol_cnt="";
				String mtd_inforced_afyp=""; String mtd_inforced_count=""; String ytd_inforced_afyp=""; String	ytd_inforced_count="";
				String grth_paid_adj_mfyp=""; String adj_mfyp_lst_mn=""; String mtd_inforced_adj_mfyp=""; String grth_ovr_lst_yr_paid="";
				String adj_mfyp_sam_ytd_lst_yr=""; String ytd_inforced_adj_mfyp=""; String achiev_mtd_adj_mfyp=""; String pln_mtd_basis_adj_mfyp="";
				String achiev_ytd_adj_mfyp=""; String pln_ytd_basis_adj_mfyp=""; String mtd_inforced_adj_mfyp_achi="";
				String ytd_inforced_adj_mfyp_achi=""; String real_tim_timstamp="";
				String case_size_afyp_mtd="", case_size_afyp_ytd="", lpc_applied_adj_ifyp_mtd="", lpc_applied_adj_ifyp_ytd="", lpc_applied_afyp_mtd="",
				       		lpc_applied_afyp_ytd="", lpc_applied_cases_mtd="", lpc_applied_cases_ytd="", lpc_paid_adj_mfyp_mtd="", lpc_paid_adj_mfyp_ytd="",
						lpc_paid_cases_mtd="", lpc_paid_cases_ytd="", achiev_mtd_case_active_mtd="", achiev_mtd_case_active_ytd="",
						grth_lst_yr_sm_adj_mfyp_mtd="", grth_lst_yr_sm_adj_mfyp_ytd="", prev_year_adj_mfyp_ytd="", prev_year_adj_mfyp_mtd="",
						recruitment_mtd="",recruitment_ytd="", achiev_ytd_recruitment="", achiev_mtd_recruitment="",grth_applied_adj_ifyp_ytd="",
						rpev_applied_adj_ifyp_ytd="",applied_adj_ifyp_ytd="", grth_applied_adj_ifyp_mtd="", rpev_applied_adj_ifyp_mtd="", applied_adj_ifyp_mtd="",
						grth_applied_afyp_ytd="",prev_applied_afyp_ytd="",applied_afyp_ytd="",grth_applied_afyp_mtd="",prev_applied_afyp_mtd="",
						applied_afyp_mtd="", grth_applied_cases_ytd="", prev_applied_cases_ytd="", applied_cases_ytd="", grth_applied_cases_mtd="",
						prev_applied_cases_mtd="", applied_cases_mtd="", grth_case_size_afyp_ytd="",prev_case_size_afyp_ytd="",case_size_afyp_ytd_growth="",
						grth_case_size_afyp_mtd="",prev_case_size_afyp_mtd="",case_size_afyp_mtd_growth="", grth_lpc_paid_adj_mfyp_ytd="",prev_lpc_paid_adj_mfyp_ytd="",
						lpc_paid_adj_mfyp_ytd_growth="",grth_lpc_paid_adj_mfyp_mtd="",prev_lpc_paid_adj_mfyp_mtd="",lpc_paid_adj_mfyp_mtd_growth="",
						grth_lpc_applied_adj_ifyp_ytd="",prev_lpc_applied_adj_ifyp_ytd="",lpc_applied_adj_ifyp_ytd_growth="",grth_lpc_applied_adj_ifyp_mtd="",
						prev_lpc_applied_adj_ifyp_mtd="",lpc_applied_adj_ifyp_mtd_growth="", grth_lpc_applied_afyp_ytd="",prev_lpc_applied_afyp_ytd="",curr_lpc_applied_afyp_ytd="",grth_lpc_applied_afyp_mtd="",
						prev_lpc_applied_afyp_mtd="",curr_lpc_applied_afyp_mtd="", grth_lpc_applied_cases_ytd="",prev_lpc_applied_cases_ytd="",lpc_applied_cases_ytd_growth="",grth_lpc_applied_cases_mtd="",
						prev_lpc_applied_cases_mtd="",lpc_applied_cases_mtd_growth="", grth_lpc_paid_cases_ytd="",prev_lpc_paid_cases_ytd="",lpc_paid_cases_ytd_growth="",grth_lpc_paid_cases_mtd="",
						prev_lpc_paid_cases_mtd="",lpc_paid_cases_mtd_growth="", grth_lst_yr_inforced_cnt_ytd="",prev_year_inforced_cnt_ytd="",ytd_inforced_cnt="",grth_lst_yr_inforced_cnt_mtd="",
						prev_year_inforced_cnt_mtd="",mtd_inforced_cnt="", grth_recruitment_ytd="",prev_recruitment_ytd="",recruitment_ytd_growth="",grth_recruitment_mtd="",
						prev_recruitment_mtd="",recruitment_mtd_growth="",ytd_adj_mfyp_pln="",mtd_adj_mfyp_pln="",
						mtd_adj_mfyp_act="", ytd_adj_mfyp_act="",achiev_mtd_paid_case="",mtd_afyp_act="",ytd_afyp_act="", mtd_afyp_pln="",ytd_afyp_pln="", mtd_adj_afyp_act="", mtd_adj_afyp_pln="",	mtd_paid_case_act="", mtd_paid_case_pln="", achiev_ytd_paid_case="",
						ytd_paid_case_act="", ytd_paid_case_pln="",	ul_penet_mtd_adj_mfyp="", par_penet_mtd_adj_mfyp="", nonpar_penet_mtd_adj_mfyp="", protec_penet_mtd_adj_mfyp="", par_penet_mtd_pol_cnt="",
						nonpar_penet_mtd_pol_cnt="", ul_penet_ytd_adj_mfyp="",	par_penet_ytd_adj_mfyp="",	nonpar_penet_ytd_adj_mfyp="",protec_penet_ytd_adj_mfyp="",par_penet_ytd_pol_cnt="",	
						nonpar_penet_ytd_pol_cnt="";
				String  mtdAdjustMFYP="", dailyAppliedAFYP="", mtdAppliedAFYP="", ytd_applied_afyp="", mtd_adj_mfyp="",
						daily_adj_mfyp="", ytd_applied_adj_ifyp="", mtd_applied_adj_ifyp="",mtd_applied_count="",
						ytd_applied_count="", daily_applied_count="", daily_inforced_count="", dailyAdjustMFYP="", ytd_adj_mfyp="";
				/*-------------------------------------------New Valiable added on 15-02-2018-------------------------------------------------------*/
				String daily_inforced_afyp2="", daily_inforced_count2="", daily_adj_mfyp2=""; 
	   			String daily_applied_afyp2="",daily_applied_count2="",daily_applied_adj_ifyp2="";
			   /*-------------------------------------------New Valiable added on 15-02-2018-------------------------------------------------------*/
				//				        --------------------ModeMix----------------------------------------------
				String annual_adj_mfyp_mtd="", semi_annual_adj_mfyp_mtd="", quarterly_adj_mfyp_mtd="", monthly_adj_mfyp_mtd="",single_adj_mfyp_mtd="",annual_adj_mfyp_ytd="",semi_annual_adj_mfyp_ytd="",
						quarterly_adj_mfyp_ytd="", monthly_adj_mfyp_ytd="", single_adj_mfyp_ytd="";
				String achiev_mtd_case_size="", achiev_ytd_case_size="";
				String daily_applied_adj_ifyp="";
				//--------------------Vairable Assignment END--------------------------------------------------------------------------------------------------------------------------------
				/*---------------------------------------------HUBHOLD----------------------------------------------------------------------------------*/
				String mtd_hub_hold_cases="",  ytd_hub_hold_cases="", daily_hub_hold_cases="",  mtd_hub_hold_adj_mfyp="", ytd_hub_hold_adj_mfyp="", 
						daily_hub_hold_adj_mfyp="", total_hub_hold_cases="",  total_hub_hold_adj_mfyp="",  btch_timstamp="";
				/*---------------------------------------------HUBHOLD----------------------------------------------------------------------------------*/

				real_tim_timstamp=timestamp.getTimeStamp(object);

				String [] regex = segment.split(",");
				for(int i=0; i<regex.length; i++)
				{
					String split= regex[i];
					String splitIntent=split.toUpperCase();
					switch(splitIntent)
					{
					case "PAID":
					{
						try	{
							dailyAdjustMFYP1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("paid").get("daily_adj_mfyp").toString());
						}
						catch(Exception ex)	{}
						dailyAdjustMFYP =df.format(dailyAdjustMFYP1);
						try	{
							mtd_inforced_afyp1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("paid").get("mtd_inforced_afyp").toString());
						}
						catch(Exception ex)	{}
						String mtd_inforced_afyp_enforce =df.format(mtd_inforced_afyp1);
						try
						{
							mtdAdjustMFYP1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("paid").get("mtd_adj_mfyp").toString());
						}catch(Exception ex){}
						mtdAdjustMFYP = df.format(mtdAdjustMFYP1);
						try
						{
							ytd_inforced_afyp1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("paid").get("ytd_inforced_afyp").toString());
						}catch(Exception ex){}
						try
						{
							double daily_inforced_count11 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("paid").get("daily_inforced_count").toString());
							daily_inforced_count1=df1.format(daily_inforced_count11);
						}catch(Exception ex){}
						try
						{
							mtd_inforced_count = (object.getJSONObject("payload").getJSONObject("paid").get("mtd_inforced_count").toString());
						}catch(Exception ex){}
						try
						{
							ytd_inforced_count = (object.getJSONObject("payload").getJSONObject("paid").get("ytd_inforced_count").toString());
						}catch(Exception ex){}
						try{
							ytd_adj_mfyp1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("paid").get("ytd_adj_mfyp").toString());
							ytd_adj_mfyp = df.format(ytd_adj_mfyp1);
						}catch(Exception ex){}
						/*-----------------------------------For FTD NEW CHANGES-------------------------------------------------------------------------*/
						try
						{
							daily_inforced_count2 = object.getJSONObject("payload").getJSONObject("paid").get("daily_inforced_count2").toString();
						}catch(Exception ex){}
						try
						{
							daily_inforced_afyp2=object.getJSONObject("payload").getJSONObject("paid").get("daily_inforced_afyp2").toString();
						}catch(Exception ex){}
						try
						{
							daily_adj_mfyp2 = object.getJSONObject("payload").getJSONObject("paid").get("daily_adj_mfyp2").toString();
						}catch(Exception ex){}
						/*-----------------------------------For FTD NEW CHANGES-------------------------------------------------------------------------*/
					}
					break;
					case "APPLIED":
					{
						try{
							dailyAppliedAFYP1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("applied").get("daily_applied_afyp").toString());
						}catch(Exception e){}
						dailyAppliedAFYP = df.format(dailyAppliedAFYP1);
						try{
							mtdAppliedAFYP1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("applied").get("mtd_applied_afyp").toString());
						}catch(Exception e){}
						mtdAppliedAFYP = df.format(mtdAppliedAFYP1);
						try{
							ytd_applied_afyp1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("applied").get("ytd_applied_afyp").toString());
						}catch(Exception e){}
						ytd_applied_afyp = df.format(ytd_applied_afyp1);
						try{
							mtd_adj_mfyp1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("applied").get("mtd_adj_mfyp").toString());
						}catch(Exception e){}
						mtd_adj_mfyp = df.format(mtd_adj_mfyp1);
						try{
							daily_adj_mfyp1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("applied").get("daily_adj_mfyp").toString());
						}catch(Exception e){}
						daily_adj_mfyp = df.format(daily_adj_mfyp1);
						try{
							ytd_applied_adj_ifyp1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("applied").get("ytd_applied_adj_ifyp").toString());
						}catch(Exception e){}
						ytd_applied_adj_ifyp = df.format(ytd_applied_adj_ifyp1);
						try{
							mtd_applied_adj_ifyp1 = Double.parseDouble(object.getJSONObject("payload").getJSONObject("applied").get("mtd_applied_adj_ifyp").toString());
						}catch(Exception e){}
						mtd_applied_adj_ifyp = df.format(mtd_applied_adj_ifyp1);
						try{
							mtd_applied_count = (object.getJSONObject("payload").getJSONObject("applied").get("mtd_applied_count").toString());
						}catch(Exception e){}
						try{
							ytd_applied_count = (object.getJSONObject("payload").getJSONObject("applied").get("ytd_applied_count").toString());
						}catch(Exception e){}
						try{
							daily_applied_count = (object.getJSONObject("payload").getJSONObject("applied").get("daily_applied_count").toString());
						}catch(Exception e){}
						try{
							daily_inforced_count = (object.getJSONObject("payload").getJSONObject("applied").get("daily_inforced_count").toString());
						}catch(Exception e){}
						try{
							daily_applied_adj_ifyp = (object.getJSONObject("payload").getJSONObject("applied").get("daily_applied_adj_ifyp").toString());
						}catch(Exception e){}
						/*---------------------------------------NEW COLUMN ADDED FOR FTD---------------------------------------------------------------------*/
						try{
							daily_applied_afyp2 = (object.getJSONObject("payload").getJSONObject("applied").get("daily_applied_afyp2").toString());
						}catch(Exception e){}
						try{
							daily_applied_count2 = (object.getJSONObject("payload").getJSONObject("applied").get("daily_applied_count2").toString());
						}catch(Exception e){}
						try{
							daily_applied_adj_ifyp2 = (object.getJSONObject("payload").getJSONObject("applied").get("daily_applied_adj_ifyp2").toString());
						}catch(Exception e){}
						/*---------------------------------------NEW COLUMN ADDED FOR FTD---------------------------------------------------------------------*/
					}
					break;
					case "WIP":
					{
						
						try{
							wipAFYP = Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("wip_afyp").toString());
						}catch(Exception e){}
						try{
							hoWIPAFYP =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("ho_wip_afyp").toString());
						}catch(Exception e){}
						try{
							goWIPAFYP =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("go_wip_afyp").toString());
						}catch(Exception e){}
						try{
							itWIPAFYP =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("it_wip_afyp").toString());
						}catch(Exception e){}
						try{
							finWIPAFYP =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("fin_wip_afyp").toString());
						}catch(Exception e){}
						try{
							miscWIPAFYP =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("misc_wip_afyp").toString());
						}catch(Exception e){}
						try{
							welcomeWIPAFYP =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("welcome_wip_afyp").toString());
						}catch(Exception e){}
						try{
							wip_count = Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("wip_count").toString());
						}catch(Exception e){}
						try{
							ho_wip_count = Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("ho_wip_count").toString());
						}catch(Exception e){}
						try{
							go_wip_count = Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("go_wip_count").toString());
						}catch(Exception e){}
						try{
							it_wip_count = Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("it_wip_count").toString());
						}catch(Exception e){}
						try{
							fin_wip_count = Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("fin_wip_count").toString());
						}catch(Exception e){}
						try{
							misc_wip_count = Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("misc_wip_count").toString());
						}catch(Exception e){}
						try{
							welcome_wip_count = Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("welcome_wip_count").toString());
						}catch(Exception e){}
						/*----------------------------------------------------New Change 15-02-2018--------by Manish Negi-------------------------------------------*/
						try{
							ho_wip_adj_mfyp =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("ho_wip_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							go_wip_adj_mfyp =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("go_wip_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							it_wip_adj_mfyp =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("it_wip_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							fin_wip_adj_mfyp =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("fin_wip_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							misc_wip_adj_mfyp =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("misc_wip_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							welcome_wip_adj_mfyp =Double.parseDouble(object.getJSONObject("payload").getJSONObject("wip").get("welcome_wip_adj_mfyp").toString());
						}catch(Exception e){}
						/*-----------------------------------------------------------------------------------------------------------------------------*/
					}
					break;
					case "PENETRATION":
					{
						try{
							mtd_inforced_afyp	 = (object.getJSONObject("payload").getJSONObject("penetration").get("mtd_inforced_afyp").toString());
						}catch(Exception e){}
						try{
							mtd_inforced_count = (object.getJSONObject("payload").getJSONObject("penetration").get("mtd_inforced_count").toString());
						}catch(Exception e){}
						try{
							ytd_inforced_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("ytd_inforced_afyp").toString());
						}catch(Exception e){}
						try{
							ytd_inforced_count = (object.getJSONObject("payload").getJSONObject("penetration").get("ytd_inforced_count").toString());
						}catch(Exception e){}
						try{
							ul_penet_mtd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("ul_penet_mtd_afyp").toString());
						}catch(Exception e){}
						try{
							ul_penet_ytd_afyp =(object.getJSONObject("payload").getJSONObject("penetration").get("ul_penet_ytd_afyp").toString());
						}catch(Exception e){}
						try{
							ul_penet_mtd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("ul_penet_mtd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							ul_penet_ytd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("ul_penet_ytd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							ul_mtd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("ul_mtd_afyp").toString());
						}catch(Exception e){}
						try{
							ul_ytd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("ul_ytd_afyp").toString());
						}catch(Exception e){}
						try{
							ul_mtd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("ul_mtd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							ul_ytd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("ul_ytd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							trad_penet_mtd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("trad_penet_mtd_afyp").toString());
						}catch(Exception e){}
						try{
							trad_penet_ytd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("trad_penet_ytd_afyp").toString());
						}catch(Exception e){}
						try{
							trad_penet_mtd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("trad_penet_mtd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							trad_penet_ytd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("trad_penet_ytd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							trad_mtd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("trad_mtd_afyp").toString());
						}catch(Exception e){}
						try{
							trad_ytd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("trad_ytd_afyp").toString());
						}catch(Exception e){}
						try{
							trad_mtd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("trad_mtd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							trad_ytd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("trad_ytd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							protec_penet_mtd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_penet_mtd_afyp").toString());
						}catch(Exception e){}
						try{
							protec_penet_ytd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_penet_ytd_afyp").toString());
						}catch(Exception e){}
						try{
							protec_penet_mtd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_penet_mtd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							protec_penet_ytd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_penet_ytd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							protec_mtd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_mtd_afyp").toString());
						}catch(Exception e){}
						try{
							protec_ytd_afyp = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_ytd_afyp").toString());
						}catch(Exception e){}
						try{
							protec_mtd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_mtd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							protec_ytd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_ytd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							ul_penet_mtd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("penetration").get("ul_penet_mtd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							par_penet_mtd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("penetration").get("par_penet_mtd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							nonpar_penet_mtd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("penetration").get("nonpar_penet_mtd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							protec_penet_mtd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_penet_mtd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							par_penet_mtd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("par_penet_mtd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							nonpar_penet_mtd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("nonpar_penet_mtd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							ul_penet_ytd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("penetration").get("ul_penet_ytd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							par_penet_ytd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("penetration").get("par_penet_ytd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							nonpar_penet_ytd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("penetration").get("nonpar_penet_ytd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							protec_penet_ytd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("penetration").get("protec_penet_ytd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							par_penet_ytd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("par_penet_ytd_pol_cnt").toString());
						}catch(Exception e){}
						try{
							nonpar_penet_ytd_pol_cnt = (object.getJSONObject("payload").getJSONObject("penetration").get("nonpar_penet_ytd_pol_cnt").toString());
						}catch(Exception e){}
					}
					break;
					case "GROWTH":
					{
						try{
							applied_adj_ifyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("applied_adj_ifyp_mtd").toString());
						}catch(Exception e){}
						try{
							grth_paid_adj_mfyp = (object.getJSONObject("payload").getJSONObject("growth").get("grth_paid_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							adj_mfyp_lst_mn = (object.getJSONObject("payload").getJSONObject("growth").get("adj_mfyp_lst_mn").toString());
						}catch(Exception e){}
						try{
							mtd_inforced_adj_mfyp = (object.getJSONObject("payload").getJSONObject("growth").get("mtd_inforced_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							grth_lpc_applied_afyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_applied_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_applied_afyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_applied_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							curr_lpc_applied_afyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("curr_lpc_applied_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							grth_lpc_applied_afyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_applied_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_applied_afyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_applied_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							curr_lpc_applied_afyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("curr_lpc_applied_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							grth_lpc_applied_adj_ifyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_applied_adj_ifyp_ytd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_applied_adj_ifyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_applied_adj_ifyp_ytd").toString());
						}catch(Exception e){}
						try{
							lpc_applied_adj_ifyp_ytd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("lpc_applied_adj_ifyp_ytd").toString());
						}catch(Exception e){}
						try{
							grth_lpc_applied_adj_ifyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_applied_adj_ifyp_mtd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_applied_adj_ifyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_applied_adj_ifyp_mtd").toString());
						}catch(Exception e){}
						try{
							lpc_applied_adj_ifyp_mtd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("lpc_applied_adj_ifyp_mtd").toString());
						}catch(Exception e){}
						try{
							grth_case_size_afyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_case_size_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							prev_case_size_afyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_case_size_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							case_size_afyp_ytd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("case_size_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							grth_case_size_afyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_case_size_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							prev_case_size_afyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_case_size_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							case_size_afyp_mtd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("case_size_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							grth_ovr_lst_yr_paid = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lst_yr_sm_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							grth_recruitment_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_recruitment_ytd").toString());
						}catch(Exception e){}
						try{
							prev_recruitment_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_recruitment_ytd").toString());
						}catch(Exception e){}
						try{
							recruitment_ytd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("recruitment_ytd").toString());
						}catch(Exception e){}
						try{
							grth_recruitment_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_recruitment_mtd").toString());
						}catch(Exception e){}
						try{
							prev_recruitment_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_recruitment_mtd").toString());
						}catch(Exception e){}
						try{
							recruitment_mtd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("recruitment_mtd").toString());
						}catch(Exception e){}
						try{
							grth_lst_yr_inforced_cnt_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lst_yr_inforced_cnt_ytd").toString());
						}catch(Exception e){}
						try{
							prev_year_inforced_cnt_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_year_inforced_cnt_ytd").toString());
						}catch(Exception e){}
						try{
							ytd_inforced_cnt = (object.getJSONObject("payload").getJSONObject("growth").get("ytd_inforced_cnt").toString());
						}catch(Exception e){}
						try{
							grth_lst_yr_inforced_cnt_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lst_yr_inforced_cnt_mtd").toString());
						}catch(Exception e){}
						try{
							prev_year_inforced_cnt_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_year_inforced_cnt_mtd").toString());
						}catch(Exception e){}
						try{
							mtd_inforced_cnt = (object.getJSONObject("payload").getJSONObject("growth").get("mtd_inforced_cnt").toString());
						}catch(Exception e){}
						try{
							grth_lpc_paid_cases_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_paid_cases_ytd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_paid_cases_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_paid_cases_ytd").toString());
						}catch(Exception e){}
						try{
							lpc_paid_cases_ytd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("lpc_paid_cases_ytd").toString());
						}catch(Exception e){}
						try{
							grth_lpc_paid_cases_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_paid_cases_mtd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_paid_cases_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_paid_cases_mtd").toString());
						}catch(Exception e){}
						try{
							lpc_paid_cases_mtd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("lpc_paid_cases_mtd").toString());
						}catch(Exception e){}
						try{
							grth_lpc_applied_cases_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_applied_cases_ytd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_applied_cases_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_applied_cases_ytd").toString());
						}catch(Exception e){}
						try{
							lpc_applied_cases_ytd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("lpc_applied_cases_ytd").toString());
						}catch(Exception e){}
						try{
							grth_lpc_applied_cases_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_applied_cases_mtd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_applied_cases_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_applied_cases_mtd").toString());
						}catch(Exception e){}
						try{
							lpc_applied_cases_mtd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("lpc_applied_cases_mtd").toString());
						}catch(Exception e){}
						try{
							grth_lst_yr_sm_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lst_yr_sm_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							grth_lst_yr_sm_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lst_yr_sm_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							prev_year_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_year_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							prev_year_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_year_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							grth_applied_adj_ifyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_applied_adj_ifyp_ytd").toString());
						}catch(Exception e){}
						try{
							rpev_applied_adj_ifyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("rpev_applied_adj_ifyp_ytd").toString());
						}catch(Exception e){}
						try{
							applied_adj_ifyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("applied_adj_ifyp_ytd").toString());
						}catch(Exception e){}
						try{
							grth_applied_adj_ifyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_applied_adj_ifyp_mtd").toString());
						}catch(Exception e){}
						try{
							rpev_applied_adj_ifyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("rpev_applied_adj_ifyp_mtd").toString());
						}catch(Exception e){}
						try{
							grth_applied_afyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_applied_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							prev_applied_afyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_applied_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							applied_afyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("applied_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							grth_applied_afyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_applied_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							prev_applied_afyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_applied_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							applied_afyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("applied_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							grth_applied_cases_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_applied_cases_ytd").toString());
						}catch(Exception e){}
						try{
							prev_applied_cases_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_applied_cases_ytd").toString());
						}catch(Exception e){}
						try{
							applied_cases_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("applied_cases_ytd").toString());
						}catch(Exception e){}
						try{
							grth_applied_cases_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_applied_cases_mtd").toString());
						}catch(Exception e){}
						try{
							prev_applied_cases_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_applied_cases_mtd").toString());
						}catch(Exception e){}
						try{
							applied_cases_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("applied_cases_mtd").toString());
						}catch(Exception e){}
						try{
							grth_lpc_paid_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_paid_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_paid_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_paid_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							lpc_paid_adj_mfyp_ytd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("lpc_paid_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							grth_lpc_paid_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("grth_lpc_paid_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							prev_lpc_paid_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("growth").get("prev_lpc_paid_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							lpc_paid_adj_mfyp_mtd_growth = (object.getJSONObject("payload").getJSONObject("growth").get("lpc_paid_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							adj_mfyp_sam_ytd_lst_yr = (object.getJSONObject("payload").getJSONObject("growth").get("prev_year_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							ytd_inforced_adj_mfyp = (object.getJSONObject("payload").getJSONObject("growth").get("ytd_inforced_adj_mfyp").toString());
						}catch(Exception e){}
					}
					break;
					case "ACHIEVEMENT":
					{
						try{
							mtd_adj_mfyp_act = (object.getJSONObject("payload").getJSONObject("achievement").get("mtd_adj_mfyp_act").toString());
						}catch(Exception e){}
						try{
							ytd_adj_mfyp_act = (object.getJSONObject("payload").getJSONObject("achievement").get("ytd_adj_mfyp_act").toString());
						}catch(Exception e){}
						try{
							achiev_mtd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_mtd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							pln_mtd_basis_adj_mfyp = (object.getJSONObject("payload").getJSONObject("achievement").get("pln_mtd_basis_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							achiev_ytd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_ytd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							pln_ytd_basis_adj_mfyp = (object.getJSONObject("payload").getJSONObject("achievement").get("pln_ytd_basis_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							mtd_inforced_adj_mfyp_achi = (object.getJSONObject("payload").getJSONObject("achievement").get("mtd_inforced_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							ytd_inforced_adj_mfyp_achi = (object.getJSONObject("payload").getJSONObject("achievement").get("ytd_inforced_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							mtd_afyp_act = (object.getJSONObject("payload").getJSONObject("achievement").get("mtd_afyp_act").toString());
						}catch(Exception e){}
						try{
							ytd_afyp_act = (object.getJSONObject("payload").getJSONObject("achievement").get("ytd_afyp_act").toString());
						}catch(Exception e){}
						try{
							mtd_afyp_pln = (object.getJSONObject("payload").getJSONObject("achievement").get("mtd_afyp_pln").toString());
						}catch(Exception e){}
						try{
							ytd_afyp_pln = (object.getJSONObject("payload").getJSONObject("achievement").get("ytd_afyp_pln").toString());
						}catch(Exception e){}
						try{
							achiev_mtd_case_active_mtd = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_mtd_case_active_mtd").toString());
						}catch(Exception e){}
						try{
							achiev_mtd_case_active_ytd = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_mtd_case_active_ytd").toString());
						}catch(Exception e){}
						try{
							achiev_mtd_recruitment = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_mtd_recruitment").toString());
						}catch(Exception e){}
						try{
							achiev_ytd_recruitment = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_ytd_recruitment").toString());
						}catch(Exception e){}
						try{
							achiev_mtd_paid_case = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_mtd_paid_case").toString());
						}catch(Exception e){}
						try{
							mtd_adj_afyp_act = (object.getJSONObject("payload").getJSONObject("achievement").get("mtd_adj_afyp_act").toString());
						}catch(Exception e){}
						try{
							mtd_adj_afyp_pln = (object.getJSONObject("payload").getJSONObject("achievement").get("mtd_adj_afyp_pln").toString());
						}catch(Exception e){}
						try{
							mtd_paid_case_act = (object.getJSONObject("payload").getJSONObject("achievement").get("mtd_paid_case_act").toString());
						}catch(Exception e){}
						try{
							mtd_paid_case_pln = (object.getJSONObject("payload").getJSONObject("achievement").get("mtd_paid_case_pln").toString());
						}catch(Exception e){}
						try{
							achiev_ytd_paid_case = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_ytd_paid_case").toString());
						}catch(Exception e){}
						try{
							ytd_adj_mfyp_act = (object.getJSONObject("payload").getJSONObject("achievement").get("ytd_adj_mfyp_act").toString());
						}catch(Exception e){}
						try{
							ytd_adj_mfyp_pln = (object.getJSONObject("payload").getJSONObject("achievement").get("ytd_adj_mfyp_pln").toString());
						}catch(Exception e){}
						try{
							mtd_adj_mfyp_pln = (object.getJSONObject("payload").getJSONObject("achievement").get("mtd_adj_mfyp_pln").toString());
						}catch(Exception e){}
						try{
							ytd_paid_case_act = (object.getJSONObject("payload").getJSONObject("achievement").get("ytd_paid_case_act").toString());
						}catch(Exception e){}
						try{
							ytd_paid_case_pln = (object.getJSONObject("payload").getJSONObject("achievement").get("ytd_paid_case_pln").toString());
						}catch(Exception e){}
						try{
							achiev_mtd_case_size = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_mtd_case_size").toString());
						}catch(Exception e){}
						try{
							achiev_ytd_case_size = (object.getJSONObject("payload").getJSONObject("achievement").get("achiev_ytd_case_size").toString());
						}catch(Exception e){}
					}
					break;
					case "CASE_SIZE":
					{
						try{
							case_size_afyp_mtd = (object.getJSONObject("payload").getJSONObject("casesize").get("case_size_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							case_size_afyp_ytd = (object.getJSONObject("payload").getJSONObject("casesize").get("case_size_afyp_ytd").toString());
						}catch(Exception e){}
					}
					break;
					case "LPC_PERFORMANCE":
					{
						try{
							lpc_applied_adj_ifyp_mtd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_applied_adj_ifyp_mtd").toString());
						}catch(Exception e){}
						try{
							lpc_applied_adj_ifyp_ytd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_applied_adj_ifyp_ytd").toString());
						}catch(Exception e){}
						try{
							lpc_applied_afyp_mtd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_applied_afyp_mtd").toString());
						}catch(Exception e){}
						try{
							lpc_applied_afyp_ytd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_applied_afyp_ytd").toString());
						}catch(Exception e){}
						try{
							lpc_applied_cases_mtd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_applied_cases_mtd").toString());
						}catch(Exception e){}
						try{
							lpc_applied_cases_ytd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_applied_cases_ytd").toString());
						}catch(Exception e){}
						try{
							lpc_paid_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_paid_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							lpc_paid_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_paid_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							lpc_paid_cases_mtd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_paid_cases_mtd").toString());
						}catch(Exception e){}
						try{
							lpc_paid_cases_ytd = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("lpc_paid_cases_ytd").toString());
						}catch(Exception e){}
					}
					break;
					case "MODE_MIX":
					{
						try{
							annual_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("modemix").get("annual_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							semi_annual_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("modemix").get("semi_annual_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							quarterly_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("modemix").get("quarterly_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							monthly_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("modemix").get("monthly_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							single_adj_mfyp_mtd = (object.getJSONObject("payload").getJSONObject("modemix").get("single_adj_mfyp_mtd").toString());
						}catch(Exception e){}
						try{
							annual_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("modemix").get("annual_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							semi_annual_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("modemix").get("semi_annual_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							quarterly_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("modemix").get("quarterly_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							monthly_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("modemix").get("monthly_adj_mfyp_ytd").toString());
						}catch(Exception e){}
						try{
							single_adj_mfyp_ytd = (object.getJSONObject("payload").getJSONObject("modemix").get("single_adj_mfyp_ytd").toString());
						}catch(Exception e){}
					}
					break;
					case "REC":
					{
						try{
							recruitment_mtd = (object.getJSONObject("payload").getJSONObject("rec").get("recruitment_mtd").toString());
						}catch(Exception e){}
						try{
							recruitment_ytd = (object.getJSONObject("payload").getJSONObject("rec").get("recruitment_ytd").toString());
						}catch(Exception e){}
					}
					break;
				case "HUB_HOLD":
					{
						try{
							System.out.println("IN :: HUB_HOLD");
							logger.info("IN :: HUB_HOLD");
							hubHoldBean =hubHold.HubHoldmethod(object);
							System.out.println("OUT :: HUB_HOLD");
							logger.info("OUT :: HUB_HOLD");
						}catch(Exception ex)
						{
							System.out.println("Exception In HUB_HOLD");
							logger.error("Exception In HUB_HOLD :: "+ex);
						}
					}
					break;
					case "RENEWAL":
					{
						try{
							daily_adj_mfyp = (object.getJSONObject("payload").getJSONObject("renewal").get("daily_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							mtd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("renewal").get("mtd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							ytd_adj_mfyp = (object.getJSONObject("payload").getJSONObject("renewal").get("ytd_adj_mfyp").toString());
						}catch(Exception e){}
						try{
							real_tim_timstamp = (object.getJSONObject("payload").getJSONObject("renewal").get("real_tim_timstamp").toString());
						}catch(Exception e){}
					}
					break;
					case "NAT_HYB_INFORCED":
					{
						try{
							System.out.println("IN :: NAT_HYB_INFORCED");
							logger.info("IN :: NAT_HYB_INFORCED");
							NatHybInforced inforced = new NatHybInforced();
							inforced.natHybInforced(object);
							System.out.println("OUT :: NAT_HYB_INFORCED");
							logger.info("OUT :: NAT_HYB_INFORCED");
						}catch(Exception ex)
						{
							System.out.println("Exception In NAT_HYB_INFORCED");
							logger.error("Exception In NAT_HYB_INFORCED :: "+ex);
						}
					}
					break;
					case "NAT_HYB_APPLIED":
					{
						try{
							System.out.println("IN :: NAT_HYB_APPLIED");
							logger.info("IN :: NAT_HYB_APPLIED");
							NatHybApplied applied = new NatHybApplied();
							applied.natHybAppliedBean(object);
							System.out.println("OUT :: NAT_HYB_APPLIED");
							logger.info("OUT :: NAT_HYB_APPLIED");
						}catch(Exception ex)
						{
							System.out.println("Exception In NAT_HYB_APPLIED");
							logger.error("Exception In NAT_HYB_APPLIED" + ex);
						}
					}
					break;
					case "NAT_HYB_MODEMIX":
					{
						try{
							System.out.println("IN :: NAT_HYB_MODEMIX");
							logger.info("IN :: NAT_HYB_MODEMIX");
							NatHybModeMix modemix = new NatHybModeMix();
							modemix.natHybModeMix(object);
							System.out.println("OUT :: NAT_HYB_MODEMIX");
							logger.info("OUT :: NAT_HYB_MODEMIX");
						}catch(Exception ex)
						{
							System.out.println("Exception In NAT_HYB_MODE_MIX");
							logger.error("Exception In NAT_HYB_MODE_MIX" + ex);
						}
					}
					break;
					case "NAT_HYB_WIP":
					{
						try{
							System.out.println("IN :: NAT_HYB_WIP");
							logger.info("IN :: NAT_HYB_WIP");
							NatHybWIP wip = new NatHybWIP();
							wip.natHybWip(object);
							System.out.println("IN :: NAT_HYB_WIP");
							logger.info("IN :: NAT_HYB_WIP");
						}catch(Exception ex)
						{
							System.out.println("Exception In NAT_HYB_WIP");
							logger.error("Exception In NAT_HYB_WIP :: " + ex);
						}
					}
					break;
					case "NAT_HYB_CASE_SIZE":
					{
						try{
							System.out.println("IN :: NAT_HYB_CASE_SIZE");
							logger.info("IN :: NAT_HYB_CASE_SIZE");
							NatHybCaseSize casesize = new NatHybCaseSize();
							casesize.natHybCaseSize(object);
							System.out.println("OUT :: NAT_HYB_CASE_SIZE");
							logger.info("OUT :: NAT_HYB_CASE_SIZE");
						}catch(Exception ex)
						{
							System.out.println("Exception In NAT_HYB_CASE_SIZE");
							logger.error("Exception In NAT_HYB_CASE_SIZE :: " + ex);
						}
					}
					break;
					case "NAT_HYB_PENETRATION":
					{
						try{
							System.out.println("IN :: NAT_HYB_PENETRATION");
							logger.info("IN :: NAT_HYB_PENETRATION");
							NatHybPenetration penetration = new NatHybPenetration();
							penetration.natHybPenetration(object);
							System.out.println("OUT :: NAT_HYB_PENETRATION");
							logger.info("OUT :: NAT_HYB_PENETRATION");
						}catch(Exception ex)
						{
							System.out.println("Exception In NAT_HYB_PENETRATION");
							logger.error("Exception In NAT_HYB_PENETRATION :: "+ex);
						}
					}
					break;
					case "NAT_HYB_GROWTH":
					{
						try{
							System.out.println("IN :: NAT_HYB_GROWTH");
							logger.info("IN :: NAT_HYB_GROWTH");
							NatHybGrowth growth = new NatHybGrowth();
							growth.natHybGrowth(object);
							System.out.println("OUT :: NAT_HYB_GROWTH");
							logger.info("OUT :: NAT_HYB_GROWTH");
						}catch(Exception ex)
						{
							System.out.println("Exception In NAT_HYB_GROWTH");
							logger.error("Exception In NAT_HYB_GROWTH :: " + ex);
						}
					}
					break;
					case "NTU":
					{
						try{
							System.out.println("IN :: NTU");
							logger.info("IN :: NTU");
							ntubean =ntu.ntumethod(object);
							System.out.println("OUT :: NTU");
							logger.info("OUT :: NTU");
						}catch(Exception ex)
						{
							System.out.println("Exception In NTU");
							logger.error("Exception In NTU :: " + ex);
						}
					}
					break;
					case "PROTECTION":
					case "NBREGION.NBREGION-YES":
					case "NBZONE.NBZONE-YES":
					case "NBCLUSTER.NBCLUSTER-YES":
					case "NBCIRCLE.NBCIRCLE-YES":
					case "NBSUBCHANNEL.NBSUBCHANNEL-YES":
					case "NBGO.NBGO-YES":
					case "NBPERIOD.NBPERIOD-YES":
					case "NBCHANNEL.NBCHANNEL-YES":		
					{
						try{
							System.out.println("IN :: PROTECTION");
							logger.info("IN :: PROTECTION");
							protectionBean =protection.Protectionmethod(object);
							System.out.println("OUT :: PROTECTION");
							logger.info("OUT :: PROTECTION");
						}catch(Exception ex)
						{
							System.out.println("Exception In PROTECTION");
							logger.error("Exception In PROTECTION :: "+ex);
						}
					}
					break;
					case "INSTA_ISSUANCE":
					{
						try{
							logger.info("IN :: INSTAISSUANCE");
							instaIssuanceBean =instaIssuanceJson.getInstaIssuancedata(object);
							logger.info("OUT :: INSTAISSUANCE");
						}catch(Exception ex)
						{
							logger.error("Exception In INSTAISSUANCE :: "+ex);
						}
					}
					break;
					case "POLICYSTATUS":
					{
						logger.info("IN :: POLICYSTATUS");
						policyStatusBean = policyStatus.getPolicyStatus(object);
						logger.info("OUT :: POLICYSTATUS");
					}
					break;					
					default :
						finalresponse="No Action Matched";
					}
				}
				sum3 = sum+ho_wip_adj_mfyp+go_wip_adj_mfyp+it_wip_adj_mfyp+fin_wip_adj_mfyp+misc_wip_adj_mfyp+welcome_wip_adj_mfyp;
				sum = sum+wipAFYP+hoWIPAFYP+goWIPAFYP+itWIPAFYP+finWIPAFYP+miscWIPAFYP+welcomeWIPAFYP;
				String convertsum  =  df.format(sum);
				String convertsum3  =  df.format(sum3);
				sum4=sum4+ho_wip_count+go_wip_count+it_wip_count+fin_wip_count+misc_wip_count+welcome_wip_count;
				String convertsum4  =  df1.format(sum4);
				String intent=action.toUpperCase();
				System.out.println("SWITCH INTENT TO BE CALLED ::"+intent);
				logger.info("SWITCH INTENT TO BE CALLED ::"+intent);
				
				//The change is to merge the channels IM and IMF and showing their business collectively
				//Request Raised By: Bhavneet
				//Date: 14 Jun 2018
						
				if("IMF".equalsIgnoreCase(channel) || "IM Channel".equalsIgnoreCase(channel) || "IM".equalsIgnoreCase(channel))
				{
					channel="IM/IMF";
					msgChannel="IM/IMF";
					serviceChannel="IM/IMF";
					user_sub_channel="";
					user_superzone="";
					userzone="";
					user_keyMarket="";
					 user_region="";
					user_circle="";
					user_clusters="";
					user_go="";
				}
				
				//check if msgChannel contains GO
				//replace with office
				
				if(msgChannel.contains("GO")) {
					msgChannel = msgChannel.replace("GO", "Office");
				}
				
				if(user_go.contains("GO")) {
					user_go = user_go.replace("GO", "Office");
				}
				
				switch(intent)
				{
				case "NUMBERS":
				{
					finalresponse=Numbers.numberIntent(period, source, msgChannel, mtdAdjustMFYP, mtdAppliedAFYP, 
							convertsum3, real_tim_timstamp, serviceChannel, user_sub_channel, dailyAdjustMFYP, 
							ytd_adj_mfyp, dailyAppliedAFYP, ytd_applied_afyp,
							daily_applied_afyp2, daily_applied_count2, daily_applied_adj_ifyp2,
							daily_inforced_afyp2, daily_inforced_count2, daily_adj_mfyp2, LacsCr);
				}
				break;
				case "ADJMFYP":
				{
					finalresponse=AdjMFYP.adjMFYPIntent(period, source, msgChannel, mtdAdjustMFYP, real_tim_timstamp, 
							serviceChannel, dailyAdjustMFYP, ytd_adj_mfyp,
							daily_inforced_afyp2, daily_inforced_count2, daily_adj_mfyp2, LacsCr);
				}
				break;
				/*case "WIP.YES":
				{
					//Code added for bhavneet's requirement(8 Oct 2018). In case sub channel is entered before changing KPI, then in serviceChannel messageChannel should pass
					serviceChannel = msgChannel;
					//added code end
					finalresponse=WIP.wipIntent(serviceChannel, msgChannel, convertsum4, convertsum3, LacsCr, 
							userzone, user_region, user_circle, user_clusters, user_go);
				}
				break;*/
				case "WIP":
				{
					finalresponse=WIPYES.wipyesIntent(serviceChannel, msgChannel, convertsum3, convertsum4, hoWIPAFYP, 
							ho_wip_count, goWIPAFYP, go_wip_count, itWIPAFYP, it_wip_count, finWIPAFYP, fin_wip_count,	
							miscWIPAFYP, misc_wip_count, welcomeWIPAFYP, welcome_wip_count, ho_wip_adj_mfyp, go_wip_adj_mfyp,
							it_wip_adj_mfyp, fin_wip_adj_mfyp, misc_wip_adj_mfyp, welcome_wip_adj_mfyp, LacsCr, 
							userzone, user_region, user_circle, user_clusters, user_go,user_superzone,user_keyMarket);
				}
				break;
				case "APPLIED":
				{
					finalresponse=Applied.appliedIntent(period, source, msgChannel, mtdAppliedAFYP, real_tim_timstamp, 
							serviceChannel, dailyAppliedAFYP, ytd_applied_afyp, mtd_applied_adj_ifyp, ytd_applied_adj_ifyp,
							daily_applied_adj_ifyp, daily_applied_afyp2, daily_applied_count2, daily_applied_adj_ifyp2, LacsCr);
				}
				break;
				case "GROWTH":
				{
					finalresponse=Growth.growthIntent(source, msgChannel, grth_ovr_lst_yr_paid, adj_mfyp_sam_ytd_lst_yr, 
							ytd_inforced_adj_mfyp, period, grth_lst_yr_sm_adj_mfyp_mtd, prev_year_adj_mfyp_mtd, 
							mtd_inforced_adj_mfyp, LacsCr);
				}
				break;
				case "ACHIEVEMENT":
				{
					finalresponse=Achievement.achievementIntent(source, msgChannel, achiev_mtd_adj_mfyp, mtd_adj_mfyp_pln,
							mtd_adj_mfyp_act, achiev_ytd_adj_mfyp, ytd_adj_mfyp_pln, ytd_adj_mfyp_act, real_tim_timstamp, LacsCr);
				}
				break;
				case "PENETRATION":
				{
					finalresponse=Penetration.penetrationIntent(period, productType, source, msgChannel, ul_penet_mtd_afyp, 
							mtd_inforced_afyp, ul_penet_mtd_pol_cnt, mtd_inforced_count, trad_penet_mtd_afyp, 
							trad_penet_mtd_pol_cnt, protec_penet_mtd_afyp,	protec_penet_mtd_pol_cnt, 
							ul_penet_ytd_afyp, ytd_inforced_afyp, ul_penet_ytd_pol_cnt,	ytd_inforced_count, trad_penet_ytd_afyp, 
							trad_penet_ytd_pol_cnt, protec_penet_ytd_afyp, protec_penet_ytd_pol_cnt, LacsCr);
				}
				break;
				/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
				//				Sprint-2.2
				/*-----*/
				case "NB.PAIDCASES":
				{
					finalresponse=PaidCases.paidCasesIntent(serviceChannel, period, user_circle, user_region, userzone, 
							real_tim_timstamp, mtd_inforced_count, ytd_inforced_count, daily_inforced_count1,
							user_sub_channel, user_clusters, user_go,
							daily_inforced_afyp2, daily_inforced_count2, daily_adj_mfyp2,user_superzone,user_keyMarket);
				}
				break;
				case "NB.APPLIED":
				{
					finalresponse=NBApplied.nbAppliedIntent(serviceChannel, period, user_circle, user_region, userzone,
							real_tim_timstamp, mtdAppliedAFYP, ytd_applied_afyp, daily_inforced_count,
									        user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.ADJMFYP":
				{
					finalresponse=NBAdjMFYP.nbAdjMFYPIntent(serviceChannel, period, user_circle, user_region, userzone, 
							real_tim_timstamp, mtdAdjustMFYP, ytd_adj_mfyp, mtd_adj_mfyp, daily_adj_mfyp,
									       user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.CASESIZE":
				{
					finalresponse=NBCaseSize.nbCaseSizeIntent(serviceChannel, period, user_circle, user_region, userzone, 
							real_tim_timstamp, case_size_afyp_mtd, case_size_afyp_ytd,
										 user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.APPLIEDADJIFYP":
				{
					finalresponse= AppliedADJIFYP.appliedAdjIfydIntent(serviceChannel, period, user_region, user_circle,
							userzone, real_tim_timstamp, mtd_applied_adj_ifyp, ytd_applied_adj_ifyp,
							user_sub_channel, user_clusters, user_go, daily_applied_adj_ifyp,
							daily_applied_afyp2, daily_applied_count2, daily_applied_adj_ifyp2, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.APPLIEDCASES":
				{
					finalresponse= Appliedcases.appliedCasesIntent(serviceChannel, period, user_region, user_circle,
							userzone, real_tim_timstamp, mtd_applied_count, ytd_applied_count, daily_applied_count,
										      user_sub_channel, user_clusters, user_go,
										      daily_applied_afyp2, daily_applied_count2, daily_applied_adj_ifyp2, user_superzone, user_keyMarket);
				}
				break;
				case "NB.LPCAPPADJIFYP":
				{
					finalresponse= LpcAPPAdJIFYP.lpcAppAdjIfypIntent(serviceChannel, period, user_region, user_circle,
							userzone, real_tim_timstamp, lpc_applied_adj_ifyp_mtd, lpc_applied_adj_ifyp_ytd,
											user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.LPCAPPADJAFYP":
				{
					finalresponse=Lpcappadjafyp.lpcAppAdjAfypIntent(serviceChannel, period, user_region, user_circle,
							userzone, real_tim_timstamp, lpc_applied_afyp_mtd, lpc_applied_afyp_ytd,
										       user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.LPCAPLCASES":
				{
					finalresponse=Lpcaplcases.lpcAplCasesIntent(serviceChannel, period, user_region, user_circle,
							userzone, real_tim_timstamp, lpc_applied_cases_mtd, lpc_applied_cases_ytd,
										   user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.LPCPAIDADJMFYP":
				{
					finalresponse=LpcPAIDADJMFYP.lpcPaidAdjMfypIntent(serviceChannel, period, user_region, user_circle,
							userzone, real_tim_timstamp, lpc_paid_adj_mfyp_mtd, lpc_paid_adj_mfyp_ytd,
											 user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.LPCPAIDCASES":
				{
					finalresponse=LpcPAIDCASES.lpcPaidCasesIntent(serviceChannel, period, user_region, user_circle,
							userzone, real_tim_timstamp, lpc_paid_cases_mtd, lpc_paid_cases_ytd,
										     user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.CASESIZE%":
				{
					finalresponse=CaseSizePercentage.caseSizePercentageIntent(serviceChannel, period, user_region, 
							user_circle, userzone, real_tim_timstamp,  achiev_mtd_case_size, achiev_ytd_case_size, 
							user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.GROWTH":
				{
					finalresponse=NBGrowth.growthIntent(serviceChannel, period, user_region, user_circle, 
							userzone, real_tim_timstamp, prev_year_adj_mfyp_ytd, grth_lst_yr_sm_adj_mfyp_ytd, 
							ytd_inforced_adj_mfyp, grth_lst_yr_sm_adj_mfyp_mtd, prev_year_adj_mfyp_mtd, 
							mtd_inforced_adj_mfyp, user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.RECRUITMENT":
				{
					finalresponse=Recruitment.recruitmentIntent(serviceChannel, period, user_region, user_circle,
							userzone, real_tim_timstamp, recruitment_mtd, recruitment_ytd,
										   user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.RECRUITMENT%":
				{
					finalresponse=Recruitmentpercentage.recruitmentPercentageIntent(serviceChannel, period, user_region, 
					user_circle, userzone, real_tim_timstamp, achiev_mtd_recruitment, achiev_ytd_recruitment,
						user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.GROWTHAPLADJIFYP":
				{
					finalresponse=NBGROWTHAPLADGIFYP.nbGROWTHAPLADGIFYPIntent(serviceChannel, period, user_circle, 
							user_region, userzone, grth_applied_adj_ifyp_ytd, rpev_applied_adj_ifyp_ytd, 
							applied_adj_ifyp_ytd, grth_applied_adj_ifyp_mtd, 
							rpev_applied_adj_ifyp_mtd, applied_adj_ifyp_mtd, user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.GROWTHAPLAFYP":
				{
					finalresponse=NBGROWTHAPLAFYP.nbGROWTHAPLAFYPIntent(serviceChannel, period, user_circle, user_region, 
							userzone, prev_applied_afyp_ytd, grth_applied_afyp_ytd, grth_applied_afyp_mtd, 
							applied_afyp_ytd, prev_applied_afyp_mtd, applied_afyp_mtd, user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				
				case "NB.GROWTHAPLCASES":
				{
					finalresponse=NBGROWTHAPLCASES.nbGROWTHAPLCASESIntent(serviceChannel, period, user_circle, 
							user_region, userzone, prev_applied_cases_ytd, grth_applied_cases_ytd, grth_applied_cases_mtd, 
							applied_cases_ytd, prev_applied_cases_mtd, applied_cases_mtd, user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.GROWTHCASESIZE":
				{
					finalresponse=GrowthCaseSize.growthCaseSizeIntent(serviceChannel, period, userzone, user_region, 
							real_tim_timstamp, user_circle, grth_case_size_afyp_ytd, prev_case_size_afyp_ytd,
							case_size_afyp_ytd_growth, grth_case_size_afyp_mtd, prev_case_size_afyp_mtd, 
							case_size_afyp_mtd, case_size_afyp_mtd_growth, user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.GROWTHLPCADJMFYP":
				{
					finalresponse=GrowthLPCADJMFYP.growthLPCADJMFYPIntent(serviceChannel, period, userzone, user_region,
							real_tim_timstamp, user_circle,	grth_lpc_paid_adj_mfyp_ytd, prev_lpc_paid_adj_mfyp_ytd, 
							lpc_paid_adj_mfyp_ytd_growth, grth_lpc_paid_adj_mfyp_mtd, prev_lpc_paid_adj_mfyp_mtd, 
							lpc_paid_adj_mfyp_mtd_growth, user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.GROWTHLPCAPLADJIFYP":
				{
					finalresponse=GrowthLPCAPLADJIFYP.growthLPCAPLADJIFYPIntent(serviceChannel, period, userzone, user_region,
							real_tim_timstamp, user_circle, grth_lpc_applied_adj_ifyp_ytd, prev_lpc_applied_adj_ifyp_ytd, 
							lpc_applied_adj_ifyp_ytd_growth, grth_lpc_applied_adj_ifyp_mtd,	prev_lpc_applied_adj_ifyp_mtd, 
							lpc_applied_adj_ifyp_mtd_growth, lpc_paid_adj_mfyp_ytd_growth, lpc_paid_adj_mfyp_mtd_growth, 
							grth_lpc_paid_adj_mfyp_ytd, prev_lpc_paid_adj_mfyp_ytd, prev_lpc_paid_adj_mfyp_mtd, 
							grth_lpc_paid_adj_mfyp_mtd, user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				/*---------------------------------------------------*/
				case "NB.GROWTHLPCAPLAFYP":
				{
					finalresponse=GrowthLPCAPLAFYP.growthLPCAPLAFYPIntent(serviceChannel, period, userzone, user_region,
							real_tim_timstamp, user_circle, grth_lpc_applied_afyp_ytd, prev_lpc_applied_afyp_ytd, 
							curr_lpc_applied_afyp_ytd, grth_lpc_applied_afyp_mtd, prev_lpc_applied_afyp_mtd, 
							curr_lpc_applied_afyp_mtd, user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.GROWTHLPCAPLCASES":
				{
					finalresponse=GrowthLPCAPLCases.growthLPCAPLCasesIntent(serviceChannel, period, userzone, user_region, 
							real_tim_timstamp, user_circle, grth_lpc_applied_cases_ytd, prev_lpc_applied_cases_ytd, 
							lpc_applied_cases_ytd_growth, grth_lpc_applied_cases_mtd, prev_lpc_applied_cases_mtd,
							lpc_applied_cases_mtd_growth, user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				/*---------------------------------------------------*/
				case "NB.GROWTHLPCPAIDCASES":
				{ 
					finalresponse=GrowthLPCPaidCases.growthLPCPaidcasesIntent(serviceChannel, period, userzone, user_region, 
							real_tim_timstamp, user_circle, grth_lpc_paid_cases_ytd, prev_lpc_paid_cases_ytd, 
							lpc_paid_cases_ytd_growth, grth_lpc_paid_cases_mtd, prev_lpc_paid_cases_mtd, 
							lpc_paid_cases_mtd_growth, user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.GROWTHPAIDCASES":
				{
					finalresponse=GrowthPaidcases.growthPaidcasesIntent(serviceChannel, period, userzone, user_region, 
							real_tim_timstamp, grth_lst_yr_inforced_cnt_ytd, prev_year_inforced_cnt_ytd, 
							ytd_inforced_cnt, grth_lst_yr_inforced_cnt_mtd, prev_year_inforced_cnt_mtd, mtd_inforced_cnt,
							user_circle, user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.GROWTHRECRUITMENT":
				{
					finalresponse=GrowthRecruitment.growthRecruitmentIntent(serviceChannel, period, userzone, user_region,
							real_tim_timstamp, grth_recruitment_ytd, prev_recruitment_ytd, recruitment_ytd_growth,
							grth_recruitment_mtd, prev_recruitment_mtd, recruitment_mtd_growth, recruitment_ytd_growth,
							user_circle, user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.MODEMIX":
				{
					finalresponse=ModeMix.modeMixIntent(serviceChannel, period,  userzone,  user_region,  real_tim_timstamp,
							 annual_adj_mfyp_mtd, semi_annual_adj_mfyp_mtd,  quarterly_adj_mfyp_mtd, monthly_adj_mfyp_mtd,
							 single_adj_mfyp_mtd, annual_adj_mfyp_ytd,  semi_annual_adj_mfyp_ytd, quarterly_adj_mfyp_ytd,
							 monthly_adj_mfyp_ytd, single_adj_mfyp_ytd, user_circle, user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.ACHIEVEMENT":

				{
					finalresponse=NbAchievement.achievementIntent(serviceChannel, period, userzone, user_region, 
							real_tim_timstamp, achiev_mtd_adj_mfyp, achiev_mtd_paid_case, mtd_adj_afyp_act,
							mtd_adj_afyp_pln, mtd_paid_case_act, mtd_paid_case_pln, achiev_ytd_adj_mfyp, 
							achiev_ytd_paid_case, ytd_adj_mfyp_act, ytd_adj_mfyp_pln, ytd_paid_case_act, 
							ytd_paid_case_pln, user_circle, user_sub_channel, user_clusters, user_go, LacsCr, user_superzone, user_keyMarket);

				}
				break;
				case "NB.PRODUCTMIX":
				{
					finalresponse=ProductMix.productMixIntent(serviceChannel, period, userzone, user_region, real_tim_timstamp,
							ul_penet_mtd_adj_mfyp, par_penet_mtd_adj_mfyp, nonpar_penet_mtd_adj_mfyp, 
							protec_penet_mtd_adj_mfyp, ul_penet_mtd_pol_cnt, par_penet_mtd_pol_cnt, 
							nonpar_penet_mtd_pol_cnt, protec_penet_mtd_pol_cnt, protec_penet_ytd_adj_mfyp, 
							ul_penet_ytd_adj_mfyp, par_penet_ytd_adj_mfyp, nonpar_penet_ytd_adj_mfyp, 
							ul_penet_ytd_pol_cnt, par_penet_ytd_pol_cnt, nonpar_penet_ytd_pol_cnt, 
							protec_penet_ytd_pol_cnt, user_circle, user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.PRODUCTMIXADJMFYP":
				{
					finalresponse=ProductMixADJMFYP.productMixADJMFYPIntent(serviceChannel, period, userzone, user_region, 
							real_tim_timstamp, ul_penet_mtd_adj_mfyp, par_penet_mtd_adj_mfyp, nonpar_penet_mtd_adj_mfyp, 
							protec_penet_mtd_adj_mfyp, ul_penet_ytd_adj_mfyp, par_penet_ytd_adj_mfyp, 
							nonpar_penet_ytd_adj_mfyp, protec_penet_ytd_adj_mfyp, user_circle, user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.PRODUCTMIXPAIDCASE":
				{
					finalresponse=ProductMixPaidCase.productMixPaidCaseIntent(serviceChannel, period, userzone, user_region, 
							real_tim_timstamp, ul_penet_mtd_pol_cnt, par_penet_mtd_pol_cnt,
							ul_penet_ytd_pol_cnt, par_penet_ytd_pol_cnt, nonpar_penet_mtd_pol_cnt,nonpar_penet_ytd_pol_cnt, 
							protec_penet_mtd_pol_cnt, protec_penet_ytd_pol_cnt,user_circle, user_sub_channel, user_clusters, user_go, user_superzone, user_keyMarket);
				}
				break;
				case "NB.HUBHOLD":
				{
					finalresponse=HubHoldCases.hubHoldIntent(serviceChannel, period, userzone, user_region, 
							 user_circle, user_sub_channel, user_clusters, user_go, LacsCr, hubHoldBean, user_superzone, user_keyMarket);
				}
				break;
				case "NB.RENEWAL":
				{
					finalresponse=Renewal.renewalIntent(daily_adj_mfyp, mtd_adj_mfyp, ytd_adj_mfyp, real_tim_timstamp, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.NTU":
				{
					finalresponse=NTUCases.ntuIntent(serviceChannel,period,userzone, user_region, 
							user_circle, user_sub_channel, user_clusters, user_go, ntubean, LacsCr, user_superzone, user_keyMarket);
				}
				break;
				case "NB.PROTECTION":
				{
					finalresponse=ProtectionCases.protectionIntent(serviceChannel, period, userzone, user_region, 
							user_circle, user_sub_channel, user_clusters, user_go, LacsCr, protectionBean, user_superzone, user_keyMarket);
				}
				break;
				case "PROTECTION.YES":
				case "NBREGION.NBREGION-YES":
				case "NBZONE.NBZONE-YES":
				case "NBCLUSTER.NBCLUSTER-YES":
				case "NBCIRCLE.NBCIRCLE-YES":
				case "NBSUBCHANNEL.NBSUBCHANNEL-YES":
				case "NBGO.NBGO-YES":
				case "NBPERIOD.NBPERIOD-YES":
				case "NBCHANNEL.NBCHANNEL-YES":		
						
				{
					finalresponse=ProtectionYes.protectionyesIntent(serviceChannel, msgChannel, LacsCr, protectionBean, user_superzone, user_keyMarket);
				}	
				break;
				case "NB.POLICYSTATUS":
				{
					finalresponse = policyStatusMessage.policyStatusIntent(policyStatusBean);
				}
				 break;
				/*APR NEW REQUIREMENT*/
				
				case "APR":
				{
					finalresponse = aprApiCall.getAprData(user_ssoid,agentId,"NO");
				}
				
				break;
				
				case "NB.INSTAISSUANCE":
				case "NB.INSTAISSUANCEMED":
				{
					finalresponse = instaIssuance.getInstaIssuanceMsg(serviceChannel, period, userzone, user_region, 
							user_circle, user_sub_channel, user_clusters, user_go, LacsCr, instaIssuanceBean, user_superzone, user_keyMarket, instaType);
				}
				
				break;		
				default :
					finalresponse="Something gets wrong between action & channel";
				}
				speech=finalresponse;
				logger.info("Final speech :: " + speech);
			}
			catch(Exception e)
			{
				logger.error("Something went wrong in Bot Logic :: "+e);
                speech="There is some communication glitch! Please try after some time";
                logger.info("Error :: "+speech);
			}
		}
		catch(Exception ex)
		{
				logger.error("Exception In Outer Catch"+ex);    
				speech="There is some communication glitch! Please try after some time";
                logger.info("Error :: "+speech);
		}

		if("NUMBERS".equalsIgnoreCase(action))
		{
		            InnerButton innerButton1 = new InnerButton();
					innerButton1.setText("Axis Bank");
					innerButton1.setPostback("AxisBank");
							//For Second button
					InnerButton innerButton2 = new InnerButton();
					innerButton2.setText("Agency");
					innerButton2.setPostback("Agency");
							
					InnerButton innerButton3 = new InnerButton();
					innerButton3.setText("Banca");
					innerButton3.setPostback("Banca");
							
					InnerButton innerButton4 = new InnerButton();
					innerButton4.setText("CAT");
					innerButton4.setPostback("CAT");
					
					InnerButton innerButton5 = new InnerButton();
					innerButton5.setText("Ecomm");
					innerButton5.setPostback("Ecomm");
					
					InnerButton innerButton6 = new InnerButton();
					innerButton6.setText("IM");
					innerButton6.setPostback("IM");
					
					InnerButton innerButton7 = new InnerButton();
					innerButton7.setText("IMF");
					innerButton7.setPostback("IMF");
					
					innerbuttonlist.add(innerButton1);
					innerbuttonlist.add(innerButton2);
					innerbuttonlist.add(innerButton3);
					innerbuttonlist.add(innerButton4);
					innerbuttonlist.add(innerButton5);
					innerbuttonlist.add(innerButton6);
					innerbuttonlist.add(innerButton7);
					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
		}
		
		//Remove Message content start "If you want to see the Zone/Region wise business numbers, please specify the same"
		//Request raised by Bhavneet
		//Date: 29 Jun 2018
		if("IMF".equalsIgnoreCase(channel) || "IM".equalsIgnoreCase(channel) || "IM Channel".equalsIgnoreCase(channel) || "IM/IMF".equalsIgnoreCase(channel) 
				||"IM/IMF".equalsIgnoreCase(msgChannel) || "IM/IMF".equalsIgnoreCase(serviceChannel))
		{
			if(speech.contains("If you want to see the Zone/Region wise business numbers, please specify the same."))
			{
				
				String stringToRemove = "If you want to see the Zone/Region wise business numbers, please specify the same.";
				speech = speech.replace(stringToRemove , "");
			}
		}
		//Remove message content end
		
		//case when it is not an authorized key market access
		if(!isAuthorizedKeymarket) {
			speech = "You are not authorized to see different key market data";
		}
		
		WebhookResponse responseObj = new WebhookResponse(speech, speech, null);
		System.out.println("End : Response :: "+ speech); 
		return responseObj;
	}

	public String convertToCamelCase(String channel)
	{

		final String ACTIONABLE_DELIMITERS = " '-/"; // these cause the character following
		// to be capitalized

		StringBuilder sb = new StringBuilder();
		boolean capNext = true;

		for (char c : channel.toCharArray()) {
			c = (capNext)
					? Character.toUpperCase(c)
							: Character.toLowerCase(c);
					sb.append(c);
					capNext = (ACTIONABLE_DELIMITERS.indexOf((int) c) >= 0); // explicit cast not needed

		}
		return sb.toString();
	}
}
