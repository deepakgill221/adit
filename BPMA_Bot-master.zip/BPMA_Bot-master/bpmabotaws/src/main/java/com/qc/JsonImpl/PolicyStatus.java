package com.qc.jsonImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.qc.dataBean.PolicyStatusBean;

//@Component
public class PolicyStatus 
{
	private static Logger logger = LogManager.getLogger(PolicyStatus.class);
	//@Autowired
	PolicyStatusBean policyStatusBean = new PolicyStatusBean();
	
	public PolicyStatusBean getPolicyStatus(JSONObject object)
	{
		JSONObject payLoad = null;
		try
		{
		if(object != null)
		{		
		payLoad=object.getJSONObject("payload");
		
		JSONObject policyStatus= payLoad.getJSONObject("policyStatus");
		
		policyStatusBean.setChannel(validatePolicyData(policyStatus.get("channel")));
		policyStatusBean.setSubChannel(validatePolicyData(policyStatus.get("subChannel")));
		policyStatusBean.setRaAdmAgtId(validatePolicyData(policyStatus.get("raAdmAgtId")));
		policyStatusBean.setPolicyNumber(validatePolicyData(policyStatus.get("policyNumber")));
		policyStatusBean.setPolicyStatusDesc(validatePolicyData(policyStatus.get("policyStatusDesc")));
		policyStatusBean.setPolDueDate(validatePolicyData(policyStatus.get("polDueDate")));
		policyStatusBean.setBtchTimstamp(validatePolicyData(policyStatus.get("btchTimstamp")));
		policyStatusBean.setRealTimTimstamp(validatePolicyData(policyStatus.get("realTimTimstamp")));
		policyStatusBean.setWorkitemDescription(validatePolicyData(policyStatus.get("workitemDescription")));
		policyStatusBean.setPendingRequirement(validatePolicyData(policyStatus.get("pendingRequirement")));
		policyStatusBean.setTppComment(validatePolicyData(policyStatus.get("tppComment")));
		}
		}
		catch(Exception ex)
		{
			logger.error(ex);
		}
		return policyStatusBean;
	}

	private String validatePolicyData(Object object) 
	{
		String policyStatus="";
		try
		{
		if(object!=null && !(object.toString().isEmpty())){
			policyStatus= object.toString();
		}
			
		}catch(Exception ex)
		{
			logger.error(ex);
		}
		return policyStatus;
	}
	
	
}
