package com.qc.jsonImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.qc.common.ConvertToString;
import com.qc.dataBean.InstaIssuanceBean;

public class InstaIssuanceJson {
	
	private static Logger logger = LogManager.getLogger(InstaIssuanceJson.class);
	
	@Autowired
	ConvertToString convert;
	public InstaIssuanceBean getInstaIssuancedata(JSONObject jsonObject)
	{
		InstaIssuanceBean instaIssuanceBean = new InstaIssuanceBean();
		try{
		JSONObject partialObject = jsonObject.getJSONObject("payload");
		JSONObject object = partialObject.getJSONObject("instaIssuance");
		
		instaIssuanceBean.setDesignationDesc(getValue(object.get("designationDesc")));
		instaIssuanceBean.setChannel(getValue(object.get("channel")));
		instaIssuanceBean.setSubChannel(getValue(object.get("subChannel")));
		instaIssuanceBean.setSuperZone(getValue(object.get("superZone")));
		instaIssuanceBean.setZone(getValue(object.get("zone")));
		instaIssuanceBean.setRegion(getValue(object.get("region")));
		instaIssuanceBean.setKeyMarket(getValue(object.get("keyMarket")));
		instaIssuanceBean.setCircle(getValue(object.get("circle")));
		instaIssuanceBean.setClusters(getValue(object.get("clusters")));
		instaIssuanceBean.setGo(getValue(object.get("go")));
		instaIssuanceBean.setCmo(getValue(object.get("cmo")));
		instaIssuanceBean.setAmo(getValue(object.get("amo")));
		instaIssuanceBean.setIiNpNmNopAllMtd(getValue(object.get("iiNpNmNopAllMtd")));
		instaIssuanceBean.setIiNpNmAdjMfypAllMtd(getValue(object.get("iiNpNmAdjMfypAllMtd")));
		instaIssuanceBean.setIiNpNmNop6hMtd(getValue(object.get("iiNpNmNop6hMtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp6hMtd(getValue(object.get("iiNpNmAdjMfyp6hMtd")));
		instaIssuanceBean.setIiNpNmNop12hMtd(getValue(object.get("iiNpNmNop12hMtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp12hMtd(getValue(object.get("iiNpNmAdjMfyp12hMtd")));
		instaIssuanceBean.setIiNpNmNop24hMtd(getValue(object.get("iiNpNmNop24hMtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp24hMtd(getValue(object.get("iiNpNmAdjMfyp24hMtd")));
		instaIssuanceBean.setIiNpMnmNopAllMtd(getValue(object.get("iiNpMnmNopAllMtd")));
		instaIssuanceBean.setIiNpMnmAdjMfypAllMtd(getValue(object.get("iiNpMnmAdjMfypAllMtd")));
		instaIssuanceBean.setIiNpMnmNop6hMtd(getValue(object.get("iiNpMnmNop6hMtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp6hMtd(getValue(object.get("iiNpMnmAdjMfyp6hMtd")));
		instaIssuanceBean.setIiNpMnmNop12hMtd(getValue(object.get("iiNpMnmNop12hMtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp12hMtd(getValue(object.get("iiNpMnmAdjMfyp12hMtd")));
		instaIssuanceBean.setIiNpMnmNop24hMtd(getValue(object.get("iiNpMnmNop24hMtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp24hMtd(getValue(object.get("iiNpMnmAdjMfyp24hMtd")));
		instaIssuanceBean.setIiNpNmNopAllFtd(getValue(object.get("iiNpNmNopAllFtd")));
		instaIssuanceBean.setIiNpNmAdjMfypAllFtd(getValue(object.get("iiNpNmAdjMfypAllFtd")));
		instaIssuanceBean.setIiNpNmNop6hFtd(getValue(object.get("iiNpNmNop6hFtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp6hFtd(getValue(object.get("iiNpNmAdjMfyp6hFtd")));
		instaIssuanceBean.setIiNpNmNop12hFtd(getValue(object.get("iiNpNmNop12hFtd")));
		instaIssuanceBean.setIiNpNmNop12hFtd(getValue(object.get("iiNpNmNop12hFtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp12hFtd(getValue(object.get("iiNpNmAdjMfyp12hFtd")));
		instaIssuanceBean.setIiNpNmNop24hFtd(getValue(object.get("iiNpNmNop24hFtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp24hFtd(getValue(object.get("iiNpNmAdjMfyp24hFtd")));
		instaIssuanceBean.setIiNpMnmNopAllFtd(getValue(object.get("iiNpMnmNopAllFtd")));
		instaIssuanceBean.setIiNpMnmAdjMfypAllFtd(getValue(object.get("iiNpMnmAdjMfypAllFtd")));
		instaIssuanceBean.setIiNpMnmNop6hFtd(getValue(object.get("iiNpMnmNop6hFtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp6hFtd(getValue(object.get("iiNpMnmAdjMfyp6hFtd")));
		instaIssuanceBean.setIiNpMnmNop12hFtd(getValue(object.get("iiNpMnmNop12hFtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp12hFtd(getValue(object.get("iiNpMnmAdjMfyp12hFtd")));
		instaIssuanceBean.setIiNpMnmNop24hFtd(getValue(object.get("iiNpMnmNop24hFtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp24hFtd(getValue(object.get("iiNpMnmAdjMfyp24hFtd")));
		instaIssuanceBean.setIiNpNmNopAllYtd(getValue(object.get("iiNpNmNopAllYtd")));
		instaIssuanceBean.setIiNpNmAdjMfypAllYtd(getValue(object.get("iiNpNmAdjMfypAllYtd")));
		instaIssuanceBean.setIiNpNmNop6hYtd(getValue(object.get("iiNpNmNop6hYtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp6hYtd(getValue(object.get("iiNpNmAdjMfyp6hYtd")));
		instaIssuanceBean.setIiNpNmNop12hYtd(getValue(object.get("iiNpNmNop12hYtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp12hYtd(getValue(object.get("iiNpNmAdjMfyp12hYtd")));
		instaIssuanceBean.setIiNpNmNop24hYtd(getValue(object.get("iiNpNmNop24hYtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp24hYtd(getValue(object.get("iiNpNmAdjMfyp24hYtd")));
		instaIssuanceBean.setIiNpMnmNopAllYtd(getValue(object.get("iiNpMnmNopAllYtd")));
		instaIssuanceBean.setIiNpMnmAdjMfypAllYtd(getValue(object.get("iiNpMnmAdjMfypAllYtd")));
		instaIssuanceBean.setIiNpMnmNop6hYtd(getValue(object.get("iiNpMnmNop6hYtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp6hYtd(getValue(object.get("iiNpMnmAdjMfyp6hYtd")));
		instaIssuanceBean.setIiNpMnmNop12hYtd(getValue(object.get("iiNpMnmNop12hYtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp12hYtd(getValue(object.get("iiNpMnmAdjMfyp12hYtd")));
		instaIssuanceBean.setIiNpMnmNop24hYtd(getValue(object.get("iiNpMnmNop24hYtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp24hYtd(getValue(object.get("iiNpMnmAdjMfyp24hYtd")));
		instaIssuanceBean.setIiTimeStamp(getValue(object.get("iiTimeStamp")));
		instaIssuanceBean.setColumn1(getValue(object.get("column1")));
		instaIssuanceBean.setColumn2(getValue(object.get("column2")));
		instaIssuanceBean.setColumn3(getValue(object.get("column3")));
		instaIssuanceBean.setColumn4(getValue(object.get("column4")));
		instaIssuanceBean.setColumn5(getValue(object.get("column5")));
		

		}
		catch(Exception ex)
		{
			logger.error("Exception in putting value into insta issuance bean :: "+ex);
		}
		
		
		
		return instaIssuanceBean;
		
	}
	
	
	private String getValue(Object object) 
	{
		String value="";
		try
		{
		if(object!=null && !"".equalsIgnoreCase(object.toString())){
			value= object.toString();
		}
			
		}catch(Exception ex)
		{
			logger.error("Exception in converting object into String :: "+ex);
		}
		return value;
	}

}
