package com.qc.jsonImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.qc.common.ConvertToString;
import com.qc.dataBean.InstaIssuanceBean;

public class InstaIssuanceJson {
	
	private static Logger logger = LogManager.getLogger(InstaIssuanceJson.class);
	
	@Autowired
	InstaIssuanceBean instaIssuanceBean;
	@Autowired
	ConvertToString convert;
	public InstaIssuanceBean getInstaIssuancedata(JSONObject jsonObject)
	{
		try{
		JSONObject object = jsonObject.getJSONObject("payload").getJSONObject("instaIssuance");
		
		instaIssuanceBean.setDesignationDesc(convert.getValue(object.get("designationDesc")));
		instaIssuanceBean.setChannel(convert.getValue(object.get("channel")));
		instaIssuanceBean.setSubChannel(convert.getValue(object.get("subChannel")));
		instaIssuanceBean.setSuperZone(convert.getValue(object.get("superZone")));
		instaIssuanceBean.setZone(convert.getValue(object.get("zone")));
		instaIssuanceBean.setRegion(convert.getValue(object.get("region")));
		instaIssuanceBean.setKeyMarket(convert.getValue(object.get("keyMarket")));
		instaIssuanceBean.setCircle(convert.getValue(object.get("circle")));
		instaIssuanceBean.setClusters(convert.getValue(object.get("clusters")));
		instaIssuanceBean.setGo(convert.getValue(object.get("go")));
		instaIssuanceBean.setCmo(convert.getValue(object.get("cmo")));
		instaIssuanceBean.setAmo(convert.getValue(object.get("amo")));
		instaIssuanceBean.setIiNpNmNopAllMtd(convert.getValue(object.get("iiNpNmNopAllMtd")));
		instaIssuanceBean.setIiNpNmAdjMfypAllMtd(convert.getValue(object.get("iiNpNmAdjMfypAllMtd")));
		instaIssuanceBean.setIiNpNmNop6hMtd(convert.getValue(object.get("iiNpNmNop6hMtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp6hMtd(convert.getValue(object.get("iiNpNmAdjMfyp6hMtd")));
		instaIssuanceBean.setIiNpNmNop12hMtd(convert.getValue(object.get("iiNpNmNop12hMtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp12hMtd(convert.getValue(object.get("iiNpNmAdjMfyp12hMtd")));
		instaIssuanceBean.setIiNpNmNop24hMtd(convert.getValue(object.get("iiNpNmNop24hMtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp24hMtd(convert.getValue(object.get("iiNpNmAdjMfyp24hMtd")));
		instaIssuanceBean.setIiNpMnmNopAllMtd(convert.getValue(object.get("iiNpMnmNopAllMtd")));
		instaIssuanceBean.setIiNpMnmAdjMfypAllMtd(convert.getValue(object.get("iiNpMnmAdjMfypAllMtd")));
		instaIssuanceBean.setIiNpMnmNop6hMtd(convert.getValue(object.get("iiNpMnmNop6hMtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp6hMtd(convert.getValue(object.get("iiNpMnmAdjMfyp6hMtd")));
		instaIssuanceBean.setIiNpMnmNop12hMtd(convert.getValue(object.get("iiNpMnmNop12hMtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp12hMtd(convert.getValue(object.get("iiNpMnmAdjMfyp12hMtd")));
		instaIssuanceBean.setIiNpMnmNop24hMtd(convert.getValue(object.get("iiNpMnmNop24hMtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp24hMtd(convert.getValue(object.get("iiNpMnmAdjMfyp24hMtd")));
		instaIssuanceBean.setIiNpNmNopAllFtd(convert.getValue(object.get("iiNpNmNopAllFtd")));
		instaIssuanceBean.setIiNpNmAdjMfypAllFtd(convert.getValue(object.get("iiNpNmAdjMfypAllFtd")));
		instaIssuanceBean.setIiNpNmNop6hFtd(convert.getValue(object.get("iiNpNmNop6hFtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp6hFtd(convert.getValue(object.get("iiNpNmAdjMfyp6hFtd")));
		instaIssuanceBean.setIiNpNmNop12hFtd(convert.getValue(object.get("iiNpNmNop12hFtd")));
		instaIssuanceBean.setIiNpNmNop12hFtd(convert.getValue(object.get("iiNpNmNop12hFtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp12hFtd(convert.getValue(object.get("iiNpNmAdjMfyp12hFtd")));
		instaIssuanceBean.setIiNpNmNop24hFtd(convert.getValue(object.get("iiNpNmNop24hFtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp24hFtd(convert.getValue(object.get("iiNpNmAdjMfyp24hFtd")));
		instaIssuanceBean.setIiNpMnmNopAllFtd(convert.getValue(object.get("iiNpMnmNopAllFtd")));
		instaIssuanceBean.setIiNpMnmAdjMfypAllFtd(convert.getValue(object.get("iiNpMnmAdjMfypAllFtd")));
		instaIssuanceBean.setIiNpMnmNop6hFtd(convert.getValue(object.get("iiNpMnmNop6hFtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp6hFtd(convert.getValue(object.get("iiNpMnmAdjMfyp6hFtd")));
		instaIssuanceBean.setIiNpMnmNop12hFtd(convert.getValue(object.get("iiNpMnmNop12hFtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp12hFtd(convert.getValue(object.get("iiNpMnmAdjMfyp12hFtd")));
		instaIssuanceBean.setIiNpMnmNop24hFtd(convert.getValue(object.get("iiNpMnmNop24hFtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp24hFtd(convert.getValue(object.get("iiNpMnmAdjMfyp24hFtd")));
		instaIssuanceBean.setIiNpNmNopAllYtd(convert.getValue(object.get("iiNpNmNopAllYtd")));
		instaIssuanceBean.setIiNpNmAdjMfypAllYtd(convert.getValue(object.get("iiNpNmAdjMfypAllYtd")));
		instaIssuanceBean.setIiNpNmNop6hYtd(convert.getValue(object.get("iiNpNmNop6hYtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp6hYtd(convert.getValue(object.get("iiNpNmAdjMfyp6hYtd")));
		instaIssuanceBean.setIiNpNmNop12hYtd(convert.getValue(object.get("iiNpNmNop12hYtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp12hYtd(convert.getValue(object.get("iiNpNmAdjMfyp12hYtd")));
		instaIssuanceBean.setIiNpNmNop24hYtd(convert.getValue(object.get("iiNpNmNop24hYtd")));
		instaIssuanceBean.setIiNpNmAdjMfyp24hYtd(convert.getValue(object.get("iiNpNmAdjMfyp24hYtd")));
		instaIssuanceBean.setIiNpMnmNopAllYtd(convert.getValue(object.get("iiNpMnmNopAllYtd")));
		instaIssuanceBean.setIiNpMnmAdjMfypAllYtd(convert.getValue(object.get("iiNpMnmAdjMfypAllYtd")));
		instaIssuanceBean.setIiNpMnmNop6hYtd(convert.getValue(object.get("iiNpMnmNop6hYtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp6hYtd(convert.getValue(object.get("iiNpMnmAdjMfyp6hYtd")));
		instaIssuanceBean.setIiNpMnmNop12hYtd(convert.getValue(object.get("iiNpMnmNop12hYtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp12hYtd(convert.getValue(object.get("iiNpMnmAdjMfyp12hYtd")));
		instaIssuanceBean.setIiNpMnmNop24hYtd(convert.getValue(object.get("iiNpMnmNop24hYtd")));
		instaIssuanceBean.setIiNpMnmAdjMfyp24hYtd(convert.getValue(object.get("iiNpMnmAdjMfyp24hYtd")));
		instaIssuanceBean.setIiTimeStamp(convert.getValue(object.get("iiTimeStamp")));
		instaIssuanceBean.setColumn1(convert.getValue(object.get("column1")));
		instaIssuanceBean.setColumn2(convert.getValue(object.get("column2")));
		instaIssuanceBean.setColumn3(convert.getValue(object.get("column3")));
		instaIssuanceBean.setColumn4(convert.getValue(object.get("column4")));
		instaIssuanceBean.setColumn5(convert.getValue(object.get("column5")));
		

		}
		catch(Exception ex)
		{
			logger.error("Exception in putting value into insta issuance bean :: "+ex);
		}
		return instaIssuanceBean;
		
	}

}
