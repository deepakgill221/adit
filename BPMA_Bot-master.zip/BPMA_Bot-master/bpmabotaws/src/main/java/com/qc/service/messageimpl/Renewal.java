package com.qc.service.messageimpl;

public class Renewal 
{
	public static String renewalIntent(String daily_adj_mfyp, String mtd_adj_mfyp, String ytd_adj_mfyp, String real_tim_timstamp, String LacsCr, String superZone, String keyMarket)
	{
		String finalresponse="";
		finalresponse="Renewal Income for MLI is FTD : "+daily_adj_mfyp+" " + LacsCr +", "
				+ "MTD : "+mtd_adj_mfyp+" " + LacsCr +" and YTD : "+ytd_adj_mfyp+" " + LacsCr +".";
		return finalresponse;
	}
}