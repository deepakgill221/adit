package com.qc.service.messageimpl;

import com.qc.jsonImpl.NatHybApplied;

public class AppliedADJIFYP 
{
	public static String appliedAdjIfydIntent(String channel, String period, String user_region, String user_circle, String userzone , String real_tim_timstamp,
			String mtd_applied_adj_ifyp , String ytd_applied_adj_ifyp, String subchannel,String user_clusters, String user_go, String daily_applied_adj_ifyp,
			String daily_applied_afyp2, String daily_applied_count2, String daily_applied_adj_ifyp2, String LacsCr, String superZone, String keyMarket)

	{
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{
			period="";
		}
		else
		{
			period=period.toUpperCase();
		}
		if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{
			channel = subchannel;
		}
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied Business Adj IFYP MTD for MLI "
					+ mtd_applied_adj_ifyp+" " + LacsCr +". Applied Business Adj IFYP YTD for MLI "+ytd_applied_adj_ifyp+ 
					" " + LacsCr +". If you want to see the channel wise business numbers, please specify";
		}else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(keyMarket))
		{
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse= "As of "+real_tim_timstamp+" Applied Business Adj IFYP MTD for "+channel+" is "+mtd_applied_adj_ifyp+
						" " + LacsCr +". Applied Business Adj IFYP YTD for "+channel+" is "+ytd_applied_adj_ifyp+
						" " + LacsCr +". If you want to see the data for sub-channels, please enter sub-channel name - Defence, Office within office, APC, Greenfield.";
			}
			else
			{
				if("Internet Sales".equalsIgnoreCase(channel))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD  is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +", "
							+ " Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". \n\n"
							+ " For Hybrid ecomm - Applied Business Adj IFYP MTD  is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +"."
							+ " Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +".";
				}
				else
				{
					finalresponse= "As of "+real_tim_timstamp+" Applied Business Adj IFYP MTD for "+channel+" is "+mtd_applied_adj_ifyp+
							" " + LacsCr +". Applied Business Adj IFYP YTD for "+channel+" is "+ytd_applied_adj_ifyp+
							" " + LacsCr +". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP MTD for "+userzone+ " zone is "+ mtd_applied_adj_ifyp+
					" " + LacsCr +". Applied Business Adj IFYP YTD for "+userzone+" zone is "+ytd_applied_adj_ifyp+
					" " + LacsCr +". If you want to see the region wise business numbers, please specify the same.";

		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP MTD for "+superZone+ " is "+ mtd_applied_adj_ifyp+
					" " + LacsCr +". Applied Business Adj IFYP YTD for "+superZone+" is "+ytd_applied_adj_ifyp+
					" " + LacsCr +". If you want to see the zone wise business numbers, please specify the same.";

		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP MTD for KM "+keyMarket+ " is "+ mtd_applied_adj_ifyp+
					" " + LacsCr +". Applied Business Adj IFYP YTD for KM "+keyMarket+" is "+ytd_applied_adj_ifyp+
					" " + LacsCr ;

		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of "+real_tim_timstamp+ " Applied Business Adj IFYP MTD for "+user_region+" is "+mtd_applied_adj_ifyp+
					" " + LacsCr +". Applied Business Adj IFYP YTD for "+user_region+" is "+ytd_applied_adj_ifyp+" " + LacsCr +".";
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of "+real_tim_timstamp+ " Applied Business Adj IFYP MTD for "+user_clusters+" is "+mtd_applied_adj_ifyp+
					" " + LacsCr +". Applied Business Adj IFYP YTD for "+user_clusters+" is "+ytd_applied_adj_ifyp+" " + LacsCr +".";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of "+real_tim_timstamp+ " Applied Business Adj IFYP MTD for "+user_clusters+" is "+mtd_applied_adj_ifyp+
					" " + LacsCr +". Applied Business Adj IFYP YTD for "+user_clusters+" is "+ytd_applied_adj_ifyp+" " + LacsCr +".";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of "+real_tim_timstamp+ " Applied Business Adj IFYP MTD for "+user_clusters+" is "+mtd_applied_adj_ifyp+
					" " + LacsCr +". Applied Business Adj IFYP YTD for "+user_clusters+" is "+ytd_applied_adj_ifyp+" " + LacsCr +".";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of "+real_tim_timstamp+ " Applied Business Adj IFYP MTD for "+user_region+" is "+mtd_applied_adj_ifyp+
					" " + LacsCr +". Applied Business Adj IFYP YTD for "+user_region+" is "+ytd_applied_adj_ifyp+" " + LacsCr +".";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(keyMarket))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of" +real_tim_timstamp+ " Applied Business Adj IFYP " +period+" for "+channel+ " is "+ ytd_applied_adj_ifyp+
							" " + LacsCr +". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of" +real_tim_timstamp+ " Applied Business Adj IFYP " +period+" for "+channel+ " is "+ mtd_applied_adj_ifyp+
							" " + LacsCr +". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for "+channel+" Applied Adj. IFYP - " +period+" (as on last batch) is "+daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr +"";
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}

			}

		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+superZone+" is "+ytd_applied_adj_ifyp+
							". If you want to see the region wise business numbers, please specify the same.";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+superZone+" is "+mtd_applied_adj_ifyp+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for "+superZone+" Applied Adj. IFYP -" +period+" (as on last batch) is "+ daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for KM "+keyMarket+" is "+ytd_applied_adj_ifyp+
							". If you want to see the region wise business numbers, please specify the same.";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for KM "+keyMarket+" is "+mtd_applied_adj_ifyp+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for KM "+keyMarket+" Applied Adj. IFYP -" +period+" (as on last batch) is "+ daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(keyMarket))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+userzone+" zone is "+ytd_applied_adj_ifyp+
							". If you want to see the region wise business numbers, please specify the same.";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+userzone+" zone is "+mtd_applied_adj_ifyp+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for "+userzone+" Applied Adj. IFYP -" +period+" (as on last batch) is "+ daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_region+" is "+ytd_applied_adj_ifyp+" " + LacsCr;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_region+" is "+mtd_applied_adj_ifyp+" " + LacsCr;
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for "+user_region+" Applied Adj. IFYP - " +period+" (as on last batch) is "+ daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_clusters+" is "+ytd_applied_adj_ifyp+" " + LacsCr;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_clusters+" is "+mtd_applied_adj_ifyp+" " + LacsCr;
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for "+user_clusters+" Applied Adj. IFYP - " +period+" (as on last batch) is "+ daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}
			}
		}
		/*------------------------new condtion added by bhavneet-------------------31-08-2018*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_clusters+" is "+ytd_applied_adj_ifyp+" " + LacsCr;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_clusters+" is "+mtd_applied_adj_ifyp+" " + LacsCr;
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for "+user_clusters+" Applied Adj. IFYP - " +period+" (as on last batch) is "+ daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_region+" is "+ytd_applied_adj_ifyp+" " + LacsCr;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_region+" is "+mtd_applied_adj_ifyp+" " + LacsCr;
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for "+user_region+" Applied Adj. IFYP - " +period+" (as on last batch) is "+ daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_clusters+" is "+ytd_applied_adj_ifyp+" " + LacsCr;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business Adj IFYP "+period+" for "+user_clusters+" is "+mtd_applied_adj_ifyp+" " + LacsCr;
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for "+user_clusters+" Applied Adj. IFYP - " +period+" (as on last batch) is "+ daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}
			}
		}
		else
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+"  Applied Business Adj IFYP "+period+ " for MLI is "+ytd_applied_adj_ifyp+
							" " + LacsCr +". If you want to see the channel wise business numbers, please specify the same.";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+"  Applied Business Adj IFYP "+period+ " for MLI is "+mtd_applied_adj_ifyp+
							" " + LacsCr +". If you want to see the channel wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of" +real_tim_timstamp+ " for MLI Applied Adj. IFYP " +period+" (as on last batch) is "+ daily_applied_adj_ifyp+
							" " + LacsCr +". and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +". ";
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\nFor Hybrid ecomm - Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +". ";
				}
			}
		}
		return finalresponse.toString();
	}
}