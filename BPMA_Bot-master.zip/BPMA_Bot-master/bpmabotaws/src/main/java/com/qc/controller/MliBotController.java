package com.qc.controller;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.qc.api.response.WebhookResponse;
import com.qc.api.service.MliBotService;

@RestController
public class MliBotController 
{
	private static Logger logger = LogManager.getLogger(MliBotController.class);
	public static Map<String, Map<String, String>> sessionMapcontainssoinfo = new ConcurrentHashMap<String, Map<String, String>>();

	@Autowired private MliBotService mliBotService;
	
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	
	@Scheduled(cron = "0 0/30 * * * ?")
	public void removeCasheThirtyMinute() 
	{
		logger.info("Cron job to remove un-used session from cache : Start");
		mliBotService.removeCashethirtyminute();
	}
	
	
	@RequestMapping(value = "/webhook", method = RequestMethod.POST, consumes = { "application/json" }, produces = {"application/json" })

	public @ResponseBody WebhookResponse webhook(@RequestBody String obj,  Model model, HttpSession httpSession) 
	{
		logger.info("  CameInside :- Controller: Webhook");
		
		WebhookResponse responseObj = mliBotService.getBpmaData(obj);
		
		return responseObj;
		
	}
		
}
