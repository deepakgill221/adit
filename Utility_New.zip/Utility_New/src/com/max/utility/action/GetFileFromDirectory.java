package com.max.utility.action;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.max.dao.InsertData;
import com.max.dao.imp.InsertDataImpl;
import com.mli.entity.PolicyDetails;

public class GetFileFromDirectory extends ReadingFile {

	static Logger logger = Logger.getLogger(GetFileFromDirectory.class.getName());
	ReadingFile readingFile = new ReadingFile();

	@SuppressWarnings({ "rawtypes", "unused" })
	public void getFilesAndFilesSubDirectories(String directoryName) {
		logger.debug("Reading file from directory start :: " + directoryName);
		try {
			File directory = new File(directoryName);
			List<String> files = new ArrayList<>();
			String fileExtension = null;
			List<Path> filesName = Files.walk(Paths.get(directoryName)).filter(Files::isRegularFile).collect(Collectors.toList());
			for (Path path : filesName) {
				fileExtension = getFileExtension(path.toString());
				if (fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("xlsx") || fileExtension.equalsIgnoreCase("csv")) {
					if (!path.toString().contains("~")) {
						files.add(path.toString());
						System.out.println("File found :: " + path.toString());
						logger.debug("File found at this location :: " + path.toString());
					}
				}
			}
			System.out.println("Total file :: " + files.size());
			logger.debug("Total file founded  :: " + files.size());
			for (String fileName : files) {

				List<PolicyDetails> policyDetailsList = null;
//				policyDetailsList = readingFile.readingFile(fileName);
				readingFile.readingFile(fileName);
//				InsertData insertData = new InsertDataImpl();
//				if (policyDetailsList != null) {
//					insertData.insertExcelData(policyDetailsList);
//					System.out.println("File processing done for :: " + fileName);
//					logger.debug("File processing done for :: " + fileName);
//				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured while processing :: " + ex);
			System.out.println("Exception occured while processing :: " + ex);
		}

	}
	
	

	public static String getFileExtension(String fileName) {
		logger.debug("START FileExtention method  file  name " + fileName);
		String fileExtension = "";
		try {
			int index = fileName.lastIndexOf(".");
			fileExtension = fileName.substring(index + 1, fileName.length());
		} catch (Exception e) {
			logger.debug("Error during to geting file Extention  " + e);
		}
		logger.info("END FileExtention method  file  name " + fileName);
		return fileExtension;
	}
}
