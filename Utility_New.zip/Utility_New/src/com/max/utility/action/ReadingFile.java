package com.max.utility.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mli.entity.PolicyDetails;

import au.com.bytecode.opencsv.CSVReader;

public class ReadingFile {
	
	static Logger logger = Logger.getLogger(ReadingFile.class.getName());
	static ResourceBundle res = ResourceBundle.getBundle("com.mli.application.properties.SQL");
	@SuppressWarnings({ "rawtypes", "static-access" })
	protected  void readingFile(String filePath) throws FileNotFoundException, IOException{
		logger.debug("File reading started for file :: " +filePath);
		System.out.println("readingFile method START for file :: " +filePath);
		String fileExtension =  GetFileFromDirectory.getFileExtension(filePath);
		List<PolicyDetails> policyDetailsList = null;
		PolicyDetails policyDetailsDto = null;
		String cellValue = "";
		String fileName = "";
		Connection conn = null;
		PreparedStatement ps = null;
		int i = 0;
		if(fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("xlsx") ){
			try(FileInputStream fileInputStream = new FileInputStream(filePath)){
				conn = getConnection();
				ps = conn.prepareStatement(res.getString("SqlQuery"));
				fileName = new File(filePath).getName();
				
				HSSFWorkbook hssfWorkbook = new HSSFWorkbook(fileInputStream);
				for(int sheetNo =0; sheetNo < hssfWorkbook.getNumberOfSheets(); sheetNo++){
					HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(sheetNo);
					Iterator<Row> itr = hssfSheet.rowIterator();
					policyDetailsList = new ArrayList<>();
					Row row = null;
					Cell cell = null;
					while(itr.hasNext()){
						row = (Row) itr.next();
						cell = row.getCell(0);
						if(cell != null && cell.getCellType() == Cell.CELL_TYPE_NUMERIC){
							i++;
							cell.setCellType(cell.CELL_TYPE_STRING);
							policyDetailsDto = new PolicyDetails();
							policyDetailsDto.setPolicyNo(cell.getStringCellValue());
							policyDetailsDto.setFileName(fileName);
							policyDetailsDto.setFilePath(filePath);
							policyDetailsDto.setRowNum(row.getRowNum()+"");
							policyDetailsDto.setId(i);
//							policyDetailsList.add(policyDetailsDto);
							
							if(conn != null){
								ps.setInt(1, policyDetailsDto.getId());
								ps.setString(2, policyDetailsDto.getPolicyNo());
								ps.setString(3, policyDetailsDto.getFileName());
								ps.setString(4, policyDetailsDto.getFilePath());
								ps.setString(5, policyDetailsDto.getRowNum());
								ps.addBatch();
							}
							
							if (i % 500 == 0) {
								ps.executeBatch();
//								conn.commit();
							}	
						}
						
					}
					
					ps.executeBatch();
//					ps.close();
//					conn.close();
					
					System.out.println("Data inserted sucessfully");
				}
				
			}
			catch(Exception ex){
				logger.error("Exception occured while reading excel file :: " +ex);
				logger.error("Issue occured in file format trying one more time :: "+filePath);
				System.out.println("Issue occured in file format trying one more time :: "+filePath);
//				System.out.println("Exception occured 1st time :: " +ex.getMessage());
				if(ex.getMessage().contains("The supplied data appears to be in the Office 2007+ XML")){
					try{
						OPCPackage pkg = OPCPackage.open(new File(filePath));
						 XSSFWorkbook wb = new XSSFWorkbook(pkg);
						 for(int sheetNo = 0; sheetNo < wb.getNumberOfSheets(); sheetNo++){
							 XSSFSheet sheet = wb.getSheetAt(sheetNo);
							 Iterator<Row> itr = sheet.rowIterator();
							 XSSFRow row = null;
							 XSSFCell cell = null;
							 policyDetailsList = new ArrayList<>();
							 while(itr.hasNext()){
								 row = (XSSFRow)itr.next();
								 cell = row.getCell(0);
								 if(cell != null && cell.getCellType() == cell.CELL_TYPE_NUMERIC){
									 i++;
										cell.setCellType(cell.CELL_TYPE_STRING);
										policyDetailsDto = new PolicyDetails();
										policyDetailsDto.setPolicyNo(cell.getStringCellValue());
										policyDetailsDto.setFileName(fileName);
										policyDetailsDto.setFilePath(filePath);
										policyDetailsDto.setRowNum(row.getRowNum()+"");
										policyDetailsDto.setId(i);
//										policyDetailsList.add(policyDetailsDto);
										
										if(conn != null){
											ps.setInt(1, policyDetailsDto.getId());
											ps.setString(2, policyDetailsDto.getPolicyNo());
											ps.setString(3, policyDetailsDto.getFileName());
											ps.setString(4, policyDetailsDto.getFilePath());
											ps.setString(5, policyDetailsDto.getRowNum());
											ps.addBatch();
										}
										
										if (i % 500 == 0) {
											ps.executeBatch();
//											conn.commit();
										}	
								 }
							 }		 
							 	ps.executeBatch();
//								ps.close();
//								conn.close();
								
								System.out.println("Data inserted sucessfully");
						 }
						 
					}
					catch(Exception ex1){
						logger.error("2nd time exception occured while reading excel file :: " +ex);
						System.out.println("Exception occured for 2nd time for the same excel ::  "+ex1);
						
						try {
							if (ps != null) {
								ps.close();
							}
							if (conn != null) {
								conn.close();
							}
						} catch (SQLException sx) {
							logger.debug("Exception occured while closing object :: " + sx);
						}
					}
				}
			}
			
			finally {
				try {
					if (ps != null) {
						ps.close();
					}
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException sx) {
					logger.debug("Exception occured while closing object :: " + sx);
				}
			}
		}
		System.out.println("ReadingFile method END");
		logger.debug("File reading ended for file :: " +filePath);
//		return policyDetailsList;
	}
	
	public Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@172.23.51.186:1875:GBHASETL", "SOAUAT", "soauat#1234");
		} catch (Exception ex) {
			logger.error("Exception occured while creating connection with database :: " + ex);
		}
		return conn;
	}

}
