package com.max.dao.imp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.max.dao.InsertData;
import com.mli.entity.PolicyDetails;

public class InsertDataImpl implements InsertData {
	static Logger logger = Logger.getLogger(InsertDataImpl.class.getName());
	static ResourceBundle res = ResourceBundle.getBundle("com.mli.application.properties.SQL");

	@Override
	public boolean insertExcelData(List<PolicyDetails> policyDetails) {

		System.out.println("Insertion start");
		logger.debug("Insertion of data is started");
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			int batchCount = 0;
			conn = getConnection();
//			conn.setAutoCommit(false);
			if (conn != null) {
				ps = conn.prepareStatement(res.getString("SqlQuery"));
				for (PolicyDetails policyDetailsDto : policyDetails) {
					batchCount++;
					ps.setInt(1, policyDetailsDto.getId());
					ps.setString(2, policyDetailsDto.getPolicyNo());
					ps.setString(3, policyDetailsDto.getFileName());
					ps.setString(4, policyDetailsDto.getFilePath());
					ps.setString(5, policyDetailsDto.getRowNum());
					ps.addBatch();

					if (batchCount % 500 == 0) {
						ps.executeBatch();
//						conn.commit();
					}
//					ps.executeUpdate();

					// System.out.println("sss");
				}
				ps.executeBatch();
				ps.close();
				conn.close();
			}
			else{
				logger.debug("Enable to create connection with database");
			}
		}

		catch (Exception ex) {
			try {
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException sx) {
				logger.debug("Exception occured while closing object :: " + sx);
			}
		}

		finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException sx) {
				logger.debug("Exception occured while closing object :: " + sx);
			}
		}

		logger.debug("Insertion of data is ended");

		// policyDetails.stream().forEach(p -> {
		// try {
		// ps.setInt(1, p.getId());
		// ps.setString(2, p.getPolicyNo());
		// ps.setString(3, p.getFileName());
		// ps.setString(4, p.getFilePath());
		// ps.setString(5, p.getRowNum());
		// ps.execute();
		// conn.commit();
		// } catch (Exception e) {
		// e.printStackTrace();
		// System.out.println("SQL Exception in" + p.getFileName() + e);
		// try {
		// conn.close();
		// } catch (SQLException e1) {
		// e1.printStackTrace();
		// }
		// }
		// });
		// conn.close();
		// } catch (Exception e) {
		// e.printStackTrace();
		// System.out.println("Exception in" + e);
		// }
		// System.out.println("Insertion END");
		return true;
	}

	public Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@172.23.51.186:1875:GBHASETL", "SOAUAT", "soauat#1234");
		} catch (Exception ex) {
			logger.error("Exception occured while creating connection with database :: " + ex);
		}
		return conn;
	}

}
