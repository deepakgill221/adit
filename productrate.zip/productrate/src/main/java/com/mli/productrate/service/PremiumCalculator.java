package com.mli.productrate.service;

import com.mli.productrate.premiumcalculate.request.PremiumCalculatorAPIRequest;
import com.mli.productrate.premiumcalculate.response.PremiumCalculatorApiResponse;

public interface PremiumCalculator {
  public PremiumCalculatorApiResponse calculatePremium(PremiumCalculatorAPIRequest premiumCalculatorAPIRequest); 
}
