package com.mli.productrate.premiumcalculate.request;
import java.io.Serializable;
import java.util.List;

public class RequestPayload implements Serializable{
	private static final long serialVersionUID = 1L;
	private List<RequestPlan> reqPlan;
	public List<RequestPlan> getReqPlan() {
		return reqPlan;
	}
	public void setReqPlan(List<RequestPlan> reqPlan) {
		this.reqPlan = reqPlan;
	}
	
	@Override
	public String toString() {
		return "RequestPayload [reqPlan=" + reqPlan + "]";
	}
	

}
