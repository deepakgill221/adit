package com.mli.productrate.service;

import java.util.List;
import java.util.Map;

import com.mli.productrate.premiumcalculate.response.PlanDetailBean;

public interface PlanDetail {
	public List<PlanDetailBean> callPlanDetailService(String planId,String rtblAgeDur,String rtblSex);

	public List<Map<String , String>> callPremiumCalc(String plans, String rtblAgeDur, String rtblSex, String empDiscount,String serviceName);

}
