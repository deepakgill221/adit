package com.mli.productrate.premiumcalculate.response;

import java.io.Serializable;

import com.mli.productrate.util.Header;
import com.mli.productrate.util.MessageInfo;

public class PremiumCalculatorResponse implements Serializable{
	private static final long serialVersionUID = 1L;
    private Header header;
    private MessageInfo msgInfo;
    private ResponsePayload payload;
    public PremiumCalculatorResponse(){}
	public PremiumCalculatorResponse(Header header, MessageInfo msginfo, Object object) {
	   this.header=header;
	   this.msgInfo=msginfo;
	}
	
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MessageInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MessageInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public ResponsePayload getPayload() {
		return payload;
	}
	public void setPayload(ResponsePayload payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "PremiumCalculatorResponse [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}
    
}
