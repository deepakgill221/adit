package com.mli.productrate.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariDataSource;
/**
 * 
 * @author Tahseem
 * OracleDB STAGCDC Configuration
 */


@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "stagcdcManagerFactory")
public class OracleDBSTAGCDCConfig {

	Logger logger = LoggerFactory.getLogger(OracleDBSTAGCDCConfig.class);
	private static final String RESOURCE_PATH="file:/mount_app/config_repo/productrate/hibernate_productrate.properties";
	
	private static final String PACKAGE_TO_SCAN="com.qc.productrate.entity";
	
	@Value("${db1.maxPoolSize}")
	private int maxPoolSize;
	
	@Value("${db1.minPoolSize}")	
	private int minPoolSize;
	
	@Autowired
	private ResourceLoader resourceLoader;
	/**
	 * ORACLE datasource definition.
	 * 
	 * @return datasource.
	 */
	@Primary
	@Bean
	@ConfigurationProperties(prefix = "spring.datasource")
	public DataSource primaryDataSource() {
		HikariDataSource datasource=(HikariDataSource) DataSourceBuilder.create().build();
		datasource.setMinimumIdle(minPoolSize);
		datasource.setMaximumPoolSize(maxPoolSize);
		return datasource;
	}

	@Primary
	@Bean(name = "stagcdcManagerFactory")
	public LocalContainerEntityManagerFactoryBean stagcdcEntityManagerFactory(EntityManagerFactoryBuilder builder) {
		return builder
				.dataSource(primaryDataSource())
				.packages(PACKAGE_TO_SCAN)
				.properties(hibernateProperties())
				.build();
	}
	
	/**
	 * Entity manager definition. 
	 *  
	 * @param builder an EntityManagerFactoryBuilder.
	 * @return LocalContainerEntityManagerFactoryBean.
	 */
	@Primary 
	@Bean(name = "stagcdcTransactionManager")
	public PlatformTransactionManager stagcdcTransactionManager(@Qualifier("stagcdcManagerFactory") EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}

	private Map<String, Object> hibernateProperties() {

		Resource resource = resourceLoader.getResource(RESOURCE_PATH);

		try {
			Properties properties = PropertiesLoaderUtils.loadProperties(resource);
			return properties.entrySet().stream()
					.collect(Collectors.toMap(
							e -> e.getKey().toString(),
							e -> e.getValue())
							);
		} catch (IOException e) {
			logger.error("Exception while reading hibernate properties :"+e);
			return new HashMap<>();
		}
	}

}
