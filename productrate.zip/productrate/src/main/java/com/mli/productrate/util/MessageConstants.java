package com.mli.productrate.util;

/**
 * @author ad01084
 *
 */
public class MessageConstants 
{
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	
	public static final String C200 = "200";
	public static final String C200DESC = "Response Generated Successfully";
	public static final String C201DESC = 	"Document Uploaded successfully";
	public static final String C203DESC = "Transaction Timeout";
	
	public static final String C500 = "500";
	public static final String C500DESC = "There seems to be something wrong. Please try after sometime.";
	public static final String C501DESC = "Web service not able to write the data";
	
	
	public static final String C600 = "600";
	public static final String C600DESC = "Validation check fail! Please verify your request json mendatory fields i.e. body could not be empty or invalid key!!";
	public static final String C600HDESC = "Validation check fail! Please verify your request json mendatory fields i.e. headers could not be empty or invalid key!!";
	
	public static final String C604 = "604";
	public static final String C604DESC = "OTP Data not comming in quote Product Detail";
	public static final String C603DESC = "Get application not responding.";
	
	public static final String C601 = "601";
	public static final String C601DESC = "Service unavailable";
	public static final String C605DESC = "premium calculation service unavailable";
	
	//////////////DB related Error code/////////////
	public static final String C700 = "700";
	public static final String C700DESC = "Data not found from backend";
	
	public static final String C701 = "701";
	public static final String C701DESC = "There seems to be something wrong at backend.";
	public static final String C702DESC = "Client ID does not exist";
	public static final String C703DESC="No client ID exist";
	
	/////Proposal generation Specific
	public static final String DUPLICATE_MSG = "Duplicate transaction id";
	public static final String PROPOSAL_MSG = "Policy has been delivered";
	public static final String PROPOSAL_EMPTY_MSG = "Policy Numbers in DB for this plan is '0',please fill the DB!";
	public static final String C_888 = "888";
	public static final String C_999 = "999";
	public static final String C_999_MSG = "Partial Success";
	
	//////////////For SP Code Error code/////////////
	public static final String C400 = "400";
	public static final String C400DESC = "Entered SP code has been expired";
	
	public static final String C401 = "401";
	public static final String C401DESC = "Entered SP code is not active";
	
	public static final String C402 = "402";
	public static final String C402DESC = "AML training not done";
	
	public static final String C403 = "403";
	public static final String C403DESC = "Please enter SP code of same branch";
	
	public static final String C602DESC = "CRMnext Service unavailable";
	
}

	
