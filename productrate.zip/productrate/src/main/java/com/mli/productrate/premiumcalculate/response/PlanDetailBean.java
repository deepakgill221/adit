package com.mli.productrate.premiumcalculate.response;

import java.io.Serializable;

public class PlanDetailBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String planId;
	private String rhID;
	private String rtblId;
	private String rhBandAmount;
	private String rtblSexCd;
	private String discountOption;
	private String smokerCode;
	private String rtblMatXpryDur;
	private String issueAge;
	private String rtblAge;
	private String rtbl1rt;
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getRhID() {
		return rhID;
	}
	public void setRhID(String rhID) {
		this.rhID = rhID;
	}
	public String getRtblId() {
		return rtblId;
	}
	public void setRtblId(String rtblId) {
		this.rtblId = rtblId;
	}
	public String getRhBandAmount() {
		return rhBandAmount;
	}
	public void setRhBandAmount(String rhBandAmount) {
		this.rhBandAmount = rhBandAmount;
	}
	public String getRtblSexCd() {
		return rtblSexCd;
	}
	public void setRtblSexCd(String rtblSexCd) {
		this.rtblSexCd = rtblSexCd;
	}
	public String getDiscountOption() {
		return discountOption;
	}
	public void setDiscountOption(String discountOption) {
		this.discountOption = discountOption;
	}
	public String getSmokerCode() {
		return smokerCode;
	}
	public void setSmokerCode(String smokerCode) {
		this.smokerCode = smokerCode;
	}
	public String getRtblMatXpryDur() {
		return rtblMatXpryDur;
	}
	public void setRtblMatXpryDur(String rtblMatXpryDur) {
		this.rtblMatXpryDur = rtblMatXpryDur;
	}
	public String getIssueAge() {
		return issueAge;
	}
	public void setIssueAge(String issueAge) {
		this.issueAge = issueAge;
	}
	public String getRtblAge() {
		return rtblAge;
	}
	public void setRtblAge(String rtblAge) {
		this.rtblAge = rtblAge;
	}
	public String getRtbl1rt() {
		return rtbl1rt;
	}
	public void setRtbl1rt(String rtbl1rt) {
		this.rtbl1rt = rtbl1rt;
	}
	@Override
	public String toString() {
		return "PlanDetailBean [planId=" + planId + ", rhID=" + rhID + ", rtblId=" + rtblId + ", rhBandAmount="
				+ rhBandAmount + ", rtblSexCd=" + rtblSexCd + ", discountOption=" + discountOption + ", smokerCode="
				+ smokerCode + ", rtblMatXpryDur=" + rtblMatXpryDur + ", issueAge=" + issueAge + ", rtblAge=" + rtblAge
				+ ", rtbl1rt=" + rtbl1rt + "]";
	}
	
	

}
