package com.mli.productrate.util;

import java.io.Serializable;

public class Header implements Serializable {

	private static final long serialVersionUID = 1L;
	private String soaAppId = "";
	private String soaCorrelationId = "";
	
	public String getSoaAppId() {
		return soaAppId;
	}

	public void setSoaAppId(String soaAppId) {
		this.soaAppId = soaAppId;
	}

	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}

	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}

	@Override
	public String toString() {
		return "Header [soaAppId=" + soaAppId + ", soaCorrelationId=" + soaCorrelationId + "]";
	}
	
	
}
