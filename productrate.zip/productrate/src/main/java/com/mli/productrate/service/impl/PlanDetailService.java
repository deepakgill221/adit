package com.mli.productrate.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.mli.productrate.dao.NeoDao;
import com.mli.productrate.premiumcalculate.response.PlanDetailBean;
import com.mli.productrate.service.ObjectToPojoService;
import com.mli.productrate.service.PlanDetail;

@Service
public class PlanDetailService implements PlanDetail{
	
	Logger logger =LoggerFactory.getLogger(PlanDetailService.class);
	

	@Autowired
	NeoDao neoDao;
	
	@Autowired
	ObjectToPojoService objectToPojoService;
	
	@Override
	@Cacheable(value="nbserviceCache", key="#planId.concat('-').concat(#rtblAgeDur).concat('-').concat(#rtblSex)", unless="#result == null")
	public List<PlanDetailBean> callPlanDetailService(String planId, String rtblAgeDur, String rtblSex) {
		return neoDao.callPlanDetail(planId,rtblAgeDur,rtblSex);
	}

	@Override
	@Cacheable(value="nbserviceCache", key="#plans.concat('-').concat(#rtblAgeDur).concat('-').concat(#rtblSex).concat('-').concat(#empDiscount).concat('-').concat(#serviceName)", unless="#result == null")
	public List<Map<String, String>> callPremiumCalc(String plans, String rtblAgeDur, String rtblSex,
			String empDiscount, String serviceName) {
		List<Object[]> planDetails= neoDao.callPlanDetailsV2(plans, rtblAgeDur, rtblSex, empDiscount);
		if(planDetails !=null){
			List<Map<String,String>> result =objectToPojoService.getCustomClass(planDetails);
			if(result != null && !result.isEmpty()){
				return result;
			}
			
		}
		return new ArrayList<Map<String,String>>();
	}

}
