package com.mli.productrate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@SpringBootApplication
@PropertySources({
	@PropertySource(value="file:/mount_app/config_repo/productrate/application_productrate.properties",ignoreResourceNotFound=true),
	@PropertySource(value="file:/mount_app/config_repo/productrate/hibernate_productrate.properties",ignoreResourceNotFound=true)
})
public class ProductRateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductRateApplication.class, args);
	}

}
