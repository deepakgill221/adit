package com.mli.productrate.premiumcalculate.response;

import java.io.Serializable;
import java.util.List;

public class ResponsePayload implements Serializable{
	private static final long serialVersionUID = 1L;
	private List<ResponsePlan> resPlan;
	public List<ResponsePlan> getResPlan() {
		return resPlan;
	}
	public void setResPlan(List<ResponsePlan> resPlan) {
		this.resPlan = resPlan;
	}
	@Override
	public String toString() {
		return "ResponsePayload [resPlan=" + resPlan + "]";
	}
	

}
