package com.mli.productrate.premiumcalculate.request;

import java.io.Serializable;

import com.mli.productrate.util.Header;


public class PremiumCalculatorRequest implements Serializable{
	private static final long serialVersionUID = 1L;
	private Header header;
	private RequestPayload payload;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public RequestPayload getPayload() {
		return payload;
	}
	public void setPayload(RequestPayload payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "PremiumCalculatorRequest [header=" + header + ", payload=" + payload + "]";
	}
	

}
