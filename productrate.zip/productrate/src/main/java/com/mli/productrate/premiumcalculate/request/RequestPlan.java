package com.mli.productrate.premiumcalculate.request;

import java.io.Serializable;
import java.util.List;

/**
 * @author ad01084
 *
 */
public class RequestPlan extends RequestPlanData implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private List<RequestRider> reqRider;
	
	public List<RequestRider> getReqRider() {
		return reqRider;
	}
	public void setReqRider(List<RequestRider> reqRider) {
		this.reqRider = reqRider;
	}
	@Override
	public String toString() {
		return "RequestPlan [reqRider=" + reqRider + "]";
	}
}
