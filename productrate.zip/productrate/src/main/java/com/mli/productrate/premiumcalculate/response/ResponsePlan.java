package com.mli.productrate.premiumcalculate.response;

import java.io.Serializable;
import java.util.List;

import com.mli.productrate.premiumcalculate.request.RequestPlanData;

public class ResponsePlan extends RequestPlanData implements Serializable{
	private static final long serialVersionUID = 1L;
	private String totalPremiumWOGST;
	private String totalPremiumWGST;
	private String planBasePremium ;
	private String planWGST ;
	private String totalRiderPremiumWGST;
	private String totalRiderPremiumWOGST;  
	private String planGST;  
	private List<ResponseRider> resRider;
	public String getTotalPremiumWOGST() {
		return totalPremiumWOGST;
	}
	public void setTotalPremiumWOGST(String totalPremiumWOGST) {
		this.totalPremiumWOGST = totalPremiumWOGST;
	}
	public String getTotalPremiumWGST() {
		return totalPremiumWGST;
	}
	public void setTotalPremiumWGST(String totalPremiumWGST) {
		this.totalPremiumWGST = totalPremiumWGST;
	}
	public String getPlanBasePremium() {
		return planBasePremium;
	}
	public void setPlanBasePremium(String planBasePremium) {
		this.planBasePremium = planBasePremium;
	}
	public String getPlanWGST() {
		return planWGST;
	}
	public void setPlanWGST(String planWGST) {
		this.planWGST = planWGST;
	}
	public String getTotalRiderPremiumWGST() {
		return totalRiderPremiumWGST;
	}
	public void setTotalRiderPremiumWGST(String totalRiderPremiumWGST) {
		this.totalRiderPremiumWGST = totalRiderPremiumWGST;
	}
	public String getTotalRiderPremiumWOGST() {
		return totalRiderPremiumWOGST;
	}
	public void setTotalRiderPremiumWOGST(String totalRiderPremiumWOGST) {
		this.totalRiderPremiumWOGST = totalRiderPremiumWOGST;
	}
	public String getPlanGST() {
		return planGST;
	}
	public void setPlanGST(String planGST) {
		this.planGST = planGST;
	}
	public List<ResponseRider> getResRider() {
		return resRider;
	}
	public void setResRider(List<ResponseRider> resRider) {
		this.resRider = resRider;
	}
}
