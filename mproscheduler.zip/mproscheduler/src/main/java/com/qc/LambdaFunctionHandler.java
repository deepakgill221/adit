package com.qc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.QueryRequest;
import com.amazonaws.services.dynamodbv2.model.QueryResult;
import com.amazonaws.services.dynamodbv2.model.ReturnConsumedCapacity;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qc.entity.MproEntity;

public class LambdaFunctionHandler implements RequestHandler<String,String>  {
	
	
	@Override
	public String handleRequest(String arg0, Context context) {
	
		List<MproEntity> list=retriveDataFromQuery();
		
		for(int i=0;i<list.size();i++) 
		{
			MproEntity entity=list.get(i);
			System.out.println("Entity ref kye name "+entity.getReferenceKey());
			
			String refKey=entity.getReferenceKey();
			
			if(refKey!=null)
			{
				
				
			}
			
			
		}
		return "link has been sent successfully";
	}
	
	
	
	
	public List<MproEntity> retriveDataFromQuery(){
		
		List<MproEntity> list=null;
		
	     AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
			.withRegion(Regions.AP_SOUTH_1).build();
			DynamoDB dynamoDB = new DynamoDB(client);
			try {
				        Table table = dynamoDB.getTable("PI_MPRO_SELLER_TRANSACTION"); 
				        String indexName = "MPRO_SOURCE-index";
				        QuerySpec querySpec = new QuerySpec().withScanIndexForward(true)
				            .withReturnConsumedCapacity(ReturnConsumedCapacity.TOTAL)
				            .withConsistentRead(false);

				          if (indexName == "MPRO_SOURCE-index")
				          {
				            Index index = table.getIndex(indexName);
				            querySpec.withKeyConditionExpression("MPRO_SOURCE = :v_source")
				                .withValueMap(new ValueMap().withString(":v_source", "mPro"));
				            ItemCollection<QueryOutcome> items = index.query(querySpec);
				            Iterator<Item> iterator = items.iterator();
				            ObjectMapper objectMapper = new ObjectMapper();
				            list=new ArrayList();
				            while (iterator.hasNext())
				            {
				            	MproEntity pp1= objectMapper.readValue(iterator.next().toJSONPretty(),MproEntity.class);
				            	list.add(pp1);
				            }
				            System.out.println("List size "+list.size());
				        }
			}catch(Exception e) {
				
				System.out.println("Exception in method "+e);
			}
		   System.out.println("End function excuting...... ");
		   return list;
	}
}