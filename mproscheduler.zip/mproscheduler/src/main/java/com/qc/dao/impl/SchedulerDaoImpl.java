package com.qc.dao.impl;

import com.qc.dao.SchedulerDao;

public class SchedulerDaoImpl implements SchedulerDao{

}
