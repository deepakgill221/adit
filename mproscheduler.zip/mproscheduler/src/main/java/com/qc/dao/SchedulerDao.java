package com.qc.dao;

public interface SchedulerDao {

	
	
}
