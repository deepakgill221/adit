package com.qc.util;

public class StringUtility {

	public static String checkStringNullOrBlank(String s) {
		
		if (s != null && !s.equals("") && !s.equalsIgnoreCase("null")) {
			return s.trim().toUpperCase();
		} else {
			return "";
		}
	}
}
