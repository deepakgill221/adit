package com.qc.service;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.qc.entity.MproEntity;
public interface SchedulerService {
public boolean sendMail(MproEntity entity,String idToEncode);
	
	public boolean sendSms(MproEntity entity,String idToEncode); 
	
	public void processMProPosv(List<MproEntity> list ,Context context);
	
	
}
