package com.qc.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HttpsURLConnection;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.qc.entity.MproEntity;
import com.qc.service.SchedulerService;
import com.qc.util.AESEncryptor;
import com.qc.util.StringUtility;
import com.qc.util.XTrustProvider;

public class SchedulerServiceImpl implements SchedulerService {

	static ResourceBundle res = ResourceBundle.getBundle("application");

	
	@Override
	public void processMProPosv(List<MproEntity> list,Context context)
	{
	 LambdaLogger logger = context.getLogger();
	 logger.log("start mpro scheduler...");
		try 
		{
			logger.log("user List size "+list.size());
				    if(!list.isEmpty())
				    {
						for (int i = 0; i <list.size(); i++)
						{
						MproEntity custList=list.get(i);
						if(custList!=null){
							ExecutorService execSemService=Executors.newSingleThreadExecutor();
							Callable<Boolean> callable1=new Callable<Boolean>() {
								@Override
								public Boolean call() throws Exception {
									return sendSmsAndEmail(custList,context);
								}
							};
							execSemService.submit(callable1);
							execSemService.shutdown();
							if (execSemService.awaitTermination(5, TimeUnit.SECONDS)){
			           	    }
						}	
						}
					}
			} catch (Exception ex) 
	     	{
				logger.log("Creating exception in processMProPosv :: "+ex);
		    }
	}

	public Boolean sendSmsAndEmail(MproEntity entity,Context context){
		
			/*if("YES".equalsIgnoreCase(entity.getMpro_bitly_link()))
			{
				boolean smsStatus =false;
				boolean mailStatus = false;
				if(entity.getTxnid() != null)
				{
					mailStatus =sendMail(entity,entity.getTxnid());
					smsStatus =sendSms(entity,entity.getTxnid());
					context.getLogger().log("Mail Status "+mailStatus+ " Sms Status "+smsStatus);
				}
				if(smsStatus)
				{
					//con.updateSellerRecords(list.get(0),"Y");
				}
			}else
			{
				context.getLogger().log("Bittely link not found for txn id "+entity.getTxnid());
			}*/
	  return true;
	}
	
	
	@Override
	public boolean sendMail(MproEntity entity,String idToEncode) {

		String output = new String();
		StringBuilder result = new StringBuilder();				
		try 
		{

			String encTxnId = AESEncryptor.encrypt(idToEncode+"||"+"E"+"||"+"mpro");
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();

			StringBuilder mailReq=new StringBuilder();
			mailReq.append("{");
			mailReq.append("\"request\": {");
			mailReq.append("\"header\": {");
			mailReq.append("\"soaCorrelationId\": \""+entity.getTxnid()+"\",");
			mailReq.append("\"soaAppId\": \"POS\"");
			mailReq.append("},");
			mailReq.append("\"requestData\": {");
			//mailReq.append("\"mailIdTo\": \""+entity.getCustemailid().toLowerCase()+"\",");
			mailReq.append("\"mailSubject\": \"Pre Issuance Verification Link\",");
			mailReq.append("\"fromName\": \"Maxlife Insurance\",");
			mailReq.append("\"attachments\": [],");
			mailReq.append("\"isConsolidate\":false,");
			mailReq.append("\"isFileAttached\":true,");
			mailReq.append("\"fromEmail\": \"DoNotReply@maxlifeinsurance.com\",");
			//mailReq.append("\"mailBody\": \"").append("<html><body>Dear "+((StringUtility.checkStringNullOrBlank(entity.getCustfname())+" "+StringUtility.checkStringNullOrBlank(entity.getCustmname())).trim()+" "+StringUtility.checkStringNullOrBlank(entity.getCustlname())).toUpperCase()+",<br/><br/>Thank you for choosing "+StringUtility.checkStringNullOrBlank(entity.getCustbenifitname())+".<br/>Your Pre Issuance Verification process for Reference no. "+StringUtility.checkStringNullOrBlank(entity.getTxnid())+" has started which is mandatory for policy issuance.<br/>Kindly click on <a href='"+res.getString("com.qc.preissuance.buyerURL")+encTxnId+"'>"+res.getString("com.qc.preissuance.buyerURL")+encTxnId+"</a> to submit your response.</body></html>").append("\"");
			
			mailReq.append("}");
			mailReq.append("}");
			mailReq.append("}");

			String pUrl = res.getString("com.qc.preissuance.sendMailURLConf");
			URL url = new URL(pUrl);


			HttpURLConnection conn = null;
			String devMode = res.getString("spring.enable.proxy.development");
			if(devMode!=null && !devMode.equalsIgnoreCase("") && devMode.equalsIgnoreCase("Y"))
			{
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}

			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("POST");

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(mailReq.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				return false;
			}
		}
		catch (Exception e) 
		{
			return false;
		}
		return true;
	
	}

	@Override
	public boolean sendSms(MproEntity entity,String idToEncode) {

		String output = new String();
		StringBuilder result = new StringBuilder();
		BufferedReader br=null;
		try 
		{
			String encTxnId = AESEncryptor.encrypt(idToEncode+"||"+"M"+"||"+"mpro");
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			StringBuilder sb = new StringBuilder();
			sb.append("{");
			sb.append("	   \"MliSmsService\": {");
			sb.append("      \"requestHeader\": {");
			sb.append("         \"generalConsumerInformation\": {");
			sb.append("            \"messageVersion\": \"1.0\",");
			sb.append("            \"consumerId\": \"").append(res.getString("com.qc.preissuance.smsapi.consumerid")).append("\",");
			sb.append("            \"correlationId\": \"").append(encTxnId).append("\"");
			sb.append("         }");
			sb.append("      },");
			sb.append("      \"requestBody\": {");
			sb.append("        \"appAccId\": \"").append(res.getString("com.qc.preissuance.smsapi.appaccessid")).append("\",");
			sb.append("      \"appAccPass\": \"").append(res.getString("com.qc.preissuance.smsapi.appaccesspass")).append("\",");
			sb.append("        \"appId\": \"").append(res.getString("com.qc.preissuance.smsapi.appid")).append("\",");
	        //sb.append("        \"msgTo\": \""+entity.getCustmobileno()+"\",");
			//sb.append("         \"msgText\": \"Dear "+((StringUtility.checkStringNullOrBlank(entity.getCustfname())+" "+StringUtility.checkStringNullOrBlank(entity.getCustmname())).trim()+" "+StringUtility.checkStringNullOrBlank(entity.getCustlname())).toUpperCase()+", Thank you for choosing "+StringUtility.checkStringNullOrBlank(entity.getCustbenifitname())+". Your Pre Issuance Verification process for Reference no. "+StringUtility.checkStringNullOrBlank(entity.getTxnid())+" has started which is mandatory for policy issuance. Kindly click on "+res.getString("com.qc.preissuance.buyerURL")+encTxnId+" to submit your response.\" ");			
			sb.append("      }");
			sb.append("  }");
			sb.append("}");
			String pUrl = res.getString("com.qc.preissuance.sendSmsURL");
			URL url = new URL(pUrl);

			HttpURLConnection conn = null;
			String DevMode = res.getString("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}

			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("POST");

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(sb.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			if(apiResponseCode == 200)
			{
				br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
			else
			{
				br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				return false;
			}
		}
		catch (Exception e) 
		{
			return false;
		}
		return true;
	}

	
}
