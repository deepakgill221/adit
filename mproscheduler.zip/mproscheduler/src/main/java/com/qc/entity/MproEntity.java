package com.qc.entity;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@DynamoDBTable(tableName = "PI_MPRO_SELLER_TRANSACTION")
@JsonIgnoreProperties(ignoreUnknown = true)
public class MproEntity {
	
	 
	 @DynamoDBHashKey
	 @JsonProperty("TXNID")
	 private String   txnid;
	 @JsonProperty("AGENTCODE")
	 private String agentCode;
	 @JsonProperty("AGENTMOBILENUMBER")
	 private String  agentMobileNumber ;
	 @JsonProperty("AGENTNAME")
	 private String  agentName ;
	 @JsonProperty("AGENTTENURE")
	 private String  agentTenure ;
	 @JsonProperty("AGNTPERSISTENCY")
	 private String  agntpersistency;
	 @JsonProperty("AGNTVINTGDATE")
	 private String   agntvintgdate ;
	 @JsonProperty("AGTCHANELNAME")
	 private String   agtChanelName ;
	 @JsonProperty("AGTGOCODE")
	 private String   agtgoCode ;
	 @JsonProperty("BACKFLOWSTATUS")
	 private String   backFlowStatus;
	 @JsonProperty("CUSTAGE")
	 private String   custage ;
	 @JsonProperty("CUSTBENIFITNAME")
	 private String  custBenifitName;
	 @JsonProperty("CUSTEMAILID")
	 private String   custEmailid;
	 @JsonProperty("CUSTFNAME")
	 private String   custFname ;
	 @JsonProperty("CUSTGROUPID")
	 private String   custGroupId;
	 @JsonProperty("CUSTINIPREMPAY")
	 private String   custiniprempay;
	 @JsonProperty("CUSTLNAME")
	 private String   custLname;
	 @JsonProperty("CUSTMATURITYPERIOD")
	 private String   custMaturityperiod;
	 @JsonProperty("CUSTMNAME")
	 private String   custMname;
	 @JsonProperty("CUSTMOBILENO")
	 private String   custMobileno;
	 @JsonProperty("CUSTPERSISTENCYTYPE")
	 private String   custPersistencyType;
	 @JsonProperty("CUSTPREMIUMTHRO")
	 private String   custPremiumthro;
	 @JsonProperty("CUSTSUMASRDAPLID")
	 private String   custSumasrdaplid;
	 @JsonProperty("CUSTTERMPERIOD")
	 private String   custTermPeriod;
	 @JsonProperty("DT_FDBKSMSTRIGGERED")
	 private String   dtfdbksmsTriggered;
	 @JsonProperty("ECSDETAILS")
	 private String   ecsDetails;
	 @JsonProperty("FEEDBACK")
	 private String   feedback;
	 @JsonProperty("INSRAGE")
	 private String   insrage;
	 @JsonProperty("INSREMAILID")
	 private String   insrEmailid;
	 @JsonProperty("INSRFNAME")
	 private String   insrFname;
	 @JsonProperty("INSRLNAME")
	private String   insrLname;
	 @JsonProperty("INSRMNAME")
	private String   insrMname;
	 @JsonProperty("INSRMOBILENO")
	private String   insrMobileno;
	 @JsonProperty("ISFDBKSMSTRIGGERED")
	private String   isfdbksmsTriggered;
	 @JsonProperty("ISSMOKER")
	private String   isSmoker;
	 @JsonProperty("ISWOPTRUE")
	private String   isWoptrue;
	 @JsonProperty("MPRO_BITLY_LINK")
	private String   mproBitlyLink;
	 @JsonProperty("MPRO_POLICYNUMBER")
	private String   mproPolicyNumber;
	 @JsonProperty("MPRO_PRODUCT_LINK")
	private String   mproProductLink;
	 @JsonProperty("MPRO_SOURCE")
	private String   mproSource;
	 @JsonProperty("OTP_FREQ_NO")
	private String   otpFreqNo;
	 @JsonProperty("OTP_NUMBER")
	private String   otpNumber;
	 @JsonProperty("OTP_RCVD_DT")
	private String   otpRcvdDt;
	 @JsonProperty("OTP_SUBMIT_DT")
	private String  otpSubmitDt;
	 @JsonProperty("PASSEDTOOMNIDOCS")
	private String   passedtoomnidocs;
	 @JsonProperty("PLANCODE")
	private String   planCode;
	 @JsonProperty("PSMLOGIC")
	private String   psmLogic;
	 @JsonProperty("QUAGE")
	private String   quage;
	 @JsonProperty("QUBENIFITNAME")
	private String   qubenifitName;
	 @JsonProperty("QUEMAILID")
	private String   quEmailid;
	 @JsonProperty("QUFNAME")
	private String   quFname;
	 @JsonProperty("QUINIPREMPAY")
	private String   quiniprempay;
	 @JsonProperty("QUINSRAGE")
	private String   quinsrage;
	 @JsonProperty("QUINSREMAILID")
	private String   quinsrEmailId;
	 @JsonProperty("QUINSRFNAME")
	private String   quinsrFname;
	 @JsonProperty("QUINSRLNAME")
	private String   quinsrLname;
	 @JsonProperty("QUINSRMNAME")
	private String   quinsrMname;
	 @JsonProperty("QUINSRMOBILENO")
	private String   quinsrMobileno;
	 @JsonProperty("QULNAME")
	private String   quLname;
	 @JsonProperty("QUMATURITYPERIOD")
	private String   qumaturityPeriod;
	 @JsonProperty("QUMNAME")
	private String   qumname;
	 @JsonProperty("QUMOBILENO")
	private String   quMobileno;
	 @JsonProperty("QUPERSISTENCYTYPE")
	private String   qupersistencytype;
	 @JsonProperty("QUPREMIUMTHRO")
	private String   qupremiumthro;
	 @JsonProperty("QUSUMASRDAPLID")
	private String   qusumasrdaplid;
	 @JsonProperty("QUTERMPERIOD")
	private String   qutermperiod;
	 @JsonProperty("REFERENCEKEY")
	private String   referenceKey;
	 @JsonProperty("REPLSMNTSALE")
	private String   replsmntsale;
	 @JsonProperty("SMS_DATE")
	private String   smsDate;
	 @JsonProperty("SMSTRIGGERED")
	private String   smsTriggered;
	 @JsonProperty("VERIFICATION_SOURCE")
	private String   verificationSource;
	 @JsonProperty("VESTINGAGE")
	private String   vestingage;
	public String getTxnid() {
		return txnid;
	}
	public void setTxnid(String txnid) {
		this.txnid = txnid;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getAgentMobileNumber() {
		return agentMobileNumber;
	}
	public void setAgentMobileNumber(String agentMobileNumber) {
		this.agentMobileNumber = agentMobileNumber;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getAgentTenure() {
		return agentTenure;
	}
	public void setAgentTenure(String agentTenure) {
		this.agentTenure = agentTenure;
	}
	public String getAgntpersistency() {
		return agntpersistency;
	}
	public void setAgntpersistency(String agntpersistency) {
		this.agntpersistency = agntpersistency;
	}
	public String getAgntvintgdate() {
		return agntvintgdate;
	}
	public void setAgntvintgdate(String agntvintgdate) {
		this.agntvintgdate = agntvintgdate;
	}
	public String getAgtChanelName() {
		return agtChanelName;
	}
	public void setAgtChanelName(String agtChanelName) {
		this.agtChanelName = agtChanelName;
	}
	public String getAgtgoCode() {
		return agtgoCode;
	}
	public void setAgtgoCode(String agtgoCode) {
		this.agtgoCode = agtgoCode;
	}
	public String getBackFlowStatus() {
		return backFlowStatus;
	}
	public void setBackFlowStatus(String backFlowStatus) {
		this.backFlowStatus = backFlowStatus;
	}
	public String getCustage() {
		return custage;
	}
	public void setCustage(String custage) {
		this.custage = custage;
	}
	public String getCustBenifitName() {
		return custBenifitName;
	}
	public void setCustBenifitName(String custBenifitName) {
		this.custBenifitName = custBenifitName;
	}
	public String getCustEmailid() {
		return custEmailid;
	}
	public void setCustEmailid(String custEmailid) {
		this.custEmailid = custEmailid;
	}
	public String getCustFname() {
		return custFname;
	}
	public void setCustFname(String custFname) {
		this.custFname = custFname;
	}
	public String getCustGroupId() {
		return custGroupId;
	}
	public void setCustGroupId(String custGroupId) {
		this.custGroupId = custGroupId;
	}
	public String getCustiniprempay() {
		return custiniprempay;
	}
	public void setCustiniprempay(String custiniprempay) {
		this.custiniprempay = custiniprempay;
	}
	public String getCustLname() {
		return custLname;
	}
	public void setCustLname(String custLname) {
		this.custLname = custLname;
	}
	public String getCustMaturityperiod() {
		return custMaturityperiod;
	}
	public void setCustMaturityperiod(String custMaturityperiod) {
		this.custMaturityperiod = custMaturityperiod;
	}
	public String getCustMname() {
		return custMname;
	}
	public void setCustMname(String custMname) {
		this.custMname = custMname;
	}
	public String getCustMobileno() {
		return custMobileno;
	}
	public void setCustMobileno(String custMobileno) {
		this.custMobileno = custMobileno;
	}
	public String getCustPersistencyType() {
		return custPersistencyType;
	}
	public void setCustPersistencyType(String custPersistencyType) {
		this.custPersistencyType = custPersistencyType;
	}
	public String getCustPremiumthro() {
		return custPremiumthro;
	}
	public void setCustPremiumthro(String custPremiumthro) {
		this.custPremiumthro = custPremiumthro;
	}
	public String getCustSumasrdaplid() {
		return custSumasrdaplid;
	}
	public void setCustSumasrdaplid(String custSumasrdaplid) {
		this.custSumasrdaplid = custSumasrdaplid;
	}
	public String getCustTermPeriod() {
		return custTermPeriod;
	}
	public void setCustTermPeriod(String custTermPeriod) {
		this.custTermPeriod = custTermPeriod;
	}
	public String getDtfdbksmsTriggered() {
		return dtfdbksmsTriggered;
	}
	public void setDtfdbksmsTriggered(String dtfdbksmsTriggered) {
		this.dtfdbksmsTriggered = dtfdbksmsTriggered;
	}
	public String getEcsDetails() {
		return ecsDetails;
	}
	public void setEcsDetails(String ecsDetails) {
		this.ecsDetails = ecsDetails;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getInsrage() {
		return insrage;
	}
	public void setInsrage(String insrage) {
		this.insrage = insrage;
	}
	public String getInsrEmailid() {
		return insrEmailid;
	}
	public void setInsrEmailid(String insrEmailid) {
		this.insrEmailid = insrEmailid;
	}
	public String getInsrFname() {
		return insrFname;
	}
	public void setInsrFname(String insrFname) {
		this.insrFname = insrFname;
	}
	public String getInsrLname() {
		return insrLname;
	}
	public void setInsrLname(String insrLname) {
		this.insrLname = insrLname;
	}
	public String getInsrMname() {
		return insrMname;
	}
	public void setInsrMname(String insrMname) {
		this.insrMname = insrMname;
	}
	public String getInsrMobileno() {
		return insrMobileno;
	}
	public void setInsrMobileno(String insrMobileno) {
		this.insrMobileno = insrMobileno;
	}
	public String getIsfdbksmsTriggered() {
		return isfdbksmsTriggered;
	}
	public void setIsfdbksmsTriggered(String isfdbksmsTriggered) {
		this.isfdbksmsTriggered = isfdbksmsTriggered;
	}
	public String getIsSmoker() {
		return isSmoker;
	}
	public void setIsSmoker(String isSmoker) {
		this.isSmoker = isSmoker;
	}
	public String getIsWoptrue() {
		return isWoptrue;
	}
	public void setIsWoptrue(String isWoptrue) {
		this.isWoptrue = isWoptrue;
	}
	public String getMproBitlyLink() {
		return mproBitlyLink;
	}
	public void setMproBitlyLink(String mproBitlyLink) {
		this.mproBitlyLink = mproBitlyLink;
	}
	public String getMproPolicyNumber() {
		return mproPolicyNumber;
	}
	public void setMproPolicyNumber(String mproPolicyNumber) {
		this.mproPolicyNumber = mproPolicyNumber;
	}
	public String getMproProductLink() {
		return mproProductLink;
	}
	public void setMproProductLink(String mproProductLink) {
		this.mproProductLink = mproProductLink;
	}
	public String getMproSource() {
		return mproSource;
	}
	public void setMproSource(String mproSource) {
		this.mproSource = mproSource;
	}
	public String getOtpFreqNo() {
		return otpFreqNo;
	}
	public void setOtpFreqNo(String otpFreqNo) {
		this.otpFreqNo = otpFreqNo;
	}
	public String getOtpNumber() {
		return otpNumber;
	}
	public void setOtpNumber(String otpNumber) {
		this.otpNumber = otpNumber;
	}
	public String getOtpRcvdDt() {
		return otpRcvdDt;
	}
	public void setOtpRcvdDt(String otpRcvdDt) {
		this.otpRcvdDt = otpRcvdDt;
	}
	public String getOtpSubmitDt() {
		return otpSubmitDt;
	}
	public void setOtpSubmitDt(String otpSubmitDt) {
		this.otpSubmitDt = otpSubmitDt;
	}
	public String getPassedtoomnidocs() {
		return passedtoomnidocs;
	}
	public void setPassedtoomnidocs(String passedtoomnidocs) {
		this.passedtoomnidocs = passedtoomnidocs;
	}
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getPsmLogic() {
		return psmLogic;
	}
	public void setPsmLogic(String psmLogic) {
		this.psmLogic = psmLogic;
	}
	public String getQuage() {
		return quage;
	}
	public void setQuage(String quage) {
		this.quage = quage;
	}
	public String getQubenifitName() {
		return qubenifitName;
	}
	public void setQubenifitName(String qubenifitName) {
		this.qubenifitName = qubenifitName;
	}
	public String getQuEmailid() {
		return quEmailid;
	}
	public void setQuEmailid(String quEmailid) {
		this.quEmailid = quEmailid;
	}
	public String getQuFname() {
		return quFname;
	}
	public void setQuFname(String quFname) {
		this.quFname = quFname;
	}
	public String getQuiniprempay() {
		return quiniprempay;
	}
	public void setQuiniprempay(String quiniprempay) {
		this.quiniprempay = quiniprempay;
	}
	public String getQuinsrage() {
		return quinsrage;
	}
	public void setQuinsrage(String quinsrage) {
		this.quinsrage = quinsrage;
	}
	public String getQuinsrEmailId() {
		return quinsrEmailId;
	}
	public void setQuinsrEmailId(String quinsrEmailId) {
		this.quinsrEmailId = quinsrEmailId;
	}
	public String getQuinsrFname() {
		return quinsrFname;
	}
	public void setQuinsrFname(String quinsrFname) {
		this.quinsrFname = quinsrFname;
	}
	public String getQuinsrLname() {
		return quinsrLname;
	}
	public void setQuinsrLname(String quinsrLname) {
		this.quinsrLname = quinsrLname;
	}
	public String getQuinsrMname() {
		return quinsrMname;
	}
	public void setQuinsrMname(String quinsrMname) {
		this.quinsrMname = quinsrMname;
	}
	public String getQuinsrMobileno() {
		return quinsrMobileno;
	}
	public void setQuinsrMobileno(String quinsrMobileno) {
		this.quinsrMobileno = quinsrMobileno;
	}
	public String getQuLname() {
		return quLname;
	}
	public void setQuLname(String quLname) {
		this.quLname = quLname;
	}
	public String getQumaturityPeriod() {
		return qumaturityPeriod;
	}
	public void setQumaturityPeriod(String qumaturityPeriod) {
		this.qumaturityPeriod = qumaturityPeriod;
	}
	public String getQumname() {
		return qumname;
	}
	public void setQumname(String qumname) {
		this.qumname = qumname;
	}
	public String getQuMobileno() {
		return quMobileno;
	}
	public void setQuMobileno(String quMobileno) {
		this.quMobileno = quMobileno;
	}
	public String getQupersistencytype() {
		return qupersistencytype;
	}
	public void setQupersistencytype(String qupersistencytype) {
		this.qupersistencytype = qupersistencytype;
	}
	public String getQupremiumthro() {
		return qupremiumthro;
	}
	public void setQupremiumthro(String qupremiumthro) {
		this.qupremiumthro = qupremiumthro;
	}
	public String getQusumasrdaplid() {
		return qusumasrdaplid;
	}
	public void setQusumasrdaplid(String qusumasrdaplid) {
		this.qusumasrdaplid = qusumasrdaplid;
	}
	public String getQutermperiod() {
		return qutermperiod;
	}
	public void setQutermperiod(String qutermperiod) {
		this.qutermperiod = qutermperiod;
	}
	public String getReferenceKey() {
		return referenceKey;
	}
	public void setReferenceKey(String referenceKey) {
		this.referenceKey = referenceKey;
	}
	public String getReplsmntsale() {
		return replsmntsale;
	}
	public void setReplsmntsale(String replsmntsale) {
		this.replsmntsale = replsmntsale;
	}
	public String getSmsDate() {
		return smsDate;
	}
	public void setSmsDate(String smsDate) {
		this.smsDate = smsDate;
	}
	public String getSmsTriggered() {
		return smsTriggered;
	}
	public void setSmsTriggered(String smsTriggered) {
		this.smsTriggered = smsTriggered;
	}
	public String getVerificationSource() {
		return verificationSource;
	}
	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}
	public String getVestingage() {
		return vestingage;
	}
	public void setVestingage(String vestingage) {
		this.vestingage = vestingage;
	} 
	 
	 
	 
}
