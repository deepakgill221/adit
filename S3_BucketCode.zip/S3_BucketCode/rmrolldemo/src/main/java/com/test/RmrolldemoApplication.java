package com.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class RmrolldemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RmrolldemoApplication.class, args);
	}
	@Bean
    S3StorageService createStorageService() {
            S3StorageService storageService = new S3StorageService();
            storageService.init();

            return storageService;
    }
	
}
