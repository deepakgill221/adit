package common;
import java.io.FileOutputStream;

import org.apache.commons.io.IOUtils;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
public class FinalPoc
{
	public static void main(String args[])
	{
		String clientRegion = "ap-south-1";
	    String s3bucketName = "chatbotuat";
	    String secretAccessKey = "Z/OAm9hc7in1wXGSr0ih9rCFMcaJ0nE0ms5NTBfi" ;
	    String accessKeyId="AKIAJQC4K3CIOVQ2IYFA";
	    try
	    {
		AWSCredentials credentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
	    AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(clientRegion)
	     .build();
	    GetObjectRequest request = new GetObjectRequest(s3bucketName,"image/graph.jpg");
	    S3Object object = s3Client.getObject(request);
	    
	    S3ObjectInputStream objectContent = object.getObjectContent();
	    IOUtils.copy(objectContent, new FileOutputStream("D:\\newtest.jpg"));
	    
	    }catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	    
	}
	
}
