package common;

import java.io.FileInputStream;
import java.io.IOException;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.PropertiesCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;

public class UploadFile {

 public static void main(String[] args) throws IOException {
 // String existingBucketName = "chatbotuat";
  
	 String keyName = "image/uploadtest.jpg";
	 String clientRegion = "ap-south-1";
	    String s3bucketName = "chatbotuat";
	    String secretAccessKey = "Z/OAm9hc7in1wXGSr0ih9rCFMcaJ0nE0ms5NTBfi" ;
	    String accessKeyId="AKIAJQC4K3CIOVQ2IYFA";
  
  
  String filePath = "C:\\Users\\qualtech\\AA\\graph.jpg";
  String amazonFileUploadLocationOriginal=s3bucketName+"/";
  
try {
	AWSCredentials credentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
    AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials)).withRegion(clientRegion)
     .build();
  FileInputStream stream = new FileInputStream(filePath);
  ObjectMetadata objectMetadata = new ObjectMetadata();
  PutObjectRequest putObjectRequest = new PutObjectRequest(amazonFileUploadLocationOriginal, keyName, stream, objectMetadata);
  PutObjectResult result = s3Client.putObject(putObjectRequest);
  System.out.println("Etag:" + result.getETag() + "-->" + result);
}catch(Exception e)
{
e.printStackTrace();	
	
}


 }
 
}